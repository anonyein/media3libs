/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.cast;

import static androidx.media3.cast.CastTimeline.ItemData.UNKNOWN_CONTENT_ID;
import static com.google.common.base.Preconditions.checkNotNull;

import android.util.SparseArray;
import androidx.annotation.VisibleForTesting;
import androidx.media3.cast.CastTimeline.ItemData;
import androidx.media3.cast.CastTimeline.ItemUid;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Timeline;
import androidx.media3.common.util.Log;
import androidx.media3.common.util.Util;
import com.google.android.gms.cast.MediaInfo;
import com.google.android.gms.cast.MediaQueueItem;
import com.google.android.gms.cast.MediaStatus;
import com.google.android.gms.cast.framework.media.MediaQueue;
import com.google.android.gms.cast.framework.media.RemoteMediaClient;
import com.google.common.collect.ImmutableList;
import com.google.common.primitives.Ints;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;
import org.jspecify.annotations.Nullable;

/**
 * Creates {@link CastTimeline CastTimelines} from cast receiver app status updates.
 *
 * <p>This class keeps track of the duration reported by the current item to fill any missing
 * durations in the media queue items [See internal: b/65152553].
 */
/* package */ final class CastTimelineTracker {
  private static final String TAG = "CastTlTracker";
  /* package */ static final String KEY_SYNTHETIC_ID = "m3-syntheticId";

  // TODO: b/579370960 - Remove MAX_FETCH_COUNT once MediaQueue#fetchItemsForIds in the Cast SDK no
  // longer triggers concurrent overlapping requests (CastStatusCodes.REPLACED) and redundant
  // re-fetches when passed more than its internal 20-item batch size.
  @VisibleForTesting /* package */ static final int MAX_FETCH_COUNT = 20;

  private final Map<ItemUid, ItemData> itemIdToData;
  // Tracks the receiver-resolved live vs. buffered stream type per ItemUid (absent if not yet
  // resolved from mediaStatus.getMediaInfo() while PLAYING or PAUSED), because
  // MediaQueueItem.getMedia() entries in mediaStatus.getQueueItems() do not receive runtime
  // stream-type updates from the receiver.
  private final Map<ItemUid, Boolean> resolvedLiveByUid;
  // Tracks the receiver-resolved VOD manifest duration per ItemUid from mediaStatus.getMediaInfo()
  // while PLAYING or PAUSED, so MediaQueueItem.getMedia() entries (and mediaStatus.getMediaInfo()
  // during IDLE or BUFFERING) carrying the initial catalog duration do not overwrite the manifest
  // duration.
  private final Map<ItemUid, Long> resolvedDurationUsByUid;
  // TODO: b/553993066 - Evict entries when items are removed from the timeline to avoid unbounded
  // growth during long-running sessions.
  private final Map<ItemUid, MediaItem> mediaItemsBySyntheticId;
  // Maps the receiver assigned id to the synthetic id for media items. The synthetic id is used as
  // the stable uid of the media item in CastTimeline and abstracts away the receiver assigned id
  // from consumers.
  private final SparseArray<ItemUid> receiverItemIdToUid;
  private final Map<ItemUid, Integer> uidToReceiverItemId;
  private final MediaItemConverter mediaItemConverter;
  private boolean hasPendingQueueFetches;
  @VisibleForTesting /* package */ final HashMap<String, MediaItem> mediaItemsByContentId;

  /**
   * Creates an instance.
   *
   * @param mediaItemConverter The converter used to convert from a {@link MediaQueueItem} to a
   *     {@link MediaItem}.
   */
  public CastTimelineTracker(MediaItemConverter mediaItemConverter) {
    this.mediaItemConverter = mediaItemConverter;
    itemIdToData = new HashMap<>();
    resolvedLiveByUid = new HashMap<>();
    resolvedDurationUsByUid = new HashMap<>();
    mediaItemsBySyntheticId = new HashMap<>();
    receiverItemIdToUid = new SparseArray<>();
    uidToReceiverItemId = new HashMap<>();
    mediaItemsByContentId = new HashMap<>();
  }

  /**
   * Returns the {@link ItemUid} associated with {@code receiverItemId}, or {@code null} if not
   * found.
   */
  public @Nullable ItemUid getItemUid(int receiverItemId) {
    return receiverItemIdToUid.get(receiverItemId);
  }

  /**
   * Returns the receiver item ID for {@code uid}, or {@link MediaQueueItem#INVALID_ITEM_ID} if not
   * found.
   */
  public int getReceiverItemId(@Nullable Object uid) {
    if (uid == null || !(uid instanceof ItemUid)) {
      return MediaQueueItem.INVALID_ITEM_ID;
    }
    Integer receiverId = uidToReceiverItemId.get(uid);
    return receiverId != null ? receiverId : MediaQueueItem.INVALID_ITEM_ID;
  }

  /** Resets all item data and UID mappings. */
  public void reset() {
    itemIdToData.clear();
    resolvedLiveByUid.clear();
    resolvedDurationUsByUid.clear();
    mediaItemsBySyntheticId.clear();
    receiverItemIdToUid.clear();
    uidToReceiverItemId.clear();
    mediaItemsByContentId.clear();
    hasPendingQueueFetches = false;
  }

  /** Returns whether any items in the receiver's {@link MediaQueue} are still being fetched. */
  public boolean hasPendingQueueFetches() {
    return hasPendingQueueFetches;
  }

  /**
   * Holds the registered {@link MediaQueueItem MediaQueueItems} and their corresponding synthetic
   * {@link ItemUid ItemUids}.
   */
  public static final class RegisteredMediaItems {
    public final MediaQueueItem[] queueItems;
    public final ImmutableList<ItemUid> itemUids;

    public RegisteredMediaItems(MediaQueueItem[] queueItems, ImmutableList<ItemUid> itemUids) {
      this.queueItems = queueItems;
      this.itemUids = itemUids;
    }
  }

  /**
   * Registers the given {@link MediaItem MediaItems} with synthetic {@link ItemUid ItemUids} and
   * returns the registered {@link MediaQueueItem MediaQueueItems} and {@link ItemUid ItemUids}.
   */
  public RegisteredMediaItems registerMediaItems(List<MediaItem> mediaItems) {
    ImmutableList.Builder<ItemUid> itemUids =
        ImmutableList.builderWithExpectedSize(mediaItems.size());
    MediaQueueItem[] mediaQueueItems = new MediaQueueItem[mediaItems.size()];
    for (int i = 0; i < mediaItems.size(); i++) {
      ItemUid itemUid = ItemUid.generateItemUid();
      itemUids.add(itemUid);
      mediaQueueItems[i] = convertAndRegisterMediaItem(itemUid, mediaItems.get(i));
    }
    return new RegisteredMediaItems(mediaQueueItems, itemUids.build());
  }

  /**
   * Updates the tracker state when the receiver queue has ended by clearing receiver item ID
   * mappings and pending queue fetch state while retaining cached item data and {@link MediaItem
   * MediaItems}.
   */
  public void updateStateOnQueueEnd() {
    receiverItemIdToUid.clear();
    uidToReceiverItemId.clear();
    hasPendingQueueFetches = false;
  }

  /**
   * Converts the items in {@code timeline} to {@link MediaQueueItem MediaQueueItems} for reloading
   * the queue on the receiver while preserving each window's existing {@link ItemUid}.
   */
  public MediaQueueItem[] toMediaQueueItems(CastTimeline timeline) {
    int windowCount = timeline.getWindowCount();
    MediaQueueItem[] mediaQueueItems = new MediaQueueItem[windowCount];
    Timeline.Window window = new Timeline.Window();
    for (int i = 0; i < windowCount; i++) {
      timeline.getWindow(i, window);
      mediaQueueItems[i] = convertAndRegisterMediaItem((ItemUid) window.uid, window.mediaItem);
    }
    return mediaQueueItems;
  }

  /**
   * Returns a {@link CastTimeline} that represents the state of the given {@code
   * remoteMediaClient}.
   *
   * <p>Returned timelines may contain values obtained from {@code remoteMediaClient} in previous
   * invocations of this method.
   *
   * @param remoteMediaClient The Cast media client.
   * @return A {@link CastTimeline} that represents the given {@code remoteMediaClient} status.
   */
  public CastTimeline getCastTimeline(RemoteMediaClient remoteMediaClient) {
    MediaQueue mediaQueue = remoteMediaClient.getMediaQueue();
    int[] itemIds = mediaQueue.getItemIds();
    if (itemIds.length > 0) {
      // Only remove unused items when there is something in the queue to avoid removing all entries
      // if the remote media client clears the queue temporarily. See [Internal ref: b/128825216].
      removeUnusedItemDataEntries(itemIds);
    }

    // TODO: Reset state when the app instance changes [Internal ref: b/129672468].
    MediaStatus mediaStatus = remoteMediaClient.getMediaStatus();
    if (mediaStatus == null || mediaStatus.getMediaInfo() == null) {
      hasPendingQueueFetches = false;
      return CastTimeline.EMPTY_CAST_TIMELINE;
    }

    for (MediaQueueItem queueItem : mediaStatus.getQueueItems()) {
      updateItemDataFromQueueItem(queueItem);
    }

    int currentOrLoadingItemId = CastUtils.getCurrentOrLoadingItemId(remoteMediaClient);
    int currentItemIndex = Util.linearSearch(itemIds, currentOrLoadingItemId);
    if (currentItemIndex == C.INDEX_UNSET) {
      // This is not expected to happen, but prevents us from running out of bounds in the following
      // loop.
      currentItemIndex = 0;
    }

    // MediaStatus can report an active item or queue items before MediaQueue finishes fetching
    // the full item ID list (itemIds.length == 0). Mark fetches as pending so callers do not
    // treat the resulting empty timeline as a complete receiver state.
    hasPendingQueueFetches =
        itemIds.length == 0
            && (currentOrLoadingItemId != MediaQueueItem.INVALID_ITEM_ID
                || !mediaStatus.getQueueItems().isEmpty());

    // Fetch missing item metadata starting from the current playback index forward.
    // MediaQueue's internal cache and per-request batch size are bounded at 20 items, so we probe
    // cached items via getItemAtIndex(i, /* fetchIfNeeded= */ false) without starting its debounce
    // timer, and cap immediate batch network requests per pass to MAX_FETCH_COUNT via
    // fetchItemsForIds (see b/579370960).
    List<Integer> itemIdsToFetch = new ArrayList<>();
    for (int step = 0; step < itemIds.length; step++) {
      int i = (currentItemIndex + step) % itemIds.length;
      int itemId = itemIds[i];
      ItemUid uid = receiverItemIdToUid.get(itemId);
      ItemData itemData = uid != null ? itemIdToData.get(uid) : null;
      if (itemData == null || itemData.mediaItem == MediaItem.EMPTY) {
        MediaQueueItem queueItem = mediaQueue.getItemAtIndex(i, /* fetchIfNeeded= */ false);
        if (queueItem != null) {
          updateItemDataFromQueueItem(queueItem);
        } else {
          if (itemId != currentOrLoadingItemId) {
            hasPendingQueueFetches = true;
          }
          if (itemIdsToFetch.size() < MAX_FETCH_COUNT) {
            itemIdsToFetch.add(itemId);
          }
        }
      }
    }
    if (!itemIdsToFetch.isEmpty()) {
      mediaQueue.fetchItemsForIds(Ints.toArray(itemIdsToFetch));
    }

    // Process mediaStatus.getMediaInfo() after mediaStatus.getQueueItems()[...].getMedia(). Static
    // queue items in the Cast SDK do not receive dynamic runtime updates (such as transitioning
    // from buffered to live upon manifest loading). Updating from mediaStatus.getMediaInfo() second
    // ensures that active runtime playback state is preserved and not overwritten by stale queue
    // item metadata.
    //
    // Skip this update when mediaStatus.getLoadingItemId() is valid because Media3 already treats
    // the loading item as the current item (currentOrLoadingItemId), whereas
    // mediaStatus.getCurrentItemId() (and mediaStatus.getMediaInfo()) does not update until the
    // item finishes loading. Skipping prevents overriding the loading item's data with a
    // mismatched item's MediaInfo.
    if (mediaStatus.getLoadingItemId() == MediaQueueItem.INVALID_ITEM_ID) {
      MediaInfo currentMediaInfo = checkNotNull(mediaStatus.getMediaInfo());
      ItemUid currentItemUid = getOrCreateItemUid(currentOrLoadingItemId, currentMediaInfo);
      @Nullable MediaItem mediaItem = getMediaItem(currentItemUid, currentMediaInfo);
      int playerState = remoteMediaClient.getPlayerState();
      boolean isMediaInfoResolved =
          playerState == MediaStatus.PLAYER_STATE_PLAYING
              || playerState == MediaStatus.PLAYER_STATE_PAUSED;
      updateItemData(
          currentItemUid,
          mediaItem != null ? mediaItem : MediaItem.EMPTY,
          currentMediaInfo,
          currentMediaInfo.getContentId(),
          /* defaultPositionUs= */ C.TIME_UNSET,
          isMediaInfoResolved);
    }

    ImmutableList.Builder<ItemUid> uids = ImmutableList.builderWithExpectedSize(itemIds.length);
    for (int itemId : itemIds) {
      uids.add(getOrCreateItemUid(itemId));
    }
    return new CastTimeline(uids.build(), itemIdToData);
  }

  /**
   * Converts {@code mediaItem} to a {@link MediaQueueItem}, attaches {@code itemUid} to its custom
   * data, and registers the mapping from {@code itemUid} and content ID to {@code mediaItem}.
   */
  private MediaQueueItem convertAndRegisterMediaItem(ItemUid itemUid, MediaItem mediaItem) {
    MediaQueueItem queueItem =
        attachSyntheticId(mediaItemConverter.toMediaQueueItem(mediaItem), itemUid);
    mediaItemsBySyntheticId.put(itemUid, mediaItem);
    @Nullable MediaInfo mediaInfo = queueItem.getMedia();
    if (mediaInfo != null && mediaInfo.getContentId() != null) {
      mediaItemsByContentId.put(mediaInfo.getContentId(), mediaItem);
    }
    return queueItem;
  }

  private void updateItemDataFromQueueItem(MediaQueueItem queueItem) {
    long defaultPositionUs = (long) (queueItem.getStartTime() * C.MICROS_PER_SECOND);
    @Nullable MediaInfo mediaInfo = queueItem.getMedia();
    String contentId = mediaInfo != null ? mediaInfo.getContentId() : UNKNOWN_CONTENT_ID;
    ItemUid itemUid = getOrCreateItemUid(queueItem.getItemId(), queueItem.getMedia());
    @Nullable MediaItem mediaItem = getMediaItem(itemUid, mediaInfo);
    if (mediaItem == null || mediaItem == MediaItem.EMPTY) {
      mediaItem = mediaItemConverter.toMediaItem(queueItem);
    }
    updateItemData(
        itemUid,
        mediaItem != null ? mediaItem : MediaItem.EMPTY,
        mediaInfo,
        contentId,
        defaultPositionUs,
        /* isMediaInfoResolved= */ false);
  }

  private void updateItemData(
      ItemUid uid,
      MediaItem mediaItem,
      @Nullable MediaInfo mediaInfo,
      String contentId,
      long defaultPositionUs,
      boolean isMediaInfoResolved) {
    ItemData previousData = itemIdToData.get(uid);
    if (previousData == null) {
      previousData = ItemData.EMPTY;
    }
    // The media item can be empty if it originates from another sender. We use previous data as
    // itemIdToData is populated when all media items from the queue are updated.
    if (mediaItem == MediaItem.EMPTY) {
      mediaItem = previousData.mediaItem;
    }

    if (isMediaInfoResolved && mediaInfo != null) {
      if (mediaInfo.getStreamType() == MediaInfo.STREAM_TYPE_LIVE) {
        resolvedLiveByUid.put(uid, true);
        resolvedDurationUsByUid.remove(uid);
      } else {
        if (mediaInfo.getStreamType() == MediaInfo.STREAM_TYPE_BUFFERED) {
          resolvedLiveByUid.put(uid, false);
        }
        long activeDurationUs = CastUtils.getStreamDurationUs(mediaInfo);
        if (activeDurationUs != C.TIME_UNSET) {
          resolvedDurationUsByUid.put(uid, activeDurationUs);
        }
      }
    }

    // Prefer resolvedLiveByUid (and resolvedDurationUsByUid in getNonLiveDurationUs) over
    // mediaInfo: once an item has been resolved from active PLAYING/PAUSED playback, subsequent
    // updates from MediaQueueItem.getMedia() (or during IDLE/BUFFERING) still carry the initial
    // streamType and catalog streamDuration.
    @Nullable Boolean resolvedLive = resolvedLiveByUid.get(uid);
    boolean isLiveStream =
        resolvedLive != null
            ? resolvedLive
            : (mediaInfo == null
                    ? previousData.isLive
                    : mediaInfo.getStreamType() == MediaInfo.STREAM_TYPE_LIVE)
                || !mediaItem.liveConfiguration.equals(MediaItem.LiveConfiguration.UNSET);

    long durationUs;
    boolean isLive;
    boolean isSeekable;
    if (isLiveStream) {
      durationUs = C.TIME_UNSET;
      isLive = true;
      isSeekable = false;
    } else {
      durationUs = getNonLiveDurationUs(uid, mediaInfo, previousData, mediaItem);
      isLive = false;
      isSeekable = durationUs != C.TIME_UNSET;
    }

    if (defaultPositionUs == C.TIME_UNSET) {
      defaultPositionUs = previousData.defaultPositionUs;
    }
    itemIdToData.put(
        uid,
        previousData.copyWithNewValues(
            durationUs, defaultPositionUs, isLive, isSeekable, mediaItem, contentId));
  }

  /**
   * Returns the duration in microseconds for a non-live item, preferring the manifest duration
   * recorded during active playback over {@code mediaInfo} (which may be a {@link
   * MediaQueueItem#getMedia()} entry or an active {@link MediaStatus#getMediaInfo()} instance),
   * cached {@code previousData}, and {@link MediaItem#mediaMetadata}.
   */
  private long getNonLiveDurationUs(
      ItemUid uid, @Nullable MediaInfo mediaInfo, ItemData previousData, MediaItem mediaItem) {
    // Prefer the manifest-resolved duration over mediaInfo, which for inactive queue items (and
    // during IDLE) still reports the static catalog streamDuration from MediaQueueItem.getMedia().
    @Nullable Long resolvedDurationUs = resolvedDurationUsByUid.get(uid);
    if (resolvedDurationUs != null) {
      return resolvedDurationUs;
    }
    long streamDurationUs = CastUtils.getStreamDurationUs(mediaInfo);
    if (streamDurationUs != C.TIME_UNSET) {
      return streamDurationUs;
    }
    if (!previousData.isLive && previousData.durationUs != C.TIME_UNSET) {
      return previousData.durationUs;
    }
    @Nullable Long metadataDurationMs = mediaItem.mediaMetadata.durationMs;
    if (metadataDurationMs != null) {
      return Util.msToUs(metadataDurationMs);
    }
    return C.TIME_UNSET;
  }

  private void removeUnusedItemDataEntries(int[] itemIds) {
    HashSet<Integer> activeReceiverIds = new HashSet<>(/* initialCapacity= */ itemIds.length * 2);
    for (int id : itemIds) {
      activeReceiverIds.add(id);
    }

    for (int i = receiverItemIdToUid.size() - 1; i >= 0; i--) {
      int receiverId = receiverItemIdToUid.keyAt(i);
      if (!activeReceiverIds.contains(receiverId)) {
        ItemUid uid = receiverItemIdToUid.valueAt(i);
        receiverItemIdToUid.removeAt(i);
        uidToReceiverItemId.remove(uid);
        mediaItemsBySyntheticId.remove(uid);
        resolvedLiveByUid.remove(uid);
        resolvedDurationUsByUid.remove(uid);
        ItemData data = itemIdToData.remove(uid);
        if (data != null) {
          mediaItemsByContentId.remove(data.contentId);
        }
      }
    }
  }

  /**
   * Returns the {@link MediaItem} associated with the given {@link ItemUid} and {@link MediaInfo}.
   * The method tries to look up the media item using the {@link ItemUid} first and then the {@link
   * MediaInfo#getContentId()} if the {@link ItemUid} is not found.
   *
   * @param uid The {@link ItemUid} of the media item.
   * @param mediaInfo The {@link MediaInfo} of the media item.
   * @return The {@link MediaItem} associated with the given {@link ItemUid} and {@link MediaInfo},
   *     or {@code null} if not found.
   */
  private @Nullable MediaItem getMediaItem(ItemUid uid, @Nullable MediaInfo mediaInfo) {
    MediaItem mediaItem = mediaItemsBySyntheticId.get(uid);
    if (mediaItem != null) {
      return mediaItem;
    }
    ItemData itemData = itemIdToData.get(uid);
    if (itemData != null && itemData.mediaItem != MediaItem.EMPTY) {
      return itemData.mediaItem;
    }
    if (mediaInfo != null && mediaInfo.getContentId() != null) {
      return mediaItemsByContentId.get(mediaInfo.getContentId());
    }
    return null;
  }

  /**
   * Returns the existing {@link ItemUid} for {@code receiverItemId}, or creates and caches a new
   * one if none exists.
   */
  private ItemUid getOrCreateItemUid(int receiverItemId) {
    return getOrCreateItemUid(receiverItemId, /* mediaInfo= */ null);
  }

  /**
   * Returns the existing {@link ItemUid} for {@code receiverItemId}, or creates and caches a new
   * one using synthetic ID extracted from {@code mediaInfo} (or a randomly generated ID if not
   * present).
   */
  private ItemUid getOrCreateItemUid(int receiverItemId, @Nullable MediaInfo mediaInfo) {
    @Nullable ItemUid syntheticUid = getSyntheticItemUid(mediaInfo);
    @Nullable ItemUid uid = receiverItemIdToUid.get(receiverItemId);
    if (uid == null) {
      // First time seeing this receiverItemId: use syntheticUid from MediaInfo if available, or
      // generate a random UID (either as a temporary placeholder while MediaInfo is still being
      // fetched so CastTimeline can be populated with the full queue size and playing index, or
      // for items from a sender that does not attach synthetic IDs).
      uid = syntheticUid != null ? syntheticUid : ItemUid.generateItemUid();
    } else if (syntheticUid != null
        && !syntheticUid.equals(uid)
        && mediaItemsBySyntheticId.containsKey(syntheticUid)) {
      // This receiverItemId was initially assigned a temporary placeholder UID on an earlier pass
      // before MediaQueue finished fetching its MediaInfo. Because syntheticUid was registered by
      // this sender, maskedSnapshot is already using syntheticUid; swap the temporary UID to
      // match maskedSnapshot and prevent recomposition once fetches complete.
      uidToReceiverItemId.remove(uid);
      itemIdToData.remove(uid);
      resolvedLiveByUid.remove(uid);
      resolvedDurationUsByUid.remove(uid);
      uid = syntheticUid;
    } else {
      return uid;
    }
    receiverItemIdToUid.put(receiverItemId, uid);
    uidToReceiverItemId.put(uid, receiverItemId);
    return uid;
  }

  /**
   * Enriches the given {@link MediaQueueItem} by embedding the synthetic ID into its {@link
   * MediaInfo#getCustomData()} at the top-level under key {@code "m3-syntheticId"}. If {@code
   * customData} is {@code null}, indicating a custom converter, it is left unchanged.
   */
  private static MediaQueueItem attachSyntheticId(MediaQueueItem queueItem, ItemUid syntheticId) {
    MediaInfo mediaInfo = queueItem.getMedia();
    if (mediaInfo == null) {
      return queueItem;
    }
    JSONObject customData = mediaInfo.getCustomData();
    if (customData != null) {
      try {
        customData.put(KEY_SYNTHETIC_ID, syntheticId.toString());
      } catch (JSONException e) {
        Log.w(TAG, "Failed to attach syntheticId to customData");
      }
    }
    return queueItem;
  }

  private static @Nullable ItemUid getSyntheticItemUid(@Nullable MediaInfo mediaInfo) {
    if (mediaInfo == null) {
      return null;
    }
    @Nullable JSONObject customData = mediaInfo.getCustomData();
    if (customData == null || customData.isNull(KEY_SYNTHETIC_ID)) {
      return null;
    }
    String syntheticId = customData.optString(KEY_SYNTHETIC_ID);
    return !syntheticId.isEmpty() ? ItemUid.of(syntheticId) : null;
  }
}
