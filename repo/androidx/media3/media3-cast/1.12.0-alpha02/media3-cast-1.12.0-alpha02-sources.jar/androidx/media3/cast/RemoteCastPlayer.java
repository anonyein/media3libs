/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.cast;

import static android.os.Build.VERSION.SDK_INT;
import static androidx.media3.cast.CastTrackSelector.TRACK_SELECTION_REQUEST_REASON_INVALIDATION;
import static androidx.media3.cast.CastTrackSelector.TRACK_SELECTION_REQUEST_REASON_PARAMETER_CHANGE;
import static androidx.media3.cast.CastTrackSelector.TRACK_SELECTION_REQUEST_REASON_RECEIVER_UPDATE;
import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.base.Preconditions.checkState;
import static java.lang.Math.min;

import android.content.Context;
import android.media.MediaRouter2;
import android.media.MediaRouter2.RouteCallback;
import android.media.MediaRouter2.RoutingController;
import android.media.MediaRouter2.TransferCallback;
import android.media.RouteDiscoveryPreference;
import android.media.RoutingSessionInfo;
import android.os.Handler;
import android.os.Looper;
import android.util.Range;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.TextureView;
import androidx.annotation.DoNotInline;
import androidx.annotation.IntRange;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.VisibleForTesting;
import androidx.media3.cast.CastTrackSelector.CastTrackSelectorRequest;
import androidx.media3.cast.CastTrackSelector.CastTrackSelectorResult;
import androidx.media3.cast.CastTrackSelector.TrackSelectionRequestReason;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.BasePlayer;
import androidx.media3.common.C;
import androidx.media3.common.DeviceInfo;
import androidx.media3.common.Flags;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaLibraryInfo;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.PlaybackParameters;
import androidx.media3.common.Player;
import androidx.media3.common.PlayerTransferState;
import androidx.media3.common.Timeline;
import androidx.media3.common.TrackGroup;
import androidx.media3.common.TrackSelectionParameters;
import androidx.media3.common.Tracks;
import androidx.media3.common.VideoSize;
import androidx.media3.common.text.CueGroup;
import androidx.media3.common.util.Clock;
import androidx.media3.common.util.ListenerSet;
import androidx.media3.common.util.Log;
import androidx.media3.common.util.Size;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.common.util.Util;
import com.google.android.gms.cast.CastStatusCodes;
import com.google.android.gms.cast.MediaInfo;
import com.google.android.gms.cast.MediaQueueItem;
import com.google.android.gms.cast.MediaStatus;
import com.google.android.gms.cast.MediaTrack;
import com.google.android.gms.cast.framework.CastContext;
import com.google.android.gms.cast.framework.CastSession;
import com.google.android.gms.cast.framework.SessionManagerListener;
import com.google.android.gms.cast.framework.media.MediaQueue;
import com.google.android.gms.cast.framework.media.RemoteMediaClient;
import com.google.android.gms.cast.framework.media.RemoteMediaClient.MediaChannelResult;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.google.common.primitives.Longs;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.errorprone.annotations.InlineMe;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import org.checkerframework.checker.nullness.qual.RequiresNonNull;

/**
 * {@link Player} implementation that communicates with a Cast receiver app.
 *
 * <p>The behavior of this class depends on the underlying Cast session, which is obtained from the
 * injected {@link com.google.android.gms.cast.framework.CastContext}. To keep track of the session,
 * {@link #isCastSessionAvailable()} can be queried and {@link SessionAvailabilityListener} can be
 * implemented and attached to the player.
 *
 * <p>If no session is available, the player state will remain unchanged and calls to methods that
 * alter it will be ignored. Querying the player state is possible even when no session is
 * available, in which case, the last observed receiver app state is reported.
 *
 * <p>Methods should be called on the application's main thread.
 */
@SuppressWarnings("nullness") // TODO: b/78934030 - Add missing nullness checks to this class.
@UnstableApi
public final class RemoteCastPlayer extends BasePlayer {

  /**
   * A builder for {@link RemoteCastPlayer} instances.
   *
   * <p>See {@link #Builder(Context)} for the list of default values.
   */
  @UnstableApi
  public static final class Builder {

    private final Context context;
    private MediaItemConverter mediaItemConverter;
    @Nullable private CastTrackSelector trackSelector;
    private long seekBackIncrementMs;
    private long seekForwardIncrementMs;
    private long maxSeekToPreviousPositionMs;
    private boolean buildCalled;

    /**
     * Creates a builder.
     *
     * <p>The builder uses the following default values:
     *
     * <ul>
     *   <li>{@link MediaItemConverter}: {@link DefaultMediaItemConverter}.
     *   <li>{@link CastTrackSelector}: By default, {@link #COMMAND_SET_TRACK_SELECTION_PARAMETERS}
     *       is not supported, and therefore {@link #setTrackSelectionParameters} is a no-op.
     *       Calling {@link #setTrackSelector} makes {@link #COMMAND_SET_TRACK_SELECTION_PARAMETERS}
     *       allowed on the created {@link RemoteCastPlayer}, but the application responsible for
     *       implementing {@link CastTrackSelector#evaluate}.
     *   <li>{@link #setSeekBackIncrementMs}: {@link C#DEFAULT_SEEK_BACK_INCREMENT_MS}.
     *   <li>{@link #setSeekForwardIncrementMs}: {@link C#DEFAULT_SEEK_FORWARD_INCREMENT_MS}.
     *   <li>{@link #setMaxSeekToPreviousPositionMs}: {@link
     *       C#DEFAULT_MAX_SEEK_TO_PREVIOUS_POSITION_MS}.
     * </ul>
     *
     * @param context A {@link Context}.
     */
    public Builder(Context context) {
      this.context = context;
      mediaItemConverter = new DefaultMediaItemConverter();
      trackSelector = null;
      seekBackIncrementMs = C.DEFAULT_SEEK_BACK_INCREMENT_MS;
      seekForwardIncrementMs = C.DEFAULT_SEEK_FORWARD_INCREMENT_MS;
      maxSeekToPreviousPositionMs = C.DEFAULT_MAX_SEEK_TO_PREVIOUS_POSITION_MS;
    }

    /**
     * Sets the {@link MediaItemConverter} that will be used by the player to convert {@link
     * MediaItem MediaItems}.
     *
     * @param mediaItemConverter A {@link MediaItemConverter}.
     * @return This builder.
     * @throws IllegalStateException If {@link #build()} has already been called.
     */
    @CanIgnoreReturnValue
    public Builder setMediaItemConverter(MediaItemConverter mediaItemConverter) {
      checkState(!buildCalled);
      this.mediaItemConverter = checkNotNull(mediaItemConverter);
      return this;
    }

    /**
     * Sets the {@link CastTrackSelector} that will be used by the player to handle {@link
     * TrackSelectionParameters}.
     *
     * <p>Calling this setter enables {@link #COMMAND_SET_TRACK_SELECTION_PARAMETERS} for the
     * created {@link RemoteCastPlayer}.
     *
     * <p>The provided {@link CastTrackSelector} must take care of all options in {@link
     * TrackSelectionParameters} that the application uses.
     *
     * @param trackSelector A {@link CastTrackSelector}.
     * @return This builder.
     * @throws IllegalStateException If {@link #build()} has already been called.
     */
    @CanIgnoreReturnValue
    public Builder setTrackSelector(CastTrackSelector trackSelector) {
      checkState(!buildCalled);
      this.trackSelector = checkNotNull(trackSelector);
      return this;
    }

    /**
     * Sets the {@link #seekBack()} increment.
     *
     * @param seekBackIncrementMs The seek back increment, in milliseconds.
     * @return This builder.
     * @throws IllegalArgumentException If {@code seekBackIncrementMs} is non-positive.
     * @throws IllegalStateException If {@link #build()} has already been called.
     */
    @CanIgnoreReturnValue
    public Builder setSeekBackIncrementMs(@IntRange(from = 1) long seekBackIncrementMs) {
      checkArgument(seekBackIncrementMs > 0);
      checkState(!buildCalled);
      this.seekBackIncrementMs = seekBackIncrementMs;
      return this;
    }

    /**
     * Sets the {@link #seekForward()} increment.
     *
     * @param seekForwardIncrementMs The seek forward increment, in milliseconds.
     * @return This builder.
     * @throws IllegalArgumentException If {@code seekForwardIncrementMs} is non-positive.
     * @throws IllegalStateException If {@link #build()} has already been called.
     */
    @CanIgnoreReturnValue
    public Builder setSeekForwardIncrementMs(@IntRange(from = 1) long seekForwardIncrementMs) {
      checkArgument(seekForwardIncrementMs > 0);
      checkState(!buildCalled);
      this.seekForwardIncrementMs = seekForwardIncrementMs;
      return this;
    }

    /**
     * Sets the maximum position for which {@link #seekToPrevious()} seeks to the previous {@link
     * MediaItem}.
     *
     * @param maxSeekToPreviousPositionMs The maximum position, in milliseconds.
     * @return This builder.
     * @throws IllegalArgumentException If {@code maxSeekToPreviousPositionMs} is negative.
     * @throws IllegalStateException If {@link #build()} has already been called.
     */
    @CanIgnoreReturnValue
    public Builder setMaxSeekToPreviousPositionMs(
        @IntRange(from = 0) long maxSeekToPreviousPositionMs) {
      checkArgument(maxSeekToPreviousPositionMs >= 0L);
      checkState(!buildCalled);
      this.maxSeekToPreviousPositionMs = maxSeekToPreviousPositionMs;
      return this;
    }

    /**
     * Builds and returns a {@link RemoteCastPlayer} instance.
     *
     * @throws IllegalStateException If any of the following condition occurs:
     *     <ul>
     *       <li>This method has already been called.
     *       <li>The {@link Cast} has not been initialized via {@link Cast#initialize()} before this
     *           method is called.
     *     </ul>
     */
    public RemoteCastPlayer build() {
      checkState(!buildCalled);
      buildCalled = true;
      return new RemoteCastPlayer(this);
    }
  }

  /**
   * Maximum volume to use for {@link #getDeviceVolume()} and {@link #setDeviceVolume}.
   *
   * <p>These methods are implemented around {@link CastSession#setVolume} and {@link
   * CastSession#getVolume} which operate on a {@code [0, 1]} range. So this value allows us to
   * convert to and from the int-based volume scale that {@link #getDeviceVolume()} uses.
   */
  private static final int MAX_VOLUME = 20;

  /**
   * A {@link DeviceInfo#PLAYBACK_TYPE_REMOTE remote} {@link DeviceInfo} with a null {@link
   * DeviceInfo#routingControllerId}.
   */
  public static final DeviceInfo DEVICE_INFO_REMOTE_EMPTY =
      new DeviceInfo.Builder(DeviceInfo.PLAYBACK_TYPE_REMOTE).setMaxVolume(MAX_VOLUME).build();

  private static final Range<Integer> RANGE_DEVICE_VOLUME = new Range<>(0, MAX_VOLUME);
  private static final Range<Float> RANGE_VOLUME = new Range<>(0.f, 1.f);

  static {
    MediaLibraryInfo.registerModule("media3.cast");
  }

  // Deprecated commands are still available, e.g. COMMAND_ADJUST_DEVICE_VOLUME
  @SuppressWarnings("deprecation")
  @VisibleForTesting
  /* package */ static final Commands PERMANENT_AVAILABLE_COMMANDS =
      new Commands.Builder()
          .addAll(
              COMMAND_PLAY_PAUSE,
              COMMAND_PREPARE,
              COMMAND_STOP,
              COMMAND_SEEK_TO_DEFAULT_POSITION,
              COMMAND_SEEK_TO_MEDIA_ITEM,
              COMMAND_GET_DEVICE_VOLUME,
              COMMAND_ADJUST_DEVICE_VOLUME,
              COMMAND_ADJUST_DEVICE_VOLUME_WITH_FLAGS,
              COMMAND_SET_DEVICE_VOLUME,
              COMMAND_SET_DEVICE_VOLUME_WITH_FLAGS,
              COMMAND_SET_REPEAT_MODE,
              COMMAND_SET_SPEED_AND_PITCH,
              COMMAND_GET_CURRENT_MEDIA_ITEM,
              COMMAND_GET_TIMELINE,
              COMMAND_GET_METADATA,
              COMMAND_SET_PLAYLIST_METADATA,
              COMMAND_SET_MEDIA_ITEM,
              COMMAND_CHANGE_MEDIA_ITEMS,
              COMMAND_GET_TRACKS,
              COMMAND_RELEASE)
          .build();

  public static final float MIN_SPEED_SUPPORTED = 0.5f;
  public static final float MAX_SPEED_SUPPORTED = 2.0f;

  private static final String TAG = "RemoteCastPlayer";

  private static final long PROGRESS_REPORT_PERIOD_MS = 1000;
  private static final long[] EMPTY_TRACK_ID_ARRAY = new long[0];

  /**
   * GMS error code 2055 corresponds to {@link CastStatusCodes#APPLICATION_STOPPED}. This value is
   * not part of the public API but is used when the receiver application stops.
   */
  @VisibleForTesting /* package */ static final int APPLICATION_STOPPED = 2055;

  /**
   * GMS error code 2155 corresponds to {@link
   * CastStatusCodes#SESSION_ENDED_WITH_REASON_ROUTE_CHANGED}. This value is not part of the public
   * API but is used when the route playing the media is changed.
   */
  @VisibleForTesting /* package */ static final int SESSION_END_REASON_ROUTE_CHANGE = 2155;

  /**
   * GMS error code 2154 corresponds to {@link CastStatusCodes#SESSION_ENDED_WITH_REASON_STOPPED}.
   * This value is not part of the public API but is used when the stop casting button is pressed.
   */
  @VisibleForTesting /* package */ static final int SESSION_END_REASON_STOPPED = 2154;

  private final Cast cast;
  private final MediaItemConverter mediaItemConverter;
  @Nullable private final CastTrackSelector trackSelector;
  @Nullable private CastTrackSelectorRequest lastSelectionRequest;
  private final long seekBackIncrementMs;
  private final long seekForwardIncrementMs;
  private final long maxSeekToPreviousPositionMs;
  private final Timeline.Period period;
  @Nullable private final Api30Impl api30Impl;

  // Result callbacks.
  private final com.google.android.gms.cast.Cast.Listener castListener;

  private final StatusListener statusListener;
  private final MediaQueue.Callback mediaQueueCallback;

  // Listeners and notification.
  private final ListenerSet<Listener> listeners;
  @Nullable private SessionAvailabilityListener sessionAvailabilityListener;
  @Nullable private SessionAvailabilityListener internalSessionAvailabilityListener;

  // Internal state.
  private final StateHolder<Boolean> playWhenReady;
  private final StateHolder<Integer> repeatMode;
  private boolean isMuted;
  private boolean isSessionEnding;
  private int deviceVolume;
  private final StateHolder<Float> volume;
  private float unmuteVolume;
  private final StateHolder<PlaybackParameters> playbackParameters;
  @Nullable private CastSession castSession;
  @Nullable private RemoteMediaClient remoteMediaClient;
  private final CastQueueOrchestrator queueOrchestrator;
  private QueuedOperation.QueueSnapshot currentQueueSnapshot;
  private final StateHolder<Tracks> currentTracks;
  private final StateHolder<TrackSelectionParameters> trackSelectionParameters;
  private Commands availableCommands;
  private @Player.State int playbackState;
  private long lastReportedPositionMs;
  private MediaMetadata mediaMetadata;
  private MediaMetadata playlistMetadata;
  private DeviceInfo deviceInfo;

  /** Creates a new instance. */
  private RemoteCastPlayer(Builder builder) {
    this(
        builder.context,
        Cast.getSingletonInstance(builder.context),
        builder.mediaItemConverter,
        builder.trackSelector,
        builder.seekBackIncrementMs,
        builder.seekForwardIncrementMs,
        builder.maxSeekToPreviousPositionMs);
  }

  /**
   * Constructor.
   *
   * <p>Necessary to keep {@link CastPlayer#CastPlayer(Context, CastContext, MediaItemConverter,
   * long, long, long)} part of the API, for backwards compatibility.
   */
  /* package */ RemoteCastPlayer(
      @Nullable Context context,
      Cast cast,
      MediaItemConverter mediaItemConverter,
      @Nullable CastTrackSelector trackSelector,
      @IntRange(from = 1) long seekBackIncrementMs,
      @IntRange(from = 1) long seekForwardIncrementMs,
      @IntRange(from = 0) long maxSeekToPreviousPositionMs) {
    checkArgument(seekBackIncrementMs > 0 && seekForwardIncrementMs > 0);
    checkArgument(maxSeekToPreviousPositionMs >= 0L);
    Log.i(
        TAG,
        "Init "
            + Integer.toHexString(System.identityHashCode(this))
            + " ["
            + MediaLibraryInfo.VERSION_SLASHY
            + "] ["
            + Util.DEVICE_DEBUG_INFO
            + "] "
            + Flags.getLogString());
    this.cast = cast;
    this.mediaItemConverter = mediaItemConverter;
    this.trackSelector = trackSelector;
    this.seekBackIncrementMs = seekBackIncrementMs;
    this.seekForwardIncrementMs = seekForwardIncrementMs;
    this.maxSeekToPreviousPositionMs = maxSeekToPreviousPositionMs;
    queueOrchestrator =
        new CastQueueOrchestrator(
            () -> PlayerTransferState.fromPlayer(this),
            mediaItemConverter,
            this::onQueueSnapshotChanged);
    currentQueueSnapshot = QueuedOperation.QueueSnapshot.EMPTY;
    period = new Timeline.Period();
    castListener = new CastListener();
    statusListener = new StatusListener();
    mediaQueueCallback = new MediaQueueCallback();
    listeners =
        new ListenerSet<>(
            Looper.getMainLooper(),
            Clock.DEFAULT,
            (listener, flags) -> listener.onEvents(/* player= */ this, new Events(flags)));
    playWhenReady = new StateHolder<>(false);
    repeatMode = new StateHolder<>(REPEAT_MODE_OFF);
    deviceVolume = MAX_VOLUME;
    volume = new StateHolder<>(1f);
    unmuteVolume = 1f;
    playbackParameters = new StateHolder<>(PlaybackParameters.DEFAULT);
    playbackState = STATE_IDLE;
    mediaMetadata = MediaMetadata.EMPTY;
    playlistMetadata = MediaMetadata.EMPTY;
    currentTracks = new StateHolder<>(Tracks.EMPTY);
    availableCommands =
        new Commands.Builder()
            .addAll(PERMANENT_AVAILABLE_COMMANDS)
            .addIf(COMMAND_SET_TRACK_SELECTION_PARAMETERS, trackSelector != null)
            .build();
    trackSelectionParameters = new StateHolder<>(TrackSelectionParameters.DEFAULT);

    if (context != null) {
      cast.ensureInitialized(context);
    }
    cast.addSessionManagerListener(statusListener);
    setCastSession(cast.getCurrentCastSession());
    updateInternalStateAndNotifyIfChanged();
    if (SDK_INT >= 30 && context != null) {
      api30Impl = new Api30Impl(context);
      api30Impl.initialize();
      deviceInfo = api30Impl.fetchDeviceInfo();
    } else {
      api30Impl = null;
      deviceInfo = fetchDeviceInfoFallback();
    }
    if (trackSelector != null) {
      trackSelector.init(this::onTrackSelectionInvalidated);
    }
  }

  /**
   * Called by the {@link CastTrackSelector} to trigger a new call to {@link
   * CastTrackSelector#evaluate}.
   */
  private void onTrackSelectionInvalidated() {
    updateTracksAndNotifyIfChanged(
        /* resultCallback= */ null, TRACK_SELECTION_REQUEST_REASON_INVALIDATION);
    listeners.flushEvents();
  }

  // TODO: b/549537517 - Remove this method once deprecation cycle is complete.
  /**
   * Returns the item that corresponds to the period with the given id, or null if no media queue or
   * period with id {@code periodId} exist.
   *
   * @param periodId The id of the period ({@link #getCurrentTimeline}) that corresponds to the item
   *     to get.
   * @return The item that corresponds to the period with the given id, or null if no media queue or
   *     period with id {@code periodId} exist.
   * @deprecated Use {@link #getCurrentTimeline()} to get {@link Timeline.Window#mediaItem} via
   *     {@link Timeline#getPeriodByUid(Object, Timeline.Period)} and {@link Timeline#getWindow(int,
   *     Timeline.Window)}.
   */
  @Deprecated
  @Nullable
  public MediaQueueItem getItem(int periodId) {
    MediaStatus mediaStatus = getMediaStatus();
    return mediaStatus != null
            && getCurrentTimeline().getIndexOfPeriod(queueOrchestrator.getItemUid(periodId))
                != C.INDEX_UNSET
        ? mediaStatus.getItemById(periodId)
        : null;
  }

  // CastSession methods.

  /** Returns whether a cast session is available. */
  public boolean isCastSessionAvailable() {
    return remoteMediaClient != null;
  }

  /**
   * Sets a listener for updates on the cast session availability.
   *
   * @param listener The {@link SessionAvailabilityListener}, or null to clear the listener.
   */
  public void setSessionAvailabilityListener(@Nullable SessionAvailabilityListener listener) {
    sessionAvailabilityListener = listener;
  }

  /**
   * Equivalent to {@link #setSessionAvailabilityListener}, except it's not part of the API.
   *
   * <p>Intended to be called from {@link CastPlayerImpl} without overriding any listeners set by
   * the app, so as to avoid breaking the API.
   */
  /* package */ void setInternalSessionAvailabilityListener(
      @Nullable SessionAvailabilityListener listener) {
    internalSessionAvailabilityListener = listener;
  }

  // Player implementation.

  @Override
  public Looper getApplicationLooper() {
    return Looper.getMainLooper();
  }

  @Override
  public void addListener(Listener listener) {
    listeners.add(listener);
  }

  @Override
  public void removeListener(Listener listener) {
    listeners.remove(listener);
  }

  @Override
  public void setMediaItems(List<MediaItem> mediaItems, boolean resetPosition) {
    int mediaItemIndex = resetPosition ? 0 : getCurrentMediaItemIndex();
    long startPositionMs = resetPosition ? C.TIME_UNSET : getContentPosition();
    setMediaItems(mediaItems, mediaItemIndex, startPositionMs);
  }

  @Override
  public void setMediaItems(List<MediaItem> mediaItems, int startIndex, long startPositionMs) {
    if (!isCastSessionActive() || mediaItems.isEmpty()) {
      return;
    }
    startPositionMs = startPositionMs == C.TIME_UNSET ? 0 : startPositionMs;
    if (startIndex == C.INDEX_UNSET) {
      startIndex = getCurrentMediaItemIndex();
      startPositionMs = getCurrentPosition();
    }
    int newWindowIndex = min(startIndex, mediaItems.size() - 1);
    QueuedOperation.SetMediaItemsOperation operation =
        new QueuedOperation.SetMediaItemsOperation(
            ImmutableList.copyOf(mediaItems), newWindowIndex, startPositionMs);
    queueOrchestrator.enqueue(operation, remoteMediaClient);
  }

  @Override
  public void addMediaItems(int index, List<MediaItem> mediaItems) {
    checkArgument(index >= 0);
    if (!isCastSessionActive() || mediaItems.isEmpty()) {
      return;
    }
    CastTimeline currentTimeline = currentQueueSnapshot.timeline;
    int clampedIndex = min(index, currentTimeline.getWindowCount());
    @Nullable
    Object insertBeforeUid =
        clampedIndex < currentTimeline.getWindowCount()
            ? currentTimeline.getWindow(clampedIndex, window).uid
            : null;
    QueuedOperation.AddMediaItemsOperation operation =
        new QueuedOperation.AddMediaItemsOperation(
            insertBeforeUid, ImmutableList.copyOf(mediaItems));
    queueOrchestrator.enqueue(operation, remoteMediaClient);
  }

  @Override
  public void moveMediaItems(int fromIndex, int toIndex, int newIndex) {
    checkArgument(fromIndex >= 0 && fromIndex <= toIndex && newIndex >= 0);
    if (!isCastSessionActive()) {
      return;
    }
    CastTimeline currentTimeline = currentQueueSnapshot.timeline;
    int playlistSize = currentTimeline.getWindowCount();
    int resolvedToIndex = min(toIndex, playlistSize);
    int moveCount = resolvedToIndex - fromIndex;
    int resolvedNewIndex = min(newIndex, playlistSize - moveCount);
    if (fromIndex >= playlistSize
        || fromIndex == resolvedToIndex
        || fromIndex == resolvedNewIndex) {
      // Do nothing.
      return;
    }
    List<Object> uidsToMove = new ArrayList<>(moveCount);
    for (int i = fromIndex; i < resolvedToIndex; i++) {
      uidsToMove.add(currentTimeline.getWindow(i, window).uid);
    }
    int insertBeforeIndex =
        fromIndex < resolvedNewIndex ? resolvedNewIndex + moveCount : resolvedNewIndex;
    @Nullable
    Object insertBeforeUid =
        insertBeforeIndex < playlistSize
            ? currentTimeline.getWindow(insertBeforeIndex, window).uid
            : null;
    QueuedOperation.MoveMediaItemsOperation operation =
        new QueuedOperation.MoveMediaItemsOperation(uidsToMove, insertBeforeUid);
    queueOrchestrator.enqueue(operation, remoteMediaClient);
  }

  @Override
  public void replaceMediaItems(int fromIndex, int toIndex, List<MediaItem> mediaItems) {
    checkArgument(fromIndex >= 0 && fromIndex <= toIndex);
    int playlistSize = getCurrentTimeline().getWindowCount();
    if (fromIndex > playlistSize) {
      return;
    }
    toIndex = min(toIndex, playlistSize);
    addMediaItems(toIndex, mediaItems);
    removeMediaItems(fromIndex, toIndex);
  }

  @Override
  public void removeMediaItems(int fromIndex, int toIndex) {
    checkArgument(fromIndex >= 0 && toIndex >= fromIndex);
    if (!isCastSessionActive()) {
      return;
    }
    CastTimeline currentTimeline = currentQueueSnapshot.timeline;
    int playlistSize = currentTimeline.getWindowCount();
    int resolvedToIndex = min(toIndex, playlistSize);
    if (fromIndex >= playlistSize || fromIndex == resolvedToIndex) {
      // Do nothing.
      return;
    }
    List<Object> uidsToRemove = new ArrayList<>(resolvedToIndex - fromIndex);
    for (int i = fromIndex; i < resolvedToIndex; i++) {
      uidsToRemove.add(currentTimeline.getWindow(i, window).uid);
    }
    QueuedOperation.RemoveMediaItemsOperation operation =
        new QueuedOperation.RemoveMediaItemsOperation(uidsToRemove);
    queueOrchestrator.enqueue(operation, remoteMediaClient);
  }

  @Override
  public Commands getAvailableCommands() {
    return availableCommands;
  }

  @Override
  public void prepare() {
    // Do nothing.
  }

  @Override
  public @Player.State int getPlaybackState() {
    // The Player interface requires the state to be idle when the timeline is empty. However, the
    // CastSDK will sometimes enter buffering state before the queue is populated. To prevent
    // clients from observing this discrepancy, we only transition out of idle once the timeline is
    // populated.
    return getCurrentTimeline().isEmpty() ? STATE_IDLE : playbackState;
  }

  @Override
  public @PlaybackSuppressionReason int getPlaybackSuppressionReason() {
    return Player.PLAYBACK_SUPPRESSION_REASON_NONE;
  }

  @Override
  @Nullable
  public PlaybackException getPlayerError() {
    return null;
  }

  @Override
  public void setPlayWhenReady(boolean playWhenReady) {
    if (!isCastSessionActive()) {
      return;
    }
    // We update the local state and send the message to the receiver app, which will cause the
    // operation to be perceived as synchronous by the user. When the operation reports a result,
    // the local state will be updated to reflect the state reported by the Cast SDK.
    setPlayerStateAndNotifyIfChanged(
        playWhenReady, PLAY_WHEN_READY_CHANGE_REASON_USER_REQUEST, playbackState);
    listeners.flushEvents();
    if (getMediaStatus() == null || CastUtils.hasQueueEnded(remoteMediaClient)) {
      // No media status means that both play and pause will fail, causing playWhenReady to be reset
      // to true. By not calling play/pause, the playWhenReady state holder remains populated until
      // either:
      // - It's overwritten by an eventual media status update.
      // - It's used to populate autoplay when the client loads media.
      return;
    }
    PendingResult<MediaChannelResult> pendingResult =
        playWhenReady ? remoteMediaClient.play() : remoteMediaClient.pause();
    this.playWhenReady.pendingResultCallback =
        new ResultCallback<MediaChannelResult>() {
          @Override
          public void onResult(MediaChannelResult mediaChannelResult) {
            logOperationFailedIfStatusError("Set playWhenReady", mediaChannelResult);
            if (remoteMediaClient != null) {
              updatePlayerStateAndNotifyIfChanged(this);
              listeners.flushEvents();
            }
          }
        };
    pendingResult.setResultCallback(this.playWhenReady.pendingResultCallback);
  }

  @Override
  public boolean getPlayWhenReady() {
    return playWhenReady.value;
  }

  // We still call Listener#onPositionDiscontinuity(@DiscontinuityReason int) for backwards
  // compatibility with listeners that don't implement
  // onPositionDiscontinuity(PositionInfo, PositionInfo, @DiscontinuityReason int).
  @SuppressWarnings("deprecation")
  @Override
  protected void seekTo(
      int mediaItemIndex,
      long positionMs,
      @Player.Command int seekCommand,
      boolean isRepeatingCurrentItem) {
    if (mediaItemIndex == C.INDEX_UNSET) {
      return;
    }
    checkArgument(mediaItemIndex >= 0);
    Timeline currentTimeline = getCurrentTimeline();
    if (currentTimeline.isEmpty() || mediaItemIndex >= currentTimeline.getWindowCount()) {
      return;
    }
    // We assume the default position is 0. There is no support for seeking to the default position
    // in RemoteMediaClient.
    positionMs = positionMs != C.TIME_UNSET ? positionMs : 0;
    if (isCastSessionActive()) {
      boolean isWindowChange = getCurrentMediaItemIndex() != mediaItemIndex;
      Object targetPeriodUid = currentTimeline.getUidOfPeriod(mediaItemIndex);
      PositionInfo oldPosition = getCurrentPositionInfo();
      QueuedOperation.SeekOperation seekOperation =
          new QueuedOperation.SeekOperation(positionMs, targetPeriodUid, isWindowChange);
      queueOrchestrator.enqueue(seekOperation, remoteMediaClient);
      PositionInfo newPosition = getCurrentPositionInfo();
      listeners.queueEvent(
          Player.EVENT_POSITION_DISCONTINUITY,
          listener -> {
            listener.onPositionDiscontinuity(DISCONTINUITY_REASON_SEEK);
            listener.onPositionDiscontinuity(oldPosition, newPosition, DISCONTINUITY_REASON_SEEK);
          });
      if (oldPosition.mediaItemIndex != newPosition.mediaItemIndex) {
        // TODO(internal b/182261884): queue `onMediaItemTransition` event when the media item is
        // repeated.
        MediaItem mediaItem = getCurrentTimeline().getWindow(mediaItemIndex, window).mediaItem;
        listeners.queueEvent(
            Player.EVENT_MEDIA_ITEM_TRANSITION,
            listener ->
                listener.onMediaItemTransition(mediaItem, MEDIA_ITEM_TRANSITION_REASON_SEEK));
        MediaMetadata oldMediaMetadata = mediaMetadata;
        mediaMetadata = getMediaMetadataInternal();
        if (!oldMediaMetadata.equals(mediaMetadata)) {
          listeners.queueEvent(
              Player.EVENT_MEDIA_METADATA_CHANGED,
              listener -> listener.onMediaMetadataChanged(mediaMetadata));
        }
      }
      if (CastUtils.hasQueueEnded(remoteMediaClient)) {
        setPlayerStateAndNotifyIfChanged(
            playWhenReady.value,
            PLAY_WHEN_READY_CHANGE_REASON_USER_REQUEST,
            fetchPlaybackState(remoteMediaClient));
      }
      updateAvailableCommandsAndNotifyIfChanged();
    }
    listeners.flushEvents();
  }

  @Override
  public long getSeekBackIncrement() {
    return seekBackIncrementMs;
  }

  @Override
  public long getSeekForwardIncrement() {
    return seekForwardIncrementMs;
  }

  @Override
  public long getMaxSeekToPreviousPosition() {
    return maxSeekToPreviousPositionMs;
  }

  @Override
  public PlaybackParameters getPlaybackParameters() {
    return playbackParameters.value;
  }

  @Override
  public void stop() {
    playbackState = STATE_IDLE;
    if (isCastSessionActive()) {
      // TODO(b/69792021): Support or emulate stop without position reset.
      remoteMediaClient.stop();
    }
  }

  @Override
  public void release() {
    Log.i(
        TAG,
        "Release "
            + Integer.toHexString(System.identityHashCode(this))
            + " ["
            + MediaLibraryInfo.VERSION_SLASHY
            + "] ["
            + Util.DEVICE_DEBUG_INFO
            + "] ["
            + MediaLibraryInfo.registeredModules()
            + "]");
    // The SDK_INT check is not necessary, but it prevents a lint error for the release call.
    if (SDK_INT >= 30 && api30Impl != null) {
      api30Impl.release();
    }
    cast.removeSessionManagerListener(statusListener);
    cast.endCurrentSession(false);
  }

  @Override
  public void setPlaybackParameters(PlaybackParameters playbackParameters) {
    if (!isCastSessionActive()) {
      return;
    }
    PlaybackParameters actualPlaybackParameters =
        new PlaybackParameters(
            Util.constrainValue(
                playbackParameters.speed, MIN_SPEED_SUPPORTED, MAX_SPEED_SUPPORTED));
    setPlaybackParametersAndNotifyIfChanged(actualPlaybackParameters);
    listeners.flushEvents();
    if (getMediaStatus() == null || CastUtils.hasQueueEnded(remoteMediaClient)) {
      return;
    }
    PendingResult<MediaChannelResult> pendingResult =
        remoteMediaClient.setPlaybackRate(actualPlaybackParameters.speed, /* customData= */ null);
    this.playbackParameters.pendingResultCallback =
        new ResultCallback<MediaChannelResult>() {
          @Override
          public void onResult(MediaChannelResult mediaChannelResult) {
            logOperationFailedIfStatusError("Set playback parameters", mediaChannelResult);
            if (remoteMediaClient != null) {
              updatePlaybackRateAndNotifyIfChanged(this);
              listeners.flushEvents();
            }
          }
        };
    pendingResult.setResultCallback(this.playbackParameters.pendingResultCallback);
  }

  @Override
  public void setRepeatMode(@RepeatMode int repeatMode) {
    if (!isCastSessionActive()) {
      return;
    }
    // We update the local state and send the message to the receiver app, which will cause the
    // operation to be perceived as synchronous by the user. When the operation reports a result,
    // the local state will be updated to reflect the state reported by the Cast SDK.
    setRepeatModeAndNotifyIfChanged(repeatMode);
    listeners.flushEvents();
    if (getMediaStatus() == null || CastUtils.hasQueueEnded(remoteMediaClient)) {
      return;
    }
    PendingResult<MediaChannelResult> pendingResult =
        remoteMediaClient.queueSetRepeatMode(getCastRepeatMode(repeatMode), /* customData= */ null);
    this.repeatMode.pendingResultCallback =
        new ResultCallback<MediaChannelResult>() {
          @Override
          public void onResult(MediaChannelResult mediaChannelResult) {
            logOperationFailedIfStatusError("Set repeat mode", mediaChannelResult);
            if (remoteMediaClient != null) {
              updateRepeatModeAndNotifyIfChanged(this);
              listeners.flushEvents();
            }
          }
        };
    pendingResult.setResultCallback(this.repeatMode.pendingResultCallback);
  }

  @Override
  public @RepeatMode int getRepeatMode() {
    return repeatMode.value;
  }

  @Override
  public void setShuffleModeEnabled(boolean shuffleModeEnabled) {
    // TODO: Support shuffle mode.
  }

  @Override
  public boolean getShuffleModeEnabled() {
    // TODO: Support shuffle mode.
    return false;
  }

  @Override
  public Tracks getCurrentTracks() {
    return currentTracks.value;
  }

  @Override
  public TrackSelectionParameters getTrackSelectionParameters() {
    return trackSelectionParameters.value;
  }

  @Override
  public void setTrackSelectionParameters(TrackSelectionParameters parameters) {
    if (trackSelector == null) {
      return;
    }
    setTrackSelectionParametersAndNotifyIfChanged(parameters);
    updateTracksAndNotifyIfChanged(
        /* resultCallback= */ null, TRACK_SELECTION_REQUEST_REASON_PARAMETER_CHANGE);
    listeners.flushEvents();
  }

  @Override
  public MediaMetadata getMediaMetadata() {
    return mediaMetadata;
  }

  @Override
  public MediaMetadata getPlaylistMetadata() {
    return playlistMetadata;
  }

  @Override
  public void setPlaylistMetadata(MediaMetadata playlistMetadata) {
    checkNotNull(playlistMetadata);
    if (playlistMetadata.equals(this.playlistMetadata)) {
      return;
    }
    this.playlistMetadata = playlistMetadata;
    listeners.sendEvent(
        EVENT_PLAYLIST_METADATA_CHANGED,
        listener -> listener.onPlaylistMetadataChanged(this.playlistMetadata));
  }

  @Override
  public Timeline getCurrentTimeline() {
    return currentQueueSnapshot.timeline;
  }

  @Override
  public int getCurrentPeriodIndex() {
    return getCurrentMediaItemIndex();
  }

  @Override
  public int getCurrentMediaItemIndex() {
    return currentQueueSnapshot.currentWindowIndex;
  }

  // TODO: Fill the cast timeline information with ProgressListener's duration updates.
  // See [Internal: b/65152553].
  @Override
  public long getDuration() {
    return getContentDuration();
  }

  @Override
  public long getCurrentPosition() {
    long maskedPositionMs = currentQueueSnapshot.maskedPositionMs;
    if (maskedPositionMs != C.TIME_UNSET) {
      return maskedPositionMs;
    }
    if (playbackState == STATE_ENDED) {
      long durationMs = getDuration();
      if (durationMs != C.TIME_UNSET) {
        return durationMs;
      }
    }
    return isCastSessionActive()
        ? remoteMediaClient.getApproximateStreamPosition()
        : lastReportedPositionMs;
  }

  @Override
  public long getBufferedPosition() {
    return getCurrentPosition();
  }

  @Override
  public long getTotalBufferedDuration() {
    long bufferedPosition = getBufferedPosition();
    long currentPosition = getCurrentPosition();
    return bufferedPosition == C.TIME_UNSET || currentPosition == C.TIME_UNSET
        ? 0
        : bufferedPosition - currentPosition;
  }

  @Override
  public boolean isPlayingAd() {
    return false;
  }

  @Override
  public int getCurrentAdGroupIndex() {
    return C.INDEX_UNSET;
  }

  @Override
  public int getCurrentAdIndexInAdGroup() {
    return C.INDEX_UNSET;
  }

  @Override
  public boolean isLoading() {
    return false;
  }

  @Override
  public long getContentPosition() {
    return getCurrentPosition();
  }

  @Override
  public long getContentBufferedPosition() {
    return getBufferedPosition();
  }

  /** This method is not supported and returns {@link AudioAttributes#DEFAULT}. */
  @Override
  public AudioAttributes getAudioAttributes() {
    return AudioAttributes.DEFAULT;
  }

  @Override
  public void setVolume(float volume) {
    if (!isCastSessionActive()) {
      return;
    }
    // We update the local state and send the message to the receiver app, which will cause the
    // operation to be perceived as synchronous by the user. When the operation reports a result,
    // the local state will be updated to reflect the state reported by the Cast SDK.
    volume = RANGE_VOLUME.clamp(volume);
    setVolumeAndNotifyIfChanged(volume);
    listeners.flushEvents();
    PendingResult<MediaChannelResult> pendingResult = remoteMediaClient.setStreamVolume(volume);
    this.volume.pendingResultCallback =
        new ResultCallback<MediaChannelResult>() {
          @Override
          public void onResult(MediaChannelResult result) {
            logOperationFailedIfStatusError("Set volume", result);
            if (remoteMediaClient != null) {
              updateVolumeAndNotifyIfChanged(this);
              listeners.flushEvents();
            }
          }
        };
    pendingResult.setResultCallback(this.volume.pendingResultCallback);
  }

  @Override
  public float getVolume() {
    return volume.value;
  }

  @Override
  public void mute() {
    if (volume.value != 0) {
      setMute(true);
    }
  }

  @Override
  public void unmute() {
    if (volume.value == 0 && unmuteVolume != 0) {
      setMute(false);
    }
  }

  private void setMute(boolean muted) {
    if (!isCastSessionActive()) {
      return;
    }
    float newVolume = muted ? 0f : unmuteVolume;
    setVolumeAndNotifyIfChanged(newVolume);
    listeners.flushEvents();
    PendingResult<MediaChannelResult> pendingResult = remoteMediaClient.setStreamMute(muted);
    if (!muted) {
      // Always restore stream volume when unmuting to handle both mute() and organic setVolume(0)
      // calls. Reassign pendingResult so the result callback attaches to the final async call.
      pendingResult = remoteMediaClient.setStreamVolume(unmuteVolume);
    }
    this.volume.pendingResultCallback =
        new ResultCallback<MediaChannelResult>() {
          @Override
          public void onResult(MediaChannelResult result) {
            logOperationFailedIfStatusError("Set mute", result);
            if (remoteMediaClient != null) {
              updateVolumeAndNotifyIfChanged(this);
              listeners.flushEvents();
            }
          }
        };
    pendingResult.setResultCallback(this.volume.pendingResultCallback);
  }

  /** This method is not supported and does nothing. */
  @Override
  public void clearVideoSurface() {}

  /** This method is not supported and does nothing. */
  @Override
  public void clearVideoSurface(@Nullable Surface surface) {}

  /** This method is not supported and does nothing. */
  @Override
  public void setVideoSurface(@Nullable Surface surface) {}

  /** This method is not supported and does nothing. */
  @Override
  public void setVideoSurfaceHolder(@Nullable SurfaceHolder surfaceHolder) {}

  /** This method is not supported and does nothing. */
  @Override
  public void clearVideoSurfaceHolder(@Nullable SurfaceHolder surfaceHolder) {}

  /** This method is not supported and does nothing. */
  @Override
  public void setVideoSurfaceView(@Nullable SurfaceView surfaceView) {}

  /** This method is not supported and does nothing. */
  @Override
  public void clearVideoSurfaceView(@Nullable SurfaceView surfaceView) {}

  /** This method is not supported and does nothing. */
  @Override
  public void setVideoTextureView(@Nullable TextureView textureView) {}

  /** This method is not supported and does nothing. */
  @Override
  public void clearVideoTextureView(@Nullable TextureView textureView) {}

  /** This method is not supported and returns {@link VideoSize#UNKNOWN}. */
  @Override
  public VideoSize getVideoSize() {
    return VideoSize.UNKNOWN;
  }

  /** This method is not supported and returns {@link Size#UNKNOWN}. */
  @Override
  public Size getSurfaceSize() {
    return Size.UNKNOWN;
  }

  /** This method is not supported and returns an empty {@link CueGroup}. */
  @Override
  public CueGroup getCurrentCues() {
    return CueGroup.EMPTY_TIME_ZERO;
  }

  /**
   * Returns a {@link DeviceInfo} describing the receiver device. Returns {@link
   * #DEVICE_INFO_REMOTE_EMPTY} if no {@link Context} was provided at construction, or if the Cast
   * {@link RoutingController} could not be identified.
   */
  @Override
  public DeviceInfo getDeviceInfo() {
    return deviceInfo;
  }

  @Override
  public int getDeviceVolume() {
    return deviceVolume;
  }

  @Override
  public boolean isDeviceMuted() {
    return isMuted;
  }

  /**
   * @deprecated Use {@link #setDeviceVolume(int, int)} instead.
   */
  @InlineMe(replacement = "this.setDeviceVolume(volume, 0)")
  @Deprecated
  @Override
  public void setDeviceVolume(@IntRange(from = 0) int volume) {
    setDeviceVolume(volume, /* flags= */ 0);
  }

  @Override
  public void setDeviceVolume(@IntRange(from = 0) int volume, @C.VolumeFlags int flags) {
    if (castSession == null) {
      return;
    }
    volume = RANGE_DEVICE_VOLUME.clamp(volume);
    try {
      // See [Internal ref: b/399691860] for context on why we don't use
      // RemoteMediaClient.setStreamVolume.
      castSession.setVolume((float) volume / MAX_VOLUME);
    } catch (IOException e) {
      Log.w(TAG, "Ignoring setDeviceVolume due to exception", e);
      return;
    }
    setDeviceVolumeAndNotifyIfChanged(volume, isMuted);
    listeners.flushEvents();
  }

  /**
   * @deprecated Use {@link #increaseDeviceVolume(int)} instead.
   */
  @InlineMe(replacement = "this.increaseDeviceVolume(0)")
  @Deprecated
  @Override
  public void increaseDeviceVolume() {
    increaseDeviceVolume(/* flags= */ 0);
  }

  @Override
  public void increaseDeviceVolume(@C.VolumeFlags int flags) {
    setDeviceVolume(getDeviceVolume() + 1, flags);
  }

  /**
   * @deprecated Use {@link #decreaseDeviceVolume(int)} instead.
   */
  @InlineMe(replacement = "this.decreaseDeviceVolume(0)")
  @Deprecated
  @Override
  public void decreaseDeviceVolume() {
    decreaseDeviceVolume(/* flags= */ 0);
  }

  @Override
  public void decreaseDeviceVolume(@C.VolumeFlags int flags) {
    setDeviceVolume(getDeviceVolume() - 1, flags);
  }

  /**
   * @deprecated Use {@link #setDeviceMuted(boolean, int)} instead.
   */
  @InlineMe(replacement = "this.setDeviceMuted(muted, 0)")
  @Deprecated
  @Override
  public void setDeviceMuted(boolean muted) {
    setDeviceMuted(muted, /* flags= */ 0);
  }

  @Override
  public void setDeviceMuted(boolean muted, @C.VolumeFlags int flags) {
    if (castSession == null) {
      return;
    }
    try {
      castSession.setMute(muted);
    } catch (IOException e) {
      Log.w(TAG, "Ignoring setDeviceMuted due to exception", e);
      return;
    }
    setDeviceVolumeAndNotifyIfChanged(deviceVolume, muted);
    listeners.flushEvents();
  }

  /** This method is not supported and does nothing. */
  @Override
  public void setAudioAttributes(AudioAttributes audioAttributes, boolean handleAudioFocus) {}

  // Internal methods.

  private void onQueueSnapshotChanged(
      QueuedOperation.QueueSnapshot newSnapshot,
      @Nullable @TimelineChangeReason Integer timelineChangeReason) {
    if (timelineChangeReason == null || !isCastSessionActive()) {
      currentQueueSnapshot = newSnapshot;
      return;
    }
    if (timelineChangeReason == Player.TIMELINE_CHANGE_REASON_PLAYLIST_CHANGED
        && currentQueueSnapshot.timeline.equals(newSnapshot.timeline)) {
      // Operations that do not modify the timeline (such as seekTo) handle their own position
      // discontinuity and transition notifications.
      currentQueueSnapshot = newSnapshot;
      return;
    }
    MediaMetadata oldMediaMetadata = mediaMetadata;
    applyQueueSnapshotAndNotifyTimelineChanges(newSnapshot, timelineChangeReason);
    mediaMetadata = getMediaMetadataInternal();
    if (!oldMediaMetadata.equals(mediaMetadata)) {
      listeners.queueEvent(
          Player.EVENT_MEDIA_METADATA_CHANGED,
          listener -> listener.onMediaMetadataChanged(mediaMetadata));
    }
    listeners.flushEvents();
  }

  private void updateInternalStateAndNotifyIfChanged() {
    if (!isCastSessionActive()) {
      // Leave the state of the player as it is when there is no session.
      return;
    }
    updatePlayerStateAndNotifyIfChanged(/* resultCallback= */ null);
    updateDeviceVolumeAndNotifyIfChanged();
    updateRepeatModeAndNotifyIfChanged(/* resultCallback= */ null);
    updateVolumeAndNotifyIfChanged(/* resultCallback= */ null);
    updatePlaybackRateAndNotifyIfChanged(/* resultCallback= */ null);
    updateTimelineAndNotifyIfChanged();
    updateTracksAndNotifyIfChanged(
        /* resultCallback= */ null, TRACK_SELECTION_REQUEST_REASON_RECEIVER_UPDATE);
    updateAvailableCommandsAndNotifyIfChanged();
    listeners.flushEvents();
  }

  private MediaMetadata getMediaMetadataInternal() {
    MediaItem currentMediaItem = getCurrentMediaItem();
    return currentMediaItem != null ? currentMediaItem.mediaMetadata : MediaMetadata.EMPTY;
  }

  /**
   * Updates {@link #playWhenReady} and {@link #playbackState} to match the Cast {@code
   * remoteMediaClient} state, and notifies listeners of any state changes.
   *
   * <p>This method will only update values whose {@link StateHolder#pendingResultCallback} matches
   * the given {@code resultCallback}.
   */
  @RequiresNonNull("remoteMediaClient")
  private void updatePlayerStateAndNotifyIfChanged(@Nullable ResultCallback<?> resultCallback) {
    boolean newPlayWhenReadyValue = playWhenReady.value;
    if (playWhenReady.acceptsUpdate(resultCallback)) {
      if (!CastUtils.hasQueueEnded(remoteMediaClient) && getMediaStatus() != null) {
        newPlayWhenReadyValue = !remoteMediaClient.isPaused();
      }
      playWhenReady.clearPendingResultCallback();
    }
    @PlayWhenReadyChangeReason
    int playWhenReadyChangeReason =
        newPlayWhenReadyValue != playWhenReady.value
            ? PLAY_WHEN_READY_CHANGE_REASON_REMOTE
            : PLAY_WHEN_READY_CHANGE_REASON_USER_REQUEST;
    // We do not mask the playback state, so try setting it regardless of the playWhenReady masking.
    setPlayerStateAndNotifyIfChanged(
        newPlayWhenReadyValue, playWhenReadyChangeReason, fetchPlaybackState(remoteMediaClient));
  }

  @RequiresNonNull("remoteMediaClient")
  private void updatePlaybackRateAndNotifyIfChanged(@Nullable ResultCallback<?> resultCallback) {
    if (playbackParameters.acceptsUpdate(resultCallback)) {
      @Nullable MediaStatus mediaStatus = remoteMediaClient.getMediaStatus();
      if (!CastUtils.hasQueueEnded(remoteMediaClient) && mediaStatus != null) {
        float speed = (float) mediaStatus.getPlaybackRate();
        if (speed > 0.0f) {
          // Set the speed if not paused.
          setPlaybackParametersAndNotifyIfChanged(new PlaybackParameters(speed));
        }
      }
      playbackParameters.clearPendingResultCallback();
    }
  }

  @RequiresNonNull("castSession")
  private void updateDeviceVolumeAndNotifyIfChanged() {
    if (castSession != null) {
      int deviceVolume =
          RANGE_DEVICE_VOLUME.clamp((int) Math.round(castSession.getVolume() * MAX_VOLUME));
      setDeviceVolumeAndNotifyIfChanged(deviceVolume, castSession.isMute());
    }
  }

  @RequiresNonNull("remoteMediaClient")
  private void updateVolumeAndNotifyIfChanged(@Nullable ResultCallback<?> resultCallback) {
    if (volume.acceptsUpdate(resultCallback)) {
      float remoteVolume = RANGE_VOLUME.clamp(fetchVolume(remoteMediaClient));
      setVolumeAndNotifyIfChanged(remoteVolume);
      volume.clearPendingResultCallback();
    }
  }

  @RequiresNonNull("remoteMediaClient")
  private void updateRepeatModeAndNotifyIfChanged(@Nullable ResultCallback<?> resultCallback) {
    if (repeatMode.acceptsUpdate(resultCallback)) {
      if (!CastUtils.hasQueueEnded(remoteMediaClient) && getMediaStatus() != null) {
        setRepeatModeAndNotifyIfChanged(fetchRepeatMode(remoteMediaClient));
      }
      repeatMode.clearPendingResultCallback();
    }
  }

  /** Updates the timeline and notifies {@link Player.Listener event listeners} if required. */
  private void updateTimelineAndNotifyIfChanged() {
    if (!isCastSessionActive()) {
      // We ignore calls when the session is not active.
      return;
    }
    queueOrchestrator.onReceiverStateUpdated(remoteMediaClient);
    updateAvailableCommandsAndNotifyIfChanged();
  }

  /**
   * Diffs {@code newSnapshot} against {@link #currentQueueSnapshot}, updates {@link
   * #currentQueueSnapshot}, and queues timeline, discontinuity, and transition events.
   */
  @SuppressWarnings("deprecation") // Calling deprecated listener method.
  private void applyQueueSnapshotAndNotifyTimelineChanges(
      QueuedOperation.QueueSnapshot newSnapshot, @TimelineChangeReason int timelineChangeReason) {
    Timeline oldTimeline = currentQueueSnapshot.timeline;
    int oldWindowIndex = currentQueueSnapshot.currentWindowIndex;
    @Nullable
    Object oldPeriodUid =
        !oldTimeline.isEmpty()
            ? oldTimeline.getPeriod(oldWindowIndex, period, /* setIds= */ true).uid
            : null;
    boolean playingPeriodRemoved =
        oldPeriodUid != null
            && newSnapshot.timeline.getIndexOfPeriod(oldPeriodUid) == C.INDEX_UNSET;
    @Nullable PositionInfo oldPosition = playingPeriodRemoved ? getCurrentPositionInfo() : null;

    currentQueueSnapshot = newSnapshot;

    Timeline currentTimeline = newSnapshot.timeline;
    int currentWindowIndex = newSnapshot.currentWindowIndex;
    @Nullable
    Object currentPeriodUid =
        !currentTimeline.isEmpty()
            ? currentTimeline.getPeriod(currentWindowIndex, period, /* setIds= */ true).uid
            : null;

    if (!oldTimeline.equals(currentTimeline)) {
      listeners.queueEvent(
          Player.EVENT_TIMELINE_CHANGED,
          listener -> listener.onTimelineChanged(currentTimeline, timelineChangeReason));

      if (playingPeriodRemoved && oldPosition != null) {
        PositionInfo newPosition = getCurrentPositionInfo();
        listeners.queueEvent(
            Player.EVENT_POSITION_DISCONTINUITY,
            listener -> {
              listener.onPositionDiscontinuity(DISCONTINUITY_REASON_REMOVE);
              listener.onPositionDiscontinuity(
                  oldPosition, newPosition, DISCONTINUITY_REASON_REMOVE);
            });
      }

      boolean playingPeriodChanged =
          currentTimeline.isEmpty() != oldTimeline.isEmpty() || playingPeriodRemoved;
      if (playingPeriodChanged) {
        listeners.queueEvent(
            Player.EVENT_MEDIA_ITEM_TRANSITION,
            listener ->
                listener.onMediaItemTransition(
                    getCurrentMediaItem(), MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED));
      }
    }
    if (remoteMediaClient != null && CastUtils.hasQueueEnded(remoteMediaClient)) {
      setPlayerStateAndNotifyIfChanged(
          playWhenReady.value,
          PLAY_WHEN_READY_CHANGE_REASON_USER_REQUEST,
          fetchPlaybackState(remoteMediaClient));
      updateAvailableCommandsAndNotifyIfChanged();
    } else if (currentTimeline.isEmpty() && playbackState != STATE_IDLE) {
      setPlayerStateAndNotifyIfChanged(
          playWhenReady.value, PLAY_WHEN_READY_CHANGE_REASON_USER_REQUEST, STATE_IDLE);
      updateAvailableCommandsAndNotifyIfChanged();
    }

    if (timelineChangeReason == Player.TIMELINE_CHANGE_REASON_SOURCE_UPDATE
        && oldPeriodUid != null
        && !playingPeriodRemoved
        && !Objects.equals(oldPeriodUid, currentPeriodUid)) {
      // Report discontinuity and media item auto transition.
      oldTimeline.getPeriod(oldWindowIndex, period, /* setIds= */ true);
      oldTimeline.getWindow(oldWindowIndex, window);
      long windowDurationMs = window.getDurationMs();
      PositionInfo autoTransitionOldPosition =
          new PositionInfo(
              window.uid,
              period.windowIndex,
              window.mediaItem,
              period.uid,
              period.windowIndex,
              /* positionMs= */ windowDurationMs,
              /* contentPositionMs= */ windowDurationMs,
              /* adGroupIndex= */ C.INDEX_UNSET,
              /* adIndexInAdGroup= */ C.INDEX_UNSET);
      currentTimeline.getPeriod(currentWindowIndex, period, /* setIds= */ true);
      currentTimeline.getWindow(currentWindowIndex, window);
      PositionInfo autoTransitionNewPosition =
          new PositionInfo(
              window.uid,
              period.windowIndex,
              window.mediaItem,
              period.uid,
              period.windowIndex,
              /* positionMs= */ window.getDefaultPositionMs(),
              /* contentPositionMs= */ window.getDefaultPositionMs(),
              /* adGroupIndex= */ C.INDEX_UNSET,
              /* adIndexInAdGroup= */ C.INDEX_UNSET);
      listeners.queueEvent(
          Player.EVENT_POSITION_DISCONTINUITY,
          listener -> {
            listener.onPositionDiscontinuity(DISCONTINUITY_REASON_AUTO_TRANSITION);
            listener.onPositionDiscontinuity(
                autoTransitionOldPosition,
                autoTransitionNewPosition,
                DISCONTINUITY_REASON_AUTO_TRANSITION);
          });
      listeners.queueEvent(
          Player.EVENT_MEDIA_ITEM_TRANSITION,
          listener ->
              listener.onMediaItemTransition(
                  getCurrentMediaItem(), MEDIA_ITEM_TRANSITION_REASON_AUTO));
    }
  }

  /**
   * Updates the internal tracks and queues a listener event if tracks have changed.
   *
   * <p>This method does nothing if {@link #currentTracks} is masking a track selection operation
   * (as defined by {@link StateHolder#acceptsUpdate}), the invocation of this method is not the
   * result of the completion of the masked operation, and the invocation is not the result of a
   * {@link CastTrackSelector#invalidate()} call.
   *
   * @param resultCallback The result callback that triggered this call, if any.
   * @param selectionRequestReason The reason for this invocation.
   */
  private void updateTracksAndNotifyIfChanged(
      @Nullable ResultCallback<MediaChannelResult> resultCallback,
      @TrackSelectionRequestReason int selectionRequestReason) {
    if (!isCastSessionActive()) {
      // We ignore calls when the session is not active.
      return;
    }
    if (currentTracks.acceptsUpdate(resultCallback)) {
      currentTracks.clearPendingResultCallback();
    } else if (selectionRequestReason == TRACK_SELECTION_REQUEST_REASON_RECEIVER_UPDATE) {
      // We are masking a track selection and the masked operation hasn't completed.
      return;
    }
    @Nullable MediaStatus mediaStatus = getMediaStatus();
    @Nullable MediaInfo mediaInfo = mediaStatus != null ? mediaStatus.getMediaInfo() : null;
    @Nullable
    List<MediaTrack> castMediaTracks = mediaInfo != null ? mediaInfo.getMediaTracks() : null;
    if (castMediaTracks == null || castMediaTracks.isEmpty()) {
      setTracksAndNotifyIfChanged(Tracks.EMPTY);
      return;
    }
    @Nullable long[] activeTrackIds = mediaStatus.getActiveTrackIds();
    if (activeTrackIds == null) {
      activeTrackIds = EMPTY_TRACK_ID_ARRAY;
    }
    ImmutableSet<Long> immutableActiveTrackIds = ImmutableSet.copyOf(Longs.asList(activeTrackIds));
    ImmutableList<MediaTrack> immutableCastMediaTracks = ImmutableList.copyOf(castMediaTracks);
    int currentItemId = mediaStatus.getCurrentItemId();
    ImmutableSet.Builder<TrackGroup> currentlyActiveTrackGroupsBuilder =
        new ImmutableSet.Builder<>();
    ImmutableList.Builder<TrackGroup> trackGroupListBuilder = new ImmutableList.Builder<>();
    for (int i = 0; i < castMediaTracks.size(); i++) {
      MediaTrack mediaTrack = immutableCastMediaTracks.get(i);
      TrackGroup trackGroup = CastUtils.mediaTrackToTrackGroup(currentItemId, mediaTrack);
      trackGroupListBuilder.add(trackGroup);
      if (immutableActiveTrackIds.contains(mediaTrack.getId())) {
        currentlyActiveTrackGroupsBuilder.add(trackGroup);
      }
    }
    ImmutableList<TrackGroup> trackGroupList = trackGroupListBuilder.build();
    ImmutableSet<TrackGroup> currentlyActiveTrackGroups = currentlyActiveTrackGroupsBuilder.build();

    CastTrackSelectorResult result;
    if (trackSelector != null) {
      CastTrackSelectorRequest selectionRequest =
          new CastTrackSelectorRequest(
              currentItemId,
              trackSelectionParameters.value,
              trackGroupList,
              immutableCastMediaTracks,
              currentlyActiveTrackGroups,
              selectionRequestReason);
      if (selectionRequestReason != TRACK_SELECTION_REQUEST_REASON_INVALIDATION
          && selectionRequest.equals(lastSelectionRequest)) {
        // Nothing has changed. No point in continuing.
        return;
      }
      lastSelectionRequest = selectionRequest;
      result = trackSelector.evaluate(selectionRequest);
    } else {
      result =
          new CastTrackSelectorResult(currentlyActiveTrackGroups, trackSelectionParameters.value);
    }
    if (!result.trackSelectionParameters.equals(trackSelectionParameters.value)) {
      setTrackSelectionParametersAndNotifyIfChanged(result.trackSelectionParameters);
    }
    ImmutableSet<TrackGroup> newSelectedTrackGroups = result.selections;
    if (!currentlyActiveTrackGroups.equals(newSelectedTrackGroups)) {
      currentTracks.pendingResultCallback =
          new ResultCallback<MediaChannelResult>() {
            @Override
            public void onResult(MediaChannelResult result) {
              logOperationFailedIfStatusError("Set active tracks", result);
              if (remoteMediaClient != null) {
                updateTracksAndNotifyIfChanged(
                    this, TRACK_SELECTION_REQUEST_REASON_RECEIVER_UPDATE);
                listeners.flushEvents();
              }
            }
          };
      ArrayList<Long> newActiveTracksIds =
          new ArrayList<>(/* capacity= */ newSelectedTrackGroups.size());
      for (TrackGroup trackGroup : newSelectedTrackGroups) {
        int index = trackGroupList.indexOf(trackGroup);
        if (index != -1) {
          newActiveTracksIds.add(immutableCastMediaTracks.get(index).getId());
        } else {
          throw new IllegalStateException(
              "CastTrackSelector produced a TrackGroup that was not in the list of available track"
                  + " groups: "
                  + trackGroup);
        }
      }
      remoteMediaClient
          .setActiveMediaTracks(Longs.toArray(newActiveTracksIds))
          .setResultCallback(currentTracks.pendingResultCallback);
    }

    Tracks.Group[] tracksGroups = new Tracks.Group[trackGroupList.size()];
    for (int i = 0; i < tracksGroups.length; i++) {
      TrackGroup trackGroup = trackGroupList.get(i);
      @C.FormatSupport int[] trackSupport = new int[] {C.FORMAT_HANDLED};
      boolean trackIsSelected = newSelectedTrackGroups.contains(trackGroup);
      boolean[] trackSelectedArray = new boolean[] {trackIsSelected};
      tracksGroups[i] =
          new Tracks.Group(
              trackGroup, /* adaptiveSupported= */ false, trackSupport, trackSelectedArray);
    }
    Tracks newTracks = new Tracks(ImmutableList.copyOf(tracksGroups));
    setTracksAndNotifyIfChanged(newTracks);
  }

  private void updateAvailableCommandsAndNotifyIfChanged() {
    Commands previousAvailableCommands = availableCommands;
    availableCommands =
        Util.getAvailableCommands(/* player= */ this, PERMANENT_AVAILABLE_COMMANDS)
            .buildUpon()
            .addIf(COMMAND_GET_VOLUME, isSetVolumeCommandAvailable())
            .addIf(COMMAND_SET_VOLUME, isSetVolumeCommandAvailable())
            .addIf(COMMAND_SET_TRACK_SELECTION_PARAMETERS, trackSelector != null)
            .build();
    if (!availableCommands.equals(previousAvailableCommands)) {
      listeners.queueEvent(
          Player.EVENT_AVAILABLE_COMMANDS_CHANGED,
          listener -> listener.onAvailableCommandsChanged(availableCommands));
    }
  }

  private boolean isSetVolumeCommandAvailable() {
    if (isCastSessionActive()) {
      MediaStatus mediaStatus = remoteMediaClient.getMediaStatus();
      if (mediaStatus != null) {
        return mediaStatus.isMediaCommandSupported(MediaStatus.COMMAND_SET_VOLUME);
      }
    }
    return false;
  }

  private PositionInfo getCurrentPositionInfo() {
    Timeline currentTimeline = getCurrentTimeline();
    @Nullable Object newPeriodUid = null;
    @Nullable Object newWindowUid = null;
    @Nullable MediaItem newMediaItem = null;
    if (!currentTimeline.isEmpty()) {
      newPeriodUid =
          currentTimeline.getPeriod(getCurrentPeriodIndex(), period, /* setIds= */ true).uid;
      newWindowUid = currentTimeline.getWindow(period.windowIndex, window).uid;
      newMediaItem = window.mediaItem;
    }
    return new PositionInfo(
        newWindowUid,
        getCurrentMediaItemIndex(),
        newMediaItem,
        newPeriodUid,
        getCurrentPeriodIndex(),
        getCurrentPosition(),
        getContentPosition(),
        /* adGroupIndex= */ C.INDEX_UNSET,
        /* adIndexInAdGroup= */ C.INDEX_UNSET);
  }

  private void setDeviceVolumeAndNotifyIfChanged(
      @IntRange(from = 0) int deviceVolume, boolean isMuted) {
    if (this.deviceVolume != deviceVolume || this.isMuted != isMuted) {
      this.deviceVolume = deviceVolume;
      this.isMuted = isMuted;
      listeners.queueEvent(
          Player.EVENT_DEVICE_VOLUME_CHANGED,
          listener -> listener.onDeviceVolumeChanged(deviceVolume, isMuted));
    }
  }

  private void setRepeatModeAndNotifyIfChanged(@Player.RepeatMode int repeatMode) {
    if (this.repeatMode.value != repeatMode) {
      this.repeatMode.value = repeatMode;
      listeners.queueEvent(
          Player.EVENT_REPEAT_MODE_CHANGED, listener -> listener.onRepeatModeChanged(repeatMode));
      updateAvailableCommandsAndNotifyIfChanged();
    }
  }

  private void setVolumeAndNotifyIfChanged(float volume) {
    if (this.volume.value != volume) {
      unmuteVolume = volume != 0 ? volume : this.unmuteVolume;
      this.volume.value = volume;
      listeners.queueEvent(
          Player.EVENT_VOLUME_CHANGED, listener -> listener.onVolumeChanged(volume));
      updateAvailableCommandsAndNotifyIfChanged();
    }
  }

  private void setPlaybackParametersAndNotifyIfChanged(PlaybackParameters playbackParameters) {
    if (this.playbackParameters.value.equals(playbackParameters)) {
      return;
    }
    this.playbackParameters.value = playbackParameters;
    listeners.queueEvent(
        Player.EVENT_PLAYBACK_PARAMETERS_CHANGED,
        listener -> listener.onPlaybackParametersChanged(playbackParameters));
    updateAvailableCommandsAndNotifyIfChanged();
  }

  private void setTrackSelectionParametersAndNotifyIfChanged(
      TrackSelectionParameters newTrackSelectionParameters) {
    if (this.trackSelectionParameters.value.equals(newTrackSelectionParameters)) {
      return;
    }
    this.trackSelectionParameters.value = newTrackSelectionParameters;
    listeners.queueEvent(
        Player.EVENT_TRACK_SELECTION_PARAMETERS_CHANGED,
        listener -> listener.onTrackSelectionParametersChanged(newTrackSelectionParameters));
  }

  @SuppressWarnings("deprecation")
  private void setPlayerStateAndNotifyIfChanged(
      boolean playWhenReady,
      @Player.PlayWhenReadyChangeReason int playWhenReadyChangeReason,
      @Player.State int playbackState) {
    boolean wasPlaying = this.playbackState == Player.STATE_READY && this.playWhenReady.value;
    boolean playWhenReadyChanged = this.playWhenReady.value != playWhenReady;
    boolean playbackStateChanged = this.playbackState != playbackState;
    if (playWhenReadyChanged || playbackStateChanged) {
      this.playbackState = playbackState;
      this.playWhenReady.value = playWhenReady;
      listeners.queueEvent(
          /* eventFlag= */ C.INDEX_UNSET,
          listener -> listener.onPlayerStateChanged(playWhenReady, playbackState));
      if (playbackStateChanged) {
        listeners.queueEvent(
            Player.EVENT_PLAYBACK_STATE_CHANGED,
            listener -> listener.onPlaybackStateChanged(playbackState));
      }
      if (playWhenReadyChanged) {
        listeners.queueEvent(
            Player.EVENT_PLAY_WHEN_READY_CHANGED,
            listener -> listener.onPlayWhenReadyChanged(playWhenReady, playWhenReadyChangeReason));
      }
      boolean isPlaying = playbackState == Player.STATE_READY && playWhenReady;
      if (wasPlaying != isPlaying) {
        listeners.queueEvent(
            Player.EVENT_IS_PLAYING_CHANGED, listener -> listener.onIsPlayingChanged(isPlaying));
      }
    }
  }

  private void setTracksAndNotifyIfChanged(Tracks tracks) {
    if (!tracks.equals(currentTracks.value)) {
      currentTracks.value = tracks;
      listeners.queueEvent(
          Player.EVENT_TRACKS_CHANGED, listener -> listener.onTracksChanged(tracks));
      updateAvailableCommandsAndNotifyIfChanged();
    }
  }

  private void setCastSession(@Nullable CastSession castSession) {
    setCastSession(
        castSession, SessionAvailabilityListener.SESSION_UNAVAILABLE_REASON_DISCONNECTED);
  }

  private void setCastSession(
      @Nullable CastSession castSession,
      @SessionAvailabilityListener.SessionUnavailableReason int sessionUnavailableReason) {
    isSessionEnding = false;
    if (this.castSession != null) {
      this.castSession.removeCastListener(castListener);
    }
    if (castSession != null) {
      castSession.addCastListener(castListener);
    }
    this.castSession = castSession;
    RemoteMediaClient remoteMediaClient =
        castSession != null ? castSession.getRemoteMediaClient() : null;
    if (this.remoteMediaClient == remoteMediaClient) {
      // Do nothing.
      return;
    }
    if (this.remoteMediaClient != null) {
      this.remoteMediaClient.unregisterCallback(statusListener);
      this.remoteMediaClient.removeProgressListener(statusListener);
      this.remoteMediaClient.getMediaQueue().unregisterCallback(mediaQueueCallback);
    }
    this.remoteMediaClient = remoteMediaClient;
    resetMaskingAndCacheState();

    if (remoteMediaClient != null) {
      if (sessionAvailabilityListener != null) {
        sessionAvailabilityListener.onCastSessionAvailable();
      }
      if (internalSessionAvailabilityListener != null) {
        internalSessionAvailabilityListener.onCastSessionAvailable();
      }
      remoteMediaClient.getMediaQueue().registerCallback(mediaQueueCallback);
      remoteMediaClient.registerCallback(statusListener);
      remoteMediaClient.addProgressListener(statusListener, PROGRESS_REPORT_PERIOD_MS);
      updateInternalStateAndNotifyIfChanged();
    } else {
      if (sessionAvailabilityListener != null) {
        sessionAvailabilityListener.onCastSessionUnavailable(sessionUnavailableReason);
      }
      if (internalSessionAvailabilityListener != null) {
        internalSessionAvailabilityListener.onCastSessionUnavailable(sessionUnavailableReason);
      }
    }
    updateDeviceInfo();
  }

  private void updateDeviceInfo() {
    DeviceInfo oldDeviceInfo = deviceInfo;
    DeviceInfo newDeviceInfo =
        SDK_INT >= 30 && api30Impl != null
            ? api30Impl.fetchDeviceInfo()
            : fetchDeviceInfoFallback();
    deviceInfo = newDeviceInfo;
    if (!deviceInfo.equals(oldDeviceInfo)) {
      listeners.sendEvent(
          EVENT_DEVICE_INFO_CHANGED, listener -> listener.onDeviceInfoChanged(newDeviceInfo));
    }
  }

  private DeviceInfo fetchDeviceInfoFallback() {
    if (castSession != null && castSession.getCastDevice() != null) {
      return new DeviceInfo.Builder(DeviceInfo.PLAYBACK_TYPE_REMOTE)
          .setMaxVolume(MAX_VOLUME)
          .setRoutingControllerName(castSession.getCastDevice().getFriendlyName())
          .build();
    }
    return DEVICE_INFO_REMOTE_EMPTY;
  }

  private static @SessionAvailabilityListener.SessionUnavailableReason int mapDisconnectionReason(
      int error) {
    switch (error) {
      case SESSION_END_REASON_ROUTE_CHANGE:
        return SessionAvailabilityListener.SESSION_UNAVAILABLE_REASON_ROUTE_CHANGED;
      case SESSION_END_REASON_STOPPED:
        return SessionAvailabilityListener.SESSION_UNAVAILABLE_REASON_STOPPED;
      case APPLICATION_STOPPED:
        return SessionAvailabilityListener.SESSION_UNAVAILABLE_REASON_APP_STOPPED;
      default:
        return SessionAvailabilityListener.SESSION_UNAVAILABLE_REASON_DISCONNECTED;
    }
  }

  /**
   * Resets all masking state, pending result callbacks, and caches to their default values.
   *
   * <p>This cleanup is crucial during session transitions (such as disconnections, reconnections,
   * or session swaps) to avoid state leakage from the previous session and to prevent stale masking
   * locks from blocking incoming updates in the new session.
   */
  private void resetMaskingAndCacheState() {
    lastSelectionRequest = null;
    playWhenReady.clearPendingResultCallback();
    repeatMode.clearPendingResultCallback();
    volume.clearPendingResultCallback();
    playbackParameters.clearPendingResultCallback();
    currentTracks.clearPendingResultCallback();
    trackSelectionParameters.clearPendingResultCallback();
    queueOrchestrator.reset(/* clearSnapshots= */ remoteMediaClient != null);
  }

  @Nullable
  private MediaStatus getMediaStatus() {
    return isCastSessionActive() ? remoteMediaClient.getMediaStatus() : null;
  }

  private boolean isCastSessionActive() {
    return remoteMediaClient != null && !isSessionEnding;
  }

  /**
   * Retrieves the playback state from {@code remoteMediaClient} and maps it into a {@link Player}
   * state
   */
  private @Player.State int fetchPlaybackState(RemoteMediaClient remoteMediaClient) {
    int receiverAppStatus = remoteMediaClient.getPlayerState();
    switch (receiverAppStatus) {
      case MediaStatus.PLAYER_STATE_BUFFERING:
      case MediaStatus.PLAYER_STATE_LOADING:
        return STATE_BUFFERING;
      case MediaStatus.PLAYER_STATE_PLAYING:
      case MediaStatus.PLAYER_STATE_PAUSED:
        return STATE_READY;
      case MediaStatus.PLAYER_STATE_IDLE:
      case MediaStatus.PLAYER_STATE_UNKNOWN:
      default:
        if (CastUtils.hasQueueEnded(remoteMediaClient) && !getCurrentTimeline().isEmpty()) {
          return queueOrchestrator.isReloadingFromQueueEnd() ? STATE_BUFFERING : STATE_ENDED;
        }
        return STATE_IDLE;
    }
  }

  /**
   * Retrieves the repeat mode from {@code remoteMediaClient} and maps it into a {@link
   * Player.RepeatMode}.
   */
  private static @RepeatMode int fetchRepeatMode(RemoteMediaClient remoteMediaClient) {
    MediaStatus mediaStatus = remoteMediaClient.getMediaStatus();
    if (mediaStatus == null) {
      // No media session active, yet.
      return REPEAT_MODE_OFF;
    }
    int castRepeatMode = mediaStatus.getQueueRepeatMode();
    switch (castRepeatMode) {
      case MediaStatus.REPEAT_MODE_REPEAT_SINGLE:
        return REPEAT_MODE_ONE;
      case MediaStatus.REPEAT_MODE_REPEAT_ALL:
      case MediaStatus.REPEAT_MODE_REPEAT_ALL_AND_SHUFFLE:
        return REPEAT_MODE_ALL;
      case MediaStatus.REPEAT_MODE_REPEAT_OFF:
        return REPEAT_MODE_OFF;
      default:
        throw new IllegalStateException();
    }
  }

  private static float fetchVolume(RemoteMediaClient remoteMediaClient) {
    MediaStatus mediaStatus = remoteMediaClient.getMediaStatus();
    if (mediaStatus == null) {
      return 1f;
    }
    // Mute check should come first because getStreamVolume stores the previous volume when muted.
    if (mediaStatus.isMute()) {
      return 0f;
    }
    return (float) mediaStatus.getStreamVolume();
  }

  @SuppressWarnings("VisibleForTests")
  private static int getCastRepeatMode(@RepeatMode int repeatMode) {
    switch (repeatMode) {
      case REPEAT_MODE_ONE:
        return MediaStatus.REPEAT_MODE_REPEAT_SINGLE;
      case REPEAT_MODE_ALL:
        return MediaStatus.REPEAT_MODE_REPEAT_ALL;
      case REPEAT_MODE_OFF:
        return MediaStatus.REPEAT_MODE_REPEAT_OFF;
      default:
        throw new IllegalArgumentException();
    }
  }

  private static void logOperationFailedIfStatusError(String operation, MediaChannelResult result) {
    CastUtils.logOperationFailedIfStatusError(TAG, operation, result);
  }

  // Internal classes.

  private final class StatusListener extends RemoteMediaClient.Callback
      implements SessionManagerListener<CastSession>, RemoteMediaClient.ProgressListener {

    // RemoteMediaClient.ProgressListener implementation.

    @Override
    public void onProgressUpdated(long progressMs, long unusedDurationMs) {
      if (isCastSessionActive()) {
        lastReportedPositionMs = progressMs;
      }
    }

    // RemoteMediaClient.Callback implementation.

    @Override
    public void onStatusUpdated() {
      updateInternalStateAndNotifyIfChanged();
    }

    @Override
    public void onMetadataUpdated() {}

    @Override
    public void onQueueStatusUpdated() {
      updateTimelineAndNotifyIfChanged();
      listeners.flushEvents();
    }

    @Override
    public void onPreloadStatusUpdated() {}

    @Override
    public void onSendingRemoteMediaRequest() {}

    @Override
    public void onAdBreakStatusUpdated() {}

    // SessionManagerListener implementation.

    @Override
    public void onSessionStarted(CastSession castSession, String s) {
      setCastSession(castSession);
    }

    @Override
    public void onSessionResumed(CastSession castSession, boolean b) {
      setCastSession(castSession);
    }

    @Override
    public void onSessionEnded(CastSession castSession, int error) {
      setCastSession(null, mapDisconnectionReason(error));
    }

    @Override
    public void onSessionSuspended(CastSession castSession, int reason) {
      setCastSession(null, SessionAvailabilityListener.SESSION_UNAVAILABLE_REASON_DISCONNECTED);
    }

    @Override
    public void onSessionResumeFailed(CastSession castSession, int statusCode) {
      Log.e(
          TAG,
          "Session resume failed. Error code "
              + statusCode
              + ": "
              + CastUtils.getLogString(statusCode));
    }

    @Override
    public void onSessionStarting(CastSession castSession) {
      // Do nothing.
    }

    @Override
    public void onSessionStartFailed(CastSession castSession, int statusCode) {
      Log.e(
          TAG,
          "Session start failed. Error code "
              + statusCode
              + ": "
              + CastUtils.getLogString(statusCode));
    }

    @Override
    public void onSessionEnding(CastSession castSession) {
      // We don't wait until the onSessionEnded event because the media queue callback will send
      // updates before that (but after onSessionEnding) indicating the queue is being cleared. This
      // complicates playback state transfer to local. As a result, we freeze the state here by
      // setting isSessionEnding = true, and wait for onSessionEnded to call setCastSession(null)
      // with the unselect reason. See [internal: b/479112029] and [internal: b/502159642].
      isSessionEnding = true;
    }

    @Override
    public void onSessionResuming(CastSession castSession, String s) {
      // Do nothing.
    }
  }

  /**
   * Holds the value and the masking status of a specific part of the {@link RemoteCastPlayer}
   * state.
   */
  private static final class StateHolder<T> {

    /** The user-facing value of a specific part of the {@link RemoteCastPlayer} state. */
    public T value;

    /**
     * If {@link #value} is being masked, holds the result callback for the operation that triggered
     * the masking. Or null if {@link #value} is not being masked.
     */
    @Nullable public ResultCallback<MediaChannelResult> pendingResultCallback;

    public StateHolder(T initialValue) {
      value = initialValue;
    }

    public void clearPendingResultCallback() {
      pendingResultCallback = null;
    }

    /**
     * Returns whether this state holder accepts updates coming from the given result callback.
     *
     * <p>A null {@code resultCallback} means that the update is a regular receiver state update, in
     * which case the update will only be accepted if {@link #value} is not being masked. If {@link
     * #value} is being masked, the update will only be accepted if {@code resultCallback} is the
     * same as the {@link #pendingResultCallback}.
     *
     * @param resultCallback A result callback. May be null if the update comes from a regular
     *     receiver status update.
     */
    public boolean acceptsUpdate(@Nullable ResultCallback<?> resultCallback) {
      return pendingResultCallback == resultCallback;
    }
  }

  @RequiresApi(30)
  private final class Api30Impl {

    private final MediaRouter2 mediaRouter2;
    private final TransferCallback transferCallback;
    private final RouteCallback emptyRouteCallback;
    private final Handler handler;

    public Api30Impl(Context context) {
      mediaRouter2 = MediaRouter2.getInstance(context);
      transferCallback = new MediaRouter2TransferCallbackImpl();
      emptyRouteCallback = new MediaRouter2RouteCallbackImpl();
      handler = new Handler(Looper.getMainLooper());
    }

    /** Acquires necessary resources and registers callbacks. */
    public void initialize() {
      mediaRouter2.registerTransferCallback(handler::post, transferCallback);
      // We need at least one route callback registered in order to get transfer callback updates.
      mediaRouter2.registerRouteCallback(
          handler::post,
          emptyRouteCallback,
          new RouteDiscoveryPreference.Builder(ImmutableList.of(), /* activeScan= */ false)
              .build());
    }

    /**
     * Releases any resources acquired in {@link #initialize()} and unregisters any registered
     * callbacks.
     */
    public void release() {
      mediaRouter2.unregisterTransferCallback(transferCallback);
      mediaRouter2.unregisterRouteCallback(emptyRouteCallback);
      handler.removeCallbacksAndMessages(/* token= */ null);
    }

    /**
     * Returns a {@link DeviceInfo} with the {@link RoutingController#getId() id} that corresponds
     * to the Cast session, or {@link #DEVICE_INFO_REMOTE_EMPTY} if not available.
     */
    public DeviceInfo fetchDeviceInfo() {
      // TODO: b/364833997 - Fetch this information from the AndroidX MediaRouter selected route
      // once the selected route id matches the controller id.
      List<RoutingController> controllers = mediaRouter2.getControllers();
      // The controller at position zero is always the system controller (local playback). All other
      // controllers are for remote playback, and could be the Cast one.
      if (controllers.size() != 2) {
        // There's either no remote routing controller, or there's more than one. In either case we
        // don't populate the device info because either there's no Cast routing controller, or we
        // cannot safely identify the Cast routing controller.
        return fetchDeviceInfoFallback();
      } else {
        // There's only one remote routing controller. It's safe to assume it's the Cast routing
        // controller.
        RoutingController remoteController = controllers.get(1);
        @Nullable String controllerName = null;
        if (SDK_INT >= 34) {
          controllerName = Api34Impl.getRoutingControllerName(remoteController);
        }
        if (controllerName == null && !remoteController.getSelectedRoutes().isEmpty()) {
          controllerName = remoteController.getSelectedRoutes().get(0).getName().toString();
        }
        return new DeviceInfo.Builder(DeviceInfo.PLAYBACK_TYPE_REMOTE)
            .setMaxVolume(MAX_VOLUME)
            .setRoutingControllerId(remoteController.getId())
            .setRoutingControllerName(controllerName)
            .build();
      }
    }

    /**
     * Empty {@link RouteCallback} implementation necessary for registering the {@link MediaRouter2}
     * instance with the system_server.
     *
     * <p>This callback must be registered so that the media router service notifies the {@link
     * MediaRouter2TransferCallbackImpl} of transfer events.
     */
    private final class MediaRouter2RouteCallbackImpl extends RouteCallback {}

    /**
     * {@link TransferCallback} implementation to listen for {@link RoutingController} creation and
     * releases.
     */
    private final class MediaRouter2TransferCallbackImpl extends TransferCallback {

      @Override
      public void onTransfer(RoutingController oldController, RoutingController newController) {
        updateDeviceInfo();
      }

      @Override
      public void onStop(RoutingController controller) {
        updateDeviceInfo();
      }
    }
  }

  @RequiresApi(34)
  private static final class Api34Impl {
    private Api34Impl() {}

    @Nullable
    @DoNotInline
    public static String getRoutingControllerName(RoutingController controller) {
      RoutingSessionInfo sessionInfo = controller.getRoutingSessionInfo();
      CharSequence name = sessionInfo != null ? sessionInfo.getName() : null;
      return name != null ? name.toString() : null;
    }
  }

  private final class CastListener extends com.google.android.gms.cast.Cast.Listener {

    @Override
    public void onVolumeChanged() {
      updateDeviceVolumeAndNotifyIfChanged();
      listeners.flushEvents();
    }
  }

  private class MediaQueueCallback extends MediaQueue.Callback {

    @Override
    public void mediaQueueChanged() {
      updateTimelineAndNotifyIfChanged();
      listeners.flushEvents();
    }
  }
}
