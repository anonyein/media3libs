/*
 * Copyright 2021 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.ui;

import static androidx.media3.common.Player.COMMAND_GET_METADATA;

import android.app.PendingIntent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.text.TextUtils;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.ui.PlayerNotificationManager.BitmapCallback;
import androidx.media3.ui.PlayerNotificationManager.MediaDescriptionAdapter;
import org.jspecify.annotations.Nullable;

/**
 * Default implementation of {@link MediaDescriptionAdapter}.
 *
 * <p>Uses values from the {@link Player#getMediaMetadata() player mediaMetadata} to populate the
 * notification.
 */
@UnstableApi
public final class DefaultMediaDescriptionAdapter implements MediaDescriptionAdapter {

  private final @Nullable PendingIntent pendingIntent;

  /**
   * Creates a default {@link MediaDescriptionAdapter}.
   *
   * @param pendingIntent The {@link PendingIntent} to be returned from {@link
   *     #createCurrentContentIntent(Player)}, or null if no intent should be fired.
   */
  public DefaultMediaDescriptionAdapter(@Nullable PendingIntent pendingIntent) {
    this.pendingIntent = pendingIntent;
  }

  @Override
  public CharSequence getCurrentContentTitle(Player player) {
    if (!player.isCommandAvailable(COMMAND_GET_METADATA)) {
      return "";
    }
    @Nullable CharSequence displayTitle = player.getMediaMetadata().displayTitle;
    if (!TextUtils.isEmpty(displayTitle)) {
      return displayTitle;
    }

    @Nullable CharSequence title = player.getMediaMetadata().title;
    return title != null ? title : "";
  }

  @Override
  public @Nullable PendingIntent createCurrentContentIntent(Player player) {
    return pendingIntent;
  }

  @Override
  public @Nullable CharSequence getCurrentContentText(Player player) {
    if (!player.isCommandAvailable(COMMAND_GET_METADATA)) {
      return null;
    }
    @Nullable CharSequence artist = player.getMediaMetadata().artist;
    if (!TextUtils.isEmpty(artist)) {
      return artist;
    }

    return player.getMediaMetadata().albumArtist;
  }

  @Override
  public @Nullable Bitmap getCurrentLargeIcon(Player player, BitmapCallback callback) {
    if (!player.isCommandAvailable(COMMAND_GET_METADATA)) {
      return null;
    }
    byte @Nullable [] data = player.getMediaMetadata().artworkData;
    if (data == null) {
      return null;
    }
    return BitmapFactory.decodeByteArray(data, /* offset= */ 0, data.length);
  }
}
