/*
 * Copyright 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.transformer;

import static com.google.common.base.Preconditions.checkNotNull;

import android.content.Context;
import android.util.Pair;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MediaItem;
import androidx.media3.common.util.Util;
import com.google.common.base.Supplier;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.SettableFuture;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.jspecify.annotations.Nullable;

/** Utility methods used in transmux-transcode exports. */
/* package */ final class TransmuxTranscodeHelper {

  /** Provides metadata required to resume an export. */
  public static final class ResumeMetadata {
    /** The last sync sample timestamp of the previous output file. */
    public final long lastSyncSampleTimestampUs;

    /**
     * A {@link List} containing the index of the first {@link EditedMediaItem} to process and its
     * {@linkplain androidx.media3.common.MediaItem.ClippingConfiguration#startPositionMs additional
     * offset} for each {@link EditedMediaItemSequence} in a {@link Composition}.
     */
    public final ImmutableList<Pair<Integer, Long>> firstMediaItemIndexAndOffsetInfo;

    /** The video {@link Format} or {@code null} if there is no video track. */
    public final @Nullable Format videoFormat;

    public ResumeMetadata(
        long lastSyncSampleTimestampUs,
        ImmutableList<Pair<Integer, Long>> firstMediaItemIndexAndOffsetInfo,
        @Nullable Format videoFormat) {
      this.lastSyncSampleTimestampUs = lastSyncSampleTimestampUs;
      this.firstMediaItemIndexAndOffsetInfo = firstMediaItemIndexAndOffsetInfo;
      this.videoFormat = videoFormat;
    }
  }

  // Large enough to copy efficiently, small enough that cancel() isn't blocked for long.
  private static final int COPY_BUFFER_SIZE = 64 * 1024;

  public static ListenableFuture<Mp4Info> getMp4Info(
      Context context, String filePath, long timeUs) {
    SettableFuture<Mp4Info> mp4InfoSettableFuture = SettableFuture.create();
    new Thread("TransmuxTranscodeHelper:Mp4Info") {
      @Override
      public void run() {
        try {
          mp4InfoSettableFuture.set(Mp4Info.create(context, filePath, timeUs));
        } catch (Exception ex) {
          mp4InfoSettableFuture.setException(ex);
        }
      }
    }.start();
    return mp4InfoSettableFuture;
  }

  public static Composition buildUponCompositionForTrimOptimization(
      Composition oldComposition,
      long startTimeUs,
      long endTimeUs,
      long mediaDurationUs,
      boolean startsAtKeyFrame,
      boolean clearVideoEffects) {
    EditedMediaItemSequence sequence = oldComposition.sequences.get(0);
    EditedMediaItem firstEditedMediaItem = sequence.editedMediaItems.get(0);

    MediaItem.ClippingConfiguration clippingConfiguration =
        new MediaItem.ClippingConfiguration.Builder()
            .setStartPositionUs(startTimeUs)
            .setEndPositionUs(endTimeUs)
            .setStartsAtKeyFrame(startsAtKeyFrame)
            .build();

    MediaItem mediaItem =
        firstEditedMediaItem
            .mediaItem
            .buildUpon()
            .setClippingConfiguration(clippingConfiguration)
            .build();
    Effects effects =
        clearVideoEffects
            ? new Effects(
                firstEditedMediaItem.effects.audioProcessors,
                /* videoEffects= */ ImmutableList.of())
            : firstEditedMediaItem.effects;
    EditedMediaItem editedMediaItem =
        firstEditedMediaItem
            .buildUpon()
            .setMediaItem(mediaItem)
            .setDurationUs(mediaDurationUs)
            .setEffects(effects)
            .build();

    return oldComposition
        .buildUpon()
        .setSequences(
            ImmutableList.of(sequence.copyWithEditedMediaItems(ImmutableList.of(editedMediaItem))))
        .build();
  }

  private TransmuxTranscodeHelper() {}

  /**
   * Returns a video only {@link Composition} from the given {@code filePath} and {@code
   * clippingEndPositionUs}.
   */
  public static Composition createVideoOnlyComposition(
      String filePath, long clippingEndPositionUs) {
    MediaItem.ClippingConfiguration clippingConfiguration =
        new MediaItem.ClippingConfiguration.Builder()
            .setEndPositionMs(Util.usToMs(clippingEndPositionUs))
            .build();
    EditedMediaItem editedMediaItem =
        new EditedMediaItem.Builder(
                new MediaItem.Builder()
                    .setUri(filePath)
                    .setClippingConfiguration(clippingConfiguration)
                    .build())
            .setRemoveAudio(true)
            .build();
    EditedMediaItemSequence sequence =
        EditedMediaItemSequence.withVideoFrom(ImmutableList.of(editedMediaItem));
    return new Composition.Builder(sequence).build();
  }

  /**
   * Returns a {@link Composition} for transcoding audio and transmuxing video.
   *
   * @param composition The {@link Composition} to transcode audio from.
   * @param videoFilePath The video only file path to transmux video.
   * @return The {@link Composition}.
   */
  public static Composition createAudioTranscodeAndVideoTransmuxComposition(
      Composition composition, String videoFilePath) {
    Composition compositionWithAudioOnlySequences =
        TransmuxTranscodeHelper.buildUponComposition(
            checkNotNull(composition),
            /* sequenceTrackTypes= */ ImmutableSet.of(C.TRACK_TYPE_AUDIO),
            /* resumeMetadata= */ null);

    Composition.Builder compositionBuilder = compositionWithAudioOnlySequences.buildUpon();
    List<EditedMediaItemSequence> sequences =
        new ArrayList<>(compositionWithAudioOnlySequences.sequences);

    // Video stream sequence.
    EditedMediaItem videoOnlyEditedMediaItem =
        new EditedMediaItem.Builder(new MediaItem.Builder().setUri(videoFilePath).build()).build();
    EditedMediaItemSequence videoOnlySequence =
        EditedMediaItemSequence.withVideoFrom(ImmutableList.of(videoOnlyEditedMediaItem));

    sequences.add(videoOnlySequence);
    compositionBuilder.setSequences(sequences);
    compositionBuilder.setTransmuxVideo(true);
    return compositionBuilder.build();
  }

  /**
   * Builds a new {@link Composition} from a given {@link Composition}.
   *
   * <p>The new {@link Composition} will be built based on {@link
   * ResumeMetadata#firstMediaItemIndexAndOffsetInfo}.
   */
  public static Composition buildUponComposition(
      Composition composition,
      Set<@C.TrackType Integer> sequenceTrackTypes,
      @Nullable ResumeMetadata resumeMetadata) {
    Composition.Builder compositionBuilder = composition.buildUpon();
    ImmutableList<EditedMediaItemSequence> editedMediaItemSequenceList = composition.sequences;
    List<EditedMediaItemSequence> newEditedMediaItemSequenceList = new ArrayList<>();
    @Nullable List<Pair<Integer, Long>> firstMediaItemIndexAndOffsetInfo =
        resumeMetadata != null ? resumeMetadata.firstMediaItemIndexAndOffsetInfo : null;

    for (int sequenceIndex = 0;
        sequenceIndex < editedMediaItemSequenceList.size();
        sequenceIndex++) {
      EditedMediaItemSequence currentEditedMediaItemSequence =
          editedMediaItemSequenceList.get(sequenceIndex);
      ImmutableList<EditedMediaItem> editedMediaItemList =
          currentEditedMediaItemSequence.editedMediaItems;
      List<EditedMediaItem> newEditedMediaItemList = new ArrayList<>();

      int firstMediaItemIndex = 0;
      long firstMediaItemOffsetUs = 0L;

      if (firstMediaItemIndexAndOffsetInfo != null) {
        firstMediaItemIndex = firstMediaItemIndexAndOffsetInfo.get(sequenceIndex).first;
        firstMediaItemOffsetUs = firstMediaItemIndexAndOffsetInfo.get(sequenceIndex).second;
      }

      for (int mediaItemIndex = firstMediaItemIndex;
          mediaItemIndex < editedMediaItemList.size();
          mediaItemIndex++) {
        EditedMediaItem currentEditedMediaItem = editedMediaItemList.get(mediaItemIndex);
        EditedMediaItem.Builder newEditedMediaItemBuilder = currentEditedMediaItem.buildUpon();

        if (mediaItemIndex == firstMediaItemIndex) {
          MediaItem.ClippingConfiguration clippingConfiguration =
              currentEditedMediaItem
                  .mediaItem
                  .clippingConfiguration
                  .buildUpon()
                  .setStartPositionMs(
                      currentEditedMediaItem.mediaItem.clippingConfiguration.startPositionMs
                          + Util.usToMs(firstMediaItemOffsetUs))
                  .build();
          newEditedMediaItemBuilder.setMediaItem(
              currentEditedMediaItem
                  .mediaItem
                  .buildUpon()
                  .setClippingConfiguration(clippingConfiguration)
                  .build());
        }

        newEditedMediaItemList.add(newEditedMediaItemBuilder.build());
      }

      newEditedMediaItemSequenceList.add(
          new EditedMediaItemSequence.Builder(sequenceTrackTypes)
              .addItems(newEditedMediaItemList)
              .setIsLooping(currentEditedMediaItemSequence.isLooping)
              .build());
    }
    compositionBuilder.setSequences(newEditedMediaItemSequenceList);
    return compositionBuilder.build();
  }

  /**
   * Returns the {@link ResumeMetadata} for the given input.
   *
   * @param context The {@link Context}.
   * @param filePath The old file path to resume the export from.
   * @param composition The {@link Composition} to export.
   * @return The {@link ResumeMetadata}.
   * @throws IOException If an error occurs reading the input.
   */
  public static ResumeMetadata getResumeMetadata(
      Context context, String filePath, Composition composition) throws IOException {
    Mp4Info mp4Info = Mp4Info.create(context, filePath);
    long lastSyncSampleTimestampUs = mp4Info.lastSyncSampleTimestampUs;

    ImmutableList.Builder<Pair<Integer, Long>> firstMediaItemIndexAndOffsetInfoBuilder =
        new ImmutableList.Builder<>();
    if (lastSyncSampleTimestampUs != C.TIME_UNSET) {
      for (int compositionSequenceIndex = 0;
          compositionSequenceIndex < composition.sequences.size();
          compositionSequenceIndex++) {
        ImmutableList<EditedMediaItem> editedMediaItemList =
            composition.sequences.get(compositionSequenceIndex).editedMediaItems;
        long remainingDurationUsToSkip = lastSyncSampleTimestampUs;
        int editedMediaItemIndex = 0;
        long mediaItemOffset = 0L;
        while (editedMediaItemIndex < editedMediaItemList.size() && remainingDurationUsToSkip > 0) {
          long mediaItemDuration =
              getMediaItemDurationUs(
                  context, editedMediaItemList.get(editedMediaItemIndex).mediaItem);
          if (mediaItemDuration > remainingDurationUsToSkip) {
            mediaItemOffset = remainingDurationUsToSkip;
            break;
          }

          remainingDurationUsToSkip -= mediaItemDuration;
          editedMediaItemIndex++;
        }
        firstMediaItemIndexAndOffsetInfoBuilder.add(
            new Pair<>(editedMediaItemIndex, mediaItemOffset));
      }
    }
    return new ResumeMetadata(
        lastSyncSampleTimestampUs,
        firstMediaItemIndexAndOffsetInfoBuilder.build(),
        mp4Info.videoFormat);
  }

  /**
   * Copies {@link File} content from source to destination.
   *
   * @param source The {@link File} to copy from.
   * @param destination The {@link File} to copy to.
   * @param isCancelled Whether to stop copying. Checked before copying each chunk, so that copying
   *     a large file can be stopped early, leaving the destination partially written.
   * @throws IOException If an error occurs while copying.
   */
  public static void copyFile(File source, File destination, Supplier<Boolean> isCancelled)
      throws IOException {
    try (InputStream input = new FileInputStream(source);
        OutputStream output = new FileOutputStream(destination)) {
      byte[] buffer = new byte[COPY_BUFFER_SIZE];
      int bytesRead;
      while (!isCancelled.get() && (bytesRead = input.read(buffer)) != -1) {
        output.write(buffer, /* off= */ 0, bytesRead);
      }
    }
  }

  private static long getMediaItemDurationUs(Context context, MediaItem mediaItem)
      throws IOException {
    String filePath = checkNotNull(mediaItem.localConfiguration).uri.toString();
    long startUs = Util.msToUs(mediaItem.clippingConfiguration.startPositionMs);
    long endUs;
    if (mediaItem.clippingConfiguration.endPositionMs != C.TIME_END_OF_SOURCE) {
      endUs = Util.msToUs(mediaItem.clippingConfiguration.endPositionMs);
    } else {
      endUs = Mp4Info.create(context, filePath).durationUs;
    }

    return endUs - startUs;
  }
}
