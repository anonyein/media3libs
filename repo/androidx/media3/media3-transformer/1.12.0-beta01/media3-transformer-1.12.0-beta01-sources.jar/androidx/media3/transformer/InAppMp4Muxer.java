/*
 * Copyright 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.transformer;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkState;

import android.os.ParcelFileDescriptor;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MediaLibraryInfo;
import androidx.media3.common.Metadata;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.util.Log;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.container.Mp4OrientationData;
import androidx.media3.muxer.BufferInfo;
import androidx.media3.muxer.Mp4Muxer;
import androidx.media3.muxer.Muxer;
import androidx.media3.muxer.MuxerException;
import androidx.media3.muxer.MuxerUtil;
import androidx.media3.muxer.SeekableMuxerOutput;
import com.google.common.collect.ImmutableList;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;
import org.jspecify.annotations.Nullable;

/** {@link Muxer} implementation that uses an {@link Mp4Muxer}. */
@UnstableApi
public final class InAppMp4Muxer implements Muxer {
  /** Provides {@linkplain Metadata.Entry metadata} to add in the output MP4 file. */
  public interface MetadataProvider {

    /**
     * Updates the list of {@linkplain Metadata.Entry metadata entries}.
     *
     * <p>A {@link Metadata.Entry} can be added or removed. To modify an existing {@link
     * Metadata.Entry}, first remove it and then add a new one.
     *
     * <p>For the list of supported metadata refer to {@link
     * Mp4Muxer#addMetadataEntry(Metadata.Entry)}.
     */
    void updateMetadataEntries(Set<Metadata.Entry> metadataEntries);
  }

  /** {@link Muxer.Factory} for {@link InAppMp4Muxer}. */
  public static final class Factory implements Muxer.Factory {
    private final @Nullable MetadataProvider metadataProvider;

    private long videoDurationUs;
    private int freeSpaceAfterFileTypeBoxBytes;
    private boolean attemptStreamableOutputEnabled;

    /** Creates an instance with default values. */
    public Factory() {
      this(/* metadataProvider= */ null);
    }

    /**
     * Creates an instance.
     *
     * @param metadataProvider A {@link MetadataProvider}.
     */
    public Factory(@Nullable MetadataProvider metadataProvider) {
      this.metadataProvider = metadataProvider;
      videoDurationUs = C.TIME_UNSET;
      attemptStreamableOutputEnabled = true;
    }

    /**
     * Sets the duration of the video track (in microseconds) in the output.
     *
     * <p>Only the duration of the last sample is adjusted to achieve the given duration. Duration
     * of the other samples remains unchanged.
     *
     * <p>The default is {@link C#TIME_UNSET} to not set any duration in the output. In this case
     * the video track duration is determined by the samples written to it and the duration of the
     * last sample will be same as that of the sample before that.
     *
     * @param videoDurationUs The duration of the video track (in microseconds) in the output, or
     *     {@link C#TIME_UNSET} to not set any duration. Only applicable when a video track is
     *     {@linkplain #addTrack(Format) added}.
     * @return This factory.
     */
    @CanIgnoreReturnValue
    public Factory setVideoDurationUs(long videoDurationUs) {
      this.videoDurationUs = videoDurationUs;
      return this;
    }

    /**
     * Sets whether to attempt to write a file where the metadata is stored at the start, which can
     * make the file more efficient to read sequentially.
     *
     * <p>Setting to {@code true} does not guarantee a streamable MP4 output.
     *
     * <p>Setting to {@code true} reserves space at the start of the file which leads to increased
     * file size. Set this to {@code false} for smaller file size.
     *
     * <p>The default value is {@code true}.
     *
     * @param attemptStreamableOutputEnabled Whether to attempt to write a streamable file.
     * @return This factory.
     */
    @CanIgnoreReturnValue
    public Factory setAttemptStreamableOutputEnabled(boolean attemptStreamableOutputEnabled) {
      this.attemptStreamableOutputEnabled = attemptStreamableOutputEnabled;
      return this;
    }

    /**
     * Sets the amount of free space (in bytes) to be reserved after the File Type box in the MP4
     * file. The amount of free space that gets reserved is handled by {@link
     * Mp4Muxer.Builder#experimentalSetFreeSpaceAfterFileTypeBox(int)}.
     *
     * @param freeSpaceAfterFileTypeBoxBytes The free space after file type box in the output.
     * @return This factory.
     */
    @CanIgnoreReturnValue
    public Factory setFreeSpaceAfterFileTypeBoxBytes(int freeSpaceAfterFileTypeBoxBytes) {
      this.freeSpaceAfterFileTypeBoxBytes = freeSpaceAfterFileTypeBoxBytes;
      return this;
    }

    @Override
    public InAppMp4Muxer create(String path) throws MuxerException {
      FileOutputStream outputStream;
      try {
        outputStream = new FileOutputStream(path);
      } catch (FileNotFoundException e) {
        throw new MuxerException("Error creating file output stream", e);
      }

      Mp4Muxer.Builder builder =
          new Mp4Muxer.Builder(SeekableMuxerOutput.of(outputStream))
              .setAttemptStreamableOutputEnabled(attemptStreamableOutputEnabled);
      if (freeSpaceAfterFileTypeBoxBytes > 0) {
        builder.experimentalSetFreeSpaceAfterFileTypeBox(freeSpaceAfterFileTypeBoxBytes);
      }
      Mp4Muxer muxer = builder.build();

      return new InAppMp4Muxer(muxer, metadataProvider, videoDurationUs);
    }

    @Override
    public InAppMp4Muxer create(ParcelFileDescriptor pfd) throws MuxerException {
      @Nullable Mp4Muxer muxer = null;
      try {
        checkArgument(pfd.getFileDescriptor().valid(), "ParcelFileDescriptor is closed or invalid");
        SeekableMuxerOutput seekableMuxerOutput = SeekableMuxerOutput.of(pfd);
        validateSeekable(seekableMuxerOutput);
        Mp4Muxer.Builder builder =
            new Mp4Muxer.Builder(seekableMuxerOutput)
                .setAttemptStreamableOutputEnabled(attemptStreamableOutputEnabled);
        if (freeSpaceAfterFileTypeBoxBytes > 0) {
          builder.experimentalSetFreeSpaceAfterFileTypeBox(freeSpaceAfterFileTypeBoxBytes);
        }
        muxer = builder.build();

        return new InAppMp4Muxer(muxer, metadataProvider, videoDurationUs);
      } catch (MuxerException e) {
        closeResourceAndSuppressException(e, muxer, pfd);
        throw e;
      } catch (RuntimeException e) {
        MuxerException muxerException =
            new MuxerException("Error creating InAppMp4Muxer from ParcelFileDescriptor", e);
        closeResourceAndSuppressException(muxerException, muxer, pfd);
        throw muxerException;
      }
    }

    private static void validateSeekable(SeekableMuxerOutput seekableMuxerOutput)
        throws MuxerException {
      try {
        long unused = seekableMuxerOutput.getPosition();
      } catch (IOException e) {
        throw new MuxerException(
            "The provided ParcelFileDescriptor is not seekable. FragmentedMp4Muxer is required"
                + " for non-seekable output.",
            e);
      }
    }

    private static void closeResourceAndSuppressException(
        MuxerException muxerException, @Nullable Mp4Muxer muxer, ParcelFileDescriptor pfd) {
      if (muxer != null) {
        try {
          muxer.close();
        } catch (MuxerException e) {
          muxerException.addSuppressed(e);
        }
      } else {
        try {
          pfd.close();
        } catch (IOException e) {
          muxerException.addSuppressed(e);
        }
      }
    }

    @Override
    public ImmutableList<String> getSupportedSampleMimeTypes(@C.TrackType int trackType) {
      if (trackType == C.TRACK_TYPE_VIDEO) {
        return Mp4Muxer.SUPPORTED_VIDEO_SAMPLE_MIME_TYPES;
      } else if (trackType == C.TRACK_TYPE_AUDIO) {
        return Mp4Muxer.SUPPORTED_AUDIO_SAMPLE_MIME_TYPES;
      }
      return ImmutableList.of();
    }

    @Override
    public boolean supportsWritingNegativeTimestampsInEditList() {
      return true;
    }
  }

  public static final String MUXER_NAME =
      "androidx.media3:media3-muxer:" + MediaLibraryInfo.VERSION;

  private static final String TAG = "InAppMp4Muxer";
  private static final int TRACK_ID_UNSET = -1;

  private final Mp4Muxer muxer;
  private final @Nullable MetadataProvider metadataProvider;
  private final long videoDurationUs;
  private final Set<Metadata.Entry> metadataEntries;

  private int videoTrackId;
  private boolean isClosed;

  private InAppMp4Muxer(
      Mp4Muxer muxer, @Nullable MetadataProvider metadataProvider, long videoDurationUs) {
    this.muxer = muxer;
    this.metadataProvider = metadataProvider;
    this.videoDurationUs = videoDurationUs;
    metadataEntries = new LinkedHashSet<>();
    videoTrackId = TRACK_ID_UNSET;
  }

  @Override
  public int addTrack(Format format) throws MuxerException {
    checkState(!isClosed, "InAppMp4Muxer is closed.");
    int trackId = muxer.addTrack(format);
    if (MimeTypes.isVideo(format.sampleMimeType)) {
      muxer.addMetadataEntry(new Mp4OrientationData(format.rotationDegrees));
      videoTrackId = trackId;
    }
    return trackId;
  }

  @Override
  public void writeSampleData(int trackId, ByteBuffer byteBuffer, BufferInfo bufferInfo)
      throws MuxerException {
    checkState(!isClosed, "InAppMp4Muxer is closed.");
    if (videoDurationUs != C.TIME_UNSET
        && trackId == videoTrackId
        && bufferInfo.presentationTimeUs > videoDurationUs) {
      Log.w(
          TAG,
          String.format(
              Locale.US,
              "Skipped sample with presentation time (%d) > video duration (%d)",
              bufferInfo.presentationTimeUs,
              videoDurationUs));
      return;
    }
    muxer.writeSampleData(trackId, byteBuffer, bufferInfo);
  }

  @Override
  public void addMetadataEntry(Metadata.Entry metadataEntry) {
    checkState(!isClosed, "InAppMp4Muxer is closed.");
    if (MuxerUtil.isMetadataSupported(metadataEntry)) {
      metadataEntries.add(metadataEntry);
    }
  }

  @Override
  @SuppressWarnings("TryWithResourcesVariable") // try (muxer) requires Java 9.
  public void close() throws MuxerException {
    if (isClosed) {
      return;
    }
    isClosed = true;
    // TODO: b/502167525 - Use try (muxer) once Media3 compiles with Java 11.
    try (Mp4Muxer unused = muxer) {
      if (videoDurationUs != C.TIME_UNSET && videoTrackId != TRACK_ID_UNSET) {
        BufferInfo bufferInfo =
            new BufferInfo(
                /* presentationTimeUs= */ videoDurationUs,
                /* size= */ 0,
                C.BUFFER_FLAG_END_OF_STREAM);
        muxer.writeSampleData(videoTrackId, ByteBuffer.allocateDirect(0), bufferInfo);
      }
      writeMetadata();
    }
  }

  private void writeMetadata() {
    if (metadataProvider != null) {
      Set<Metadata.Entry> metadataEntriesCopy = new LinkedHashSet<>(metadataEntries);
      metadataProvider.updateMetadataEntries(metadataEntriesCopy);
      metadataEntries.clear();
      metadataEntries.addAll(metadataEntriesCopy);
    }

    for (Metadata.Entry entry : metadataEntries) {
      muxer.addMetadataEntry(entry);
    }
  }
}
