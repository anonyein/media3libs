/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.transformer;

import static androidx.media3.transformer.ExportException.ERROR_CODE_MUXING_APPEND;
import static androidx.media3.transformer.ExportResult.OPTIMIZATION_FAILED_FORMAT_MISMATCH;
import static androidx.media3.transformer.Transformer.PROGRESS_STATE_AVAILABLE;
import static androidx.media3.transformer.Transformer.PROGRESS_STATE_NOT_STARTED;
import static androidx.media3.transformer.Transformer.PROGRESS_STATE_UNAVAILABLE;
import static androidx.media3.transformer.Transformer.PROGRESS_STATE_WAITING_FOR_AVAILABILITY;
import static androidx.media3.transformer.TransformerUtil.releaseMuxerWrapperQuietly;
import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;
import static java.lang.Math.round;
import static java.lang.annotation.ElementType.TYPE_USE;

import android.content.Context;
import android.media.metrics.LogSessionId;
import androidx.annotation.IntDef;
import androidx.media3.common.C;
import androidx.media3.common.C.TrackType;
import androidx.media3.common.DebugViewProvider;
import androidx.media3.common.Format;
import androidx.media3.common.VideoFrameProcessor;
import androidx.media3.common.util.Clock;
import androidx.media3.common.util.HandlerWrapper;
import androidx.media3.common.video.FrameProcessor;
import androidx.media3.effect.DebugTraceUtil;
import androidx.media3.effect.HardwareBufferJniWrapper;
import androidx.media3.muxer.Muxer;
import androidx.media3.transformer.ExportResult.ProcessedInput;
import androidx.media3.transformer.Transformer.ProgressState;
import androidx.media3.transformer.TransmuxTranscodeHelper.ResumeMetadata;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import java.io.File;
import java.io.IOException;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.checkerframework.checker.nullness.qual.MonotonicNonNull;
import org.jspecify.annotations.Nullable;

/** An {@link ExportOperation} implementation for resumed exports. */
/* package */ final class ResumedExportOperation implements ExportOperation {

  @Documented
  @Retention(RetentionPolicy.SOURCE)
  @Target(TYPE_USE)
  @IntDef({
    STATE_PROCESS_FULL_INPUT,
    STATE_REMUX_PROCESSED_VIDEO,
    STATE_PROCESS_REMAINING_VIDEO,
    STATE_PROCESS_AUDIO,
    STATE_COPY_OUTPUT
  })
  private @interface ExportState {}

  /** The default Transformer state. */
  private static final int STATE_PROCESS_FULL_INPUT = 0;

  /**
   * The first state of a resumed export.
   *
   * <p>In this state, the paused export file's encoded video track is muxed into a video-only file,
   * stored at {@code oldFilePath}.
   *
   * <p>The video-only file is kept open to allow the {@link #STATE_PROCESS_REMAINING_VIDEO} to
   * continue writing to the same file & video track.
   *
   * <p>A successful operation in this state moves the Transformer to the {@link
   * #STATE_PROCESS_REMAINING_VIDEO} state.
   */
  private static final int STATE_REMUX_PROCESSED_VIDEO = 1;

  /**
   * The second state of a resumed export.
   *
   * <p>In this state, the remaining {@link Composition} video data is processed and muxed into the
   * same video-only file, stored at {@code oldFilePath}.
   *
   * <p>A successful operation in this state moves the Transformer to the {@link
   * #STATE_PROCESS_AUDIO} state.
   */
  private static final int STATE_PROCESS_REMAINING_VIDEO = 2;

  /**
   * The third state of a resumed export.
   *
   * <p>In this state, the entire {@link Composition} audio is processed and muxed. This same
   * operation also transmuxes the video-only file produced by {@link
   * #STATE_PROCESS_REMAINING_VIDEO}, interleaving of the audio and video tracks. The output is
   * stored at {@code oldFilePath}.
   *
   * <p>A successful operation in this state moves the Transformer to the {@link #STATE_COPY_OUTPUT}
   * state.
   */
  private static final int STATE_PROCESS_AUDIO = 3;

  /**
   * The final state of a resumed export.
   *
   * <p>In this state, the successful exported file (stored at {@code oldFilePath}) is copied to the
   * {@code outputFilePath}.
   */
  private static final int STATE_COPY_OUTPUT = 4;

  private final Context context;
  private final Composition composition;
  private final TransformationRequest transformationRequest;
  private final AssetLoader.@Nullable Factory assetLoaderFactory;
  private final AudioMixer.Factory audioMixerFactory;
  private final VideoFrameProcessor.Factory videoFrameProcessorFactory;
  private final Codec.EncoderFactory encoderFactory;
  private final ImmutableList<Integer> allowedEncodingRotationDegrees;
  private final int maxFramesInEncoder;
  private final ExportOperation.Listener listener;
  private final FallbackListener fallbackListener;
  private final DebugViewProvider debugViewProvider;
  private final Clock clock;

  private final FrameProcessor.@Nullable Factory frameProcessorFactory;

  private final @Nullable HardwareBufferJniWrapper hardwareBufferJniWrapper;

  private final @Nullable LogSessionId logSessionId;
  private final boolean applyMp4EditListTrim;
  private final Muxer.Factory muxerFactory;
  private final String outputFilePath;
  private final String oldFilePath;
  private final ExportResult.Builder exportResultBuilder;
  private final ComponentListener componentListener;
  private final ExportOperationRunner runner;

  // Written on the internal thread, read on the application thread.
  private volatile CurrentStage currentStage;

  // Must only be accessed from the internal thread.
  private @ExportState int state;
  private @MonotonicNonNull ResumeMetadata resumeMetadata;
  private @Nullable MuxerWrapper remuxingMuxerWrapper;

  public ResumedExportOperation(
      Context context,
      Composition composition,
      TransformationRequest transformationRequest,
      AssetLoader.@Nullable Factory assetLoaderFactory,
      AudioMixer.Factory audioMixerFactory,
      VideoFrameProcessor.Factory videoFrameProcessorFactory,
      Codec.EncoderFactory encoderFactory,
      ImmutableList<Integer> allowedEncodingRotationDegrees,
      int maxFramesInEncoder,
      ExportOperation.Listener listener,
      FallbackListener fallbackListener,
      HandlerWrapper applicationHandler,
      DebugViewProvider debugViewProvider,
      Clock clock,
      FrameProcessor.@Nullable Factory frameProcessorFactory,
      @Nullable HardwareBufferJniWrapper hardwareBufferJniWrapper,
      @Nullable LogSessionId logSessionId,
      boolean applyMp4EditListTrim,
      Muxer.Factory muxerFactory,
      String outputFilePath,
      String oldFilePath) {
    this.context = context;
    checkArgument(
        composition.sequences.size() == 1,
        "Resume is supported only for single sequence composition");
    this.composition = composition;
    this.transformationRequest = transformationRequest;
    this.assetLoaderFactory = assetLoaderFactory;
    this.audioMixerFactory = audioMixerFactory;
    this.videoFrameProcessorFactory = videoFrameProcessorFactory;
    this.encoderFactory = encoderFactory;
    this.allowedEncodingRotationDegrees = allowedEncodingRotationDegrees;
    this.maxFramesInEncoder = maxFramesInEncoder;
    this.listener = listener;
    this.fallbackListener = fallbackListener;
    this.debugViewProvider = debugViewProvider;
    this.clock = clock;
    this.frameProcessorFactory = frameProcessorFactory;
    this.hardwareBufferJniWrapper = hardwareBufferJniWrapper;
    this.logSessionId = logSessionId;
    this.applyMp4EditListTrim = applyMp4EditListTrim;
    this.muxerFactory = muxerFactory;
    this.outputFilePath = outputFilePath;
    this.oldFilePath = oldFilePath;
    exportResultBuilder = new ExportResult.Builder();
    componentListener = new ComponentListener();
    runner =
        new ExportOperationRunner(
            "Transformer:ResumedExport", clock, applicationHandler, componentListener);
    state = STATE_PROCESS_FULL_INPUT;
    currentStage = new CurrentStage(state, /* transformerInternal= */ null);
  }

  @Override
  public void start() {
    runner.start(this::remuxProcessedVideoInternal);
  }

  @Override
  public @ProgressState int getProgress(ProgressHolder progressHolder) {
    // Read once, as the current stage is replaced on the internal thread.
    CurrentStage currentStage = this.currentStage;
    @ExportState int state = currentStage.state;
    @Nullable TransformerInternal transformerInternal = currentStage.transformerInternal;

    if (state == STATE_PROCESS_FULL_INPUT) {
      return getNextAccumulatedProgress(
          transformerInternal, /* progressSoFar= */ 0, /* nextProgressWeight= */ 1, progressHolder);
    }

    float remuxProcessedVideoProgressWeight = 0.15f;
    float processRemainingVideoProgressWeight = 0.40f;
    float processAudioProgressWeight = 0.30f;
    // Remaining 15% progress is for copying the output to the final location.

    float progressSoFar = 0f;
    if (state == STATE_REMUX_PROCESSED_VIDEO) {
      return getNextAccumulatedProgress(
          transformerInternal, progressSoFar, remuxProcessedVideoProgressWeight, progressHolder);
    }
    progressSoFar = remuxProcessedVideoProgressWeight * 100;
    if (state == STATE_PROCESS_REMAINING_VIDEO) {
      return getNextAccumulatedProgress(
          transformerInternal, progressSoFar, processRemainingVideoProgressWeight, progressHolder);
    }
    progressSoFar += processRemainingVideoProgressWeight * 100;
    if (state == STATE_PROCESS_AUDIO) {
      return getNextAccumulatedProgress(
          transformerInternal, progressSoFar, processAudioProgressWeight, progressHolder);
    }
    progressSoFar += processAudioProgressWeight * 100;

    // Progress for copying the output can not be determined. After this, the export should complete
    // soon indicating 100% progress.
    progressHolder.progress = round(progressSoFar);
    return PROGRESS_STATE_AVAILABLE;
  }

  @Override
  public void cancel() {
    runner.cancel();
  }

  @Override
  public void endWithException(ExportException exportException) {
    runner.endWithException(exportException);
  }

  private void remuxProcessedVideoInternal() {
    state = STATE_REMUX_PROCESSED_VIDEO;
    ResumeMetadata resumeMetadata;
    try {
      resumeMetadata =
          TransmuxTranscodeHelper.getResumeMetadata(
              context, checkNotNull(oldFilePath), checkNotNull(composition));
    } catch (IOException | RuntimeException e) {
      // In case of error fallback to normal Export.
      processFullInputInternal();
      return;
    }
    // If there is no video track to remux or the last sync sample is actually the first
    // sample, then start the normal Export.
    if (resumeMetadata.lastSyncSampleTimestampUs == C.TIME_UNSET
        || resumeMetadata.lastSyncSampleTimestampUs == 0) {
      processFullInputInternal();
      return;
    }

    this.resumeMetadata = resumeMetadata;

    remuxingMuxerWrapper =
        new MuxerWrapper(
            checkNotNull(outputFilePath),
            muxerFactory,
            componentListener,
            MuxerWrapper.MUXER_MODE_MUX_PARTIAL,
            /* dropSamplesBeforeFirstVideoSample= */ false,
            /* appendVideoFormat= */ resumeMetadata.videoFormat);

    startInternal(
        TransmuxTranscodeHelper.createVideoOnlyComposition(
            oldFilePath, /* clippingEndPositionUs= */ resumeMetadata.lastSyncSampleTimestampUs),
        checkNotNull(remuxingMuxerWrapper),
        /* initialTimestampOffsetUs= */ 0,
        /* forceRemuxing= */ true);
  }

  private void processFullInputInternal() {
    state = STATE_PROCESS_FULL_INPUT;
    startInternal(
        checkNotNull(composition),
        new MuxerWrapper(
            checkNotNull(outputFilePath),
            muxerFactory,
            componentListener,
            MuxerWrapper.MUXER_MODE_DEFAULT,
            /* dropSamplesBeforeFirstVideoSample= */ false,
            /* appendVideoFormat= */ null),
        /* initialTimestampOffsetUs= */ 0,
        /* forceRemuxing= */ false);
  }

  private void processRemainingVideoInternal() {
    state = STATE_PROCESS_REMAINING_VIDEO;
    Composition videoOnlyComposition =
        TransmuxTranscodeHelper.buildUponComposition(
            checkNotNull(composition),
            /* sequenceTrackTypes= */ ImmutableSet.of(C.TRACK_TYPE_VIDEO),
            resumeMetadata);

    checkNotNull(remuxingMuxerWrapper);
    remuxingMuxerWrapper.changeToAppendMode();

    startInternal(
        videoOnlyComposition,
        remuxingMuxerWrapper,
        /* initialTimestampOffsetUs= */ checkNotNull(resumeMetadata).lastSyncSampleTimestampUs,
        /* forceRemuxing= */ false);
  }

  private void processAudioInternal() {
    // Skip audio processing for video only composition. Resume operation is supported only for a
    // single sequence composition.
    if (!composition.sequences.get(0).trackTypes.contains(C.TRACK_TYPE_AUDIO)) {
      reportCompletedInternal();
      return;
    }

    state = STATE_PROCESS_AUDIO;

    MuxerWrapper muxerWrapper =
        new MuxerWrapper(
            checkNotNull(oldFilePath),
            muxerFactory,
            componentListener,
            MuxerWrapper.MUXER_MODE_DEFAULT,
            /* dropSamplesBeforeFirstVideoSample= */ false,
            /* appendVideoFormat= */ null);

    startInternal(
        TransmuxTranscodeHelper.createAudioTranscodeAndVideoTransmuxComposition(
            checkNotNull(composition), checkNotNull(outputFilePath)),
        muxerWrapper,
        /* initialTimestampOffsetUs= */ 0,
        /* forceRemuxing= */ false);
  }

  // TODO: b/308253384 - Move copy output logic into MuxerWrapper.
  private void copyOutputInternal() throws ExportException {
    state = STATE_COPY_OUTPUT;
    currentStage = new CurrentStage(state, /* transformerInternal= */ null);
    // If cancel() is called, the copy stops early and the runner skips the result.
    try {
      TransmuxTranscodeHelper.copyFile(
          new File(checkNotNull(oldFilePath)),
          new File(checkNotNull(outputFilePath)),
          runner::isCancelled);
    } catch (IOException e) {
      throw ExportException.createForUnexpected(e);
    }
    reportCompletedInternal();
  }

  private void startInternal(
      Composition composition,
      MuxerWrapper muxerWrapper,
      long initialTimestampOffsetUs,
      boolean forceRemuxing) {
    DebugTraceUtil.reset();
    TransformerInternal transformerInternal =
        new TransformerInternal(
            context,
            composition,
            transformationRequest,
            assetLoaderFactory,
            audioMixerFactory,
            videoFrameProcessorFactory,
            forceRemuxing
                ? new DefaultEncoderFactory.Builder(this.context).build()
                : encoderFactory,
            allowedEncodingRotationDegrees,
            maxFramesInEncoder,
            muxerWrapper,
            runner.getTransformerInternalListener(),
            fallbackListener,
            runner.getInternalHandlerThread(),
            debugViewProvider,
            clock,
            frameProcessorFactory,
            hardwareBufferJniWrapper,
            initialTimestampOffsetUs,
            logSessionId,
            applyMp4EditListTrim,
            forceRemuxing);
    runner.startTransformerInternal(transformerInternal);
    // Published together with the state, so that getProgress() doesn't combine the state of one
    // stage with the TransformerInternal of another.
    currentStage = new CurrentStage(state, transformerInternal);
  }

  private void reportCompletedInternal() {
    ExportResult exportResult = exportResultBuilder.build();
    runner.reportCompleted(() -> listener.onCompleted(exportResult));
  }

  private void reportErrorInternal(ExportException exportException) {
    ExportResult exportResult = exportResultBuilder.setExportException(exportException).build();
    runner.reportError(() -> listener.onError(exportResult, exportException));
  }

  private static @ProgressState int getNextAccumulatedProgress(
      @Nullable TransformerInternal transformerInternal,
      float progressSoFar,
      float nextProgressWeight,
      ProgressHolder progressHolder) {
    if (transformerInternal == null) {
      progressHolder.progress = round(progressSoFar);
      return progressSoFar == 0
          ? PROGRESS_STATE_WAITING_FOR_AVAILABILITY
          : PROGRESS_STATE_AVAILABLE;
    }
    @ProgressState int ongoingProgressState = transformerInternal.getProgress(progressHolder);
    switch (ongoingProgressState) {
      case PROGRESS_STATE_NOT_STARTED:
      case PROGRESS_STATE_WAITING_FOR_AVAILABILITY:
        progressHolder.progress = round(progressSoFar);
        return progressSoFar == 0
            ? PROGRESS_STATE_WAITING_FOR_AVAILABILITY
            : PROGRESS_STATE_AVAILABLE;
      case PROGRESS_STATE_AVAILABLE:
        progressHolder.progress =
            round(progressSoFar + (progressHolder.progress * nextProgressWeight));
        return PROGRESS_STATE_AVAILABLE;
      case PROGRESS_STATE_UNAVAILABLE:
        return PROGRESS_STATE_UNAVAILABLE;
      default:
        throw new IllegalStateException();
    }
  }

  /**
   * Listener for components ({@link ExportOperationRunner} and {@link MuxerWrapper}). All methods
   * are called on the internal thread.
   */
  private final class ComponentListener
      implements ExportOperationRunner.Listener, MuxerWrapper.Listener {

    // ExportOperationRunner.Listener implementation

    @Override
    public void onTransformerInternalCompleted(
        ImmutableList<ProcessedInput> processedInputs,
        @Nullable String audioEncoderName,
        @Nullable String videoEncoderName)
        throws ExportException {
      ExportResultUtil.updateProcessingDetails(
          exportResultBuilder, processedInputs, audioEncoderName, videoEncoderName);
      // TODO: b/213341814 - Add event flags for Transformer events.
      if (state == STATE_REMUX_PROCESSED_VIDEO) {
        processRemainingVideoInternal();
      } else if (state == STATE_PROCESS_REMAINING_VIDEO) {
        remuxingMuxerWrapper = null;
        processAudioInternal();
      } else if (state == STATE_PROCESS_AUDIO) {
        copyOutputInternal();
      } else {
        reportCompletedInternal();
      }
    }

    @Override
    public void onTransformerInternalError(
        ImmutableList<ProcessedInput> processedInputs,
        @Nullable String audioEncoderName,
        @Nullable String videoEncoderName,
        ExportException exportException) {
      ExportResultUtil.updateProcessingDetails(
          exportResultBuilder, processedInputs, audioEncoderName, videoEncoderName);
      if (exportException.errorCode == ERROR_CODE_MUXING_APPEND) {
        remuxingMuxerWrapper = null;
        exportResultBuilder.reset();
        exportResultBuilder.setOptimizationResult(OPTIMIZATION_FAILED_FORMAT_MISMATCH);
        processFullInputInternal();
        return;
      }
      reportErrorInternal(exportException);
    }

    @Override
    public void onStageError(ExportException exportException) {
      reportErrorInternal(exportException);
    }

    @Override
    public void onReleased(boolean discardOutput) {
      if (remuxingMuxerWrapper != null) {
        // The export may have ended while the partially muxed output was kept open for the next
        // stage.
        releaseMuxerWrapperQuietly(remuxingMuxerWrapper);
        remuxingMuxerWrapper = null;
      }
    }

    // MuxerWrapper.Listener implementation

    @Override
    public void onTrackEnded(
        @TrackType int trackType, Format format, int averageBitrate, int sampleCount) {
      ExportResultUtil.updateTrackDetails(
          exportResultBuilder, trackType, format, averageBitrate, sampleCount);
    }

    @Override
    public void onSampleWrittenOrDropped() {
      listener.onSampleWrittenOrDropped();
    }

    @Override
    public void onEnded(long approximateDurationMs) {
      exportResultBuilder.setApproximateDurationMs(approximateDurationMs);
      checkNotNull(runner.getTransformerInternal()).endWithCompletion();
    }

    @Override
    public void onFileSizeBytesAvailable(long fileSizeBytes) {
      exportResultBuilder.setFileSizeBytes(fileSizeBytes);
    }

    @Override
    public void onError(ExportException exportException) {
      runner.endWithException(exportException);
    }
  }

  /** The stage whose progress is reported by {@link #getProgress}. */
  private static final class CurrentStage {

    private final @ExportState int state;
    private final @Nullable TransformerInternal transformerInternal;

    private CurrentStage(
        @ExportState int state, @Nullable TransformerInternal transformerInternal) {
      this.state = state;
      this.transformerInternal = transformerInternal;
    }
  }
}
