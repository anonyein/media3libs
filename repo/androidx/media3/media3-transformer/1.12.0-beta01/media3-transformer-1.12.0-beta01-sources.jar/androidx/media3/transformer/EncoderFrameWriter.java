/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.transformer;

import static android.os.Build.VERSION.SDK_INT;
import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.base.Preconditions.checkState;

import android.annotation.SuppressLint;
import android.hardware.HardwareBuffer;
import android.media.Image;
import android.media.ImageWriter;
import android.media.metrics.LogSessionId;
import android.os.Handler;
import android.view.Surface;
import androidx.annotation.RequiresApi;
import androidx.media3.common.ColorInfo;
import androidx.media3.common.Format;
import androidx.media3.common.VideoFrameProcessingException;
import androidx.media3.common.util.ExperimentalApi;
import androidx.media3.common.video.AsyncFrame;
import androidx.media3.common.video.DefaultHardwareBufferFrame;
import androidx.media3.common.video.Frame;
import androidx.media3.common.video.Frame.Usage;
import androidx.media3.common.video.FrameWriter;
import androidx.media3.common.video.SyncFenceWrapper;
import java.io.IOException;
import java.util.concurrent.Executor;
import org.checkerframework.checker.nullness.qual.MonotonicNonNull;
import org.jspecify.annotations.Nullable;

/**
 * An implementation of {@link FrameWriter} that uses an {@link ImageWriter} to forward frames to a
 * {@linkplain DefaultCodec encoder} via {@link Surface}. Sets the {@link
 * HardwareBuffer#USAGE_VIDEO_ENCODE} flag on the buffers.
 *
 * <p>HDR output (using {@link HardwareBuffer#RGBA_1010102}) is supported from API 34.
 */
@RequiresApi(33)
@ExperimentalApi // TODO: b/498176910 - Remove once FrameWriter is production ready.
public class EncoderFrameWriter implements FrameWriter {

  /** Listener for {@link EncoderFrameWriter} events. */
  public interface Listener {

    /**
     * Called synchronously when {@link EncoderFrameWriter#configure(Format, long)} is called. The
     * returned {@link Format} is used to create the encoder.
     *
     * @deprecated Prepare the {@link Format} in the {@link Codec.EncoderFactory} passed to the
     *     {@link EncoderFrameWriter} constructor instead, so {@link EncoderFrameWriter#getInfo()}
     *     and {@link EncoderFrameWriter#configure(Format, long)} use the same {@link Format}.
     */
    @Deprecated
    default Format onConfigure(Format requestedFormat) {
      return requestedFormat;
    }

    /**
     * Called when the encoder is created so downstream components can receive its output.
     *
     * @deprecated Obtain the created {@link Codec} in {@link
     *     Codec.EncoderFactory#createForVideoEncoding} on the factory passed to the {@link
     *     EncoderFrameWriter} constructor instead.
     */
    @Deprecated
    default void onEncoderCreated(Codec encoder) {}

    /** Called when the end of stream has been reached and is about to be signaled downstream. */
    void onEndOfStream();

    /** Called when an asynchronous error occurs. */
    void onError(VideoFrameProcessingException e);
  }

  private static final int CAPACITY = 4;

  private final Codec.EncoderFactory encoderFactory;
  private final Listener listener;
  private final Executor listenerExecutor;
  private final Handler imageReleaseHandler;
  private final @Nullable LogSessionId logSessionId;

  private int inUseCount;
  private @MonotonicNonNull Format configurationFormat;
  private @Nullable ImageWriter imageWriter;
  private @Nullable Codec encoder;
  private @Nullable Executor wakeupExecutor;
  private @Nullable Runnable wakeupListener;

  public EncoderFrameWriter(
      Codec.EncoderFactory encoderFactory,
      Listener listener,
      Executor listenerExecutor,
      Handler imageReleaseHandler,
      @Nullable LogSessionId logSessionId) {
    this.encoderFactory = encoderFactory;
    this.listener = listener;
    this.listenerExecutor = listenerExecutor;
    this.imageReleaseHandler = imageReleaseHandler;
    this.logSessionId = logSessionId;
  }

  @Override
  public Info getInfo() {
    return (format, usage) ->
        isPixelFormatSupported(format) && encoderFactory.isVideoFormatSupported(format);
  }

  @SuppressLint("WrongConstant") // Using usage as @Usage constant.
  @SuppressWarnings("deprecation") // Calling deprecated listener methods.
  @Override
  public void configure(Format format, @Usage long usage) {
    checkState(imageWriter == null);
    checkState(encoder == null);
    checkArgument(
        isPixelFormatSupported(format),
        "HardwareBuffer.RGBA_1010102 is only supported from API 34.");

    Format encoderFormat = listener.onConfigure(format);
    try {
      encoder = encoderFactory.createForVideoEncoding(encoderFormat, logSessionId);
    } catch (ExportException e) {
      listenerExecutor.execute(() -> listener.onError(VideoFrameProcessingException.from(e)));
      return;
    }

    Surface encoderInputSurface = encoder.getInputSurface();
    Codec nonNullEncoder = encoder;
    listenerExecutor.execute(() -> listener.onEncoderCreated(nonNullEncoder));

    this.configurationFormat = nonNullEncoder.getConfigurationFormat();

    int pixelFormat = getPixelFormat(configurationFormat);

    imageWriter =
        new ImageWriter.Builder(encoderInputSurface)
            .setImageFormat(pixelFormat)
            .setWidthAndHeight(configurationFormat.width, configurationFormat.height)
            .setUsage(Frame.USAGE_VIDEO_ENCODE | usage)
            .setMaxImages(CAPACITY)
            .build();
    imageWriter.setOnImageReleasedListener((writer) -> onImageReleased(), imageReleaseHandler);
  }

  @Override
  public synchronized @Nullable AsyncFrame dequeueInputFrame(
      Executor wakeupExecutor, Runnable wakeupListener) {
    checkState(imageWriter != null);
    if (inUseCount == CAPACITY) {
      this.wakeupExecutor = wakeupExecutor;
      this.wakeupListener = wakeupListener;
      return null;
    }
    @Nullable Image image = imageWriter.dequeueInputImage();
    if (image != null) {
      inUseCount++;
      HardwareBuffer hardwareBuffer = checkNotNull(image.getHardwareBuffer());
      DefaultHardwareBufferFrame frame =
          new DefaultHardwareBufferFrame.Builder(hardwareBuffer)
              .setFormat(checkNotNull(configurationFormat))
              .setInternalImage(image)
              .build();
      return new AsyncFrame(frame, /* acquireFence= */ null);
    }
    this.wakeupExecutor = wakeupExecutor;
    this.wakeupListener = wakeupListener;
    return null;
  }

  @Override
  public void queueInputFrame(Frame frame, @Nullable SyncFenceWrapper writeCompleteFence) {
    checkState(imageWriter != null);
    checkArgument(frame instanceof DefaultHardwareBufferFrame);
    DefaultHardwareBufferFrame hardwareBufferFrame = (DefaultHardwareBufferFrame) frame;
    hardwareBufferFrame.getHardwareBuffer().close();
    @Nullable Image image = (Image) hardwareBufferFrame.getInternalImage();
    checkArgument(image != null);
    // The downstream encoder uses the image timestamp as the presentation timestamp.
    image.setTimestamp(frame.getContentTimeUs() * 1000L);

    if (writeCompleteFence != null) {
      try {
        image.setFence(writeCompleteFence.asSyncFence());
      } catch (IOException e) {
        image.close();
        listenerExecutor.execute(() -> listener.onError(VideoFrameProcessingException.from(e)));
        return;
      } finally {
        // The image holds its own duplicate of the fence file descriptor.
        writeCompleteFence.close();
      }
    }
    checkNotNull(imageWriter).queueInputImage(image);
  }

  @Override
  public void signalEndOfStream() {
    checkState(encoder != null);
    try {
      encoder.signalEndOfInputStream();
      listenerExecutor.execute(listener::onEndOfStream);
    } catch (ExportException e) {
      listenerExecutor.execute(() -> listener.onError(VideoFrameProcessingException.from(e)));
    }
  }

  @Override
  public void close() {
    if (imageWriter != null) {
      imageWriter.close();
      imageWriter = null;
    }
    if (encoder != null) {
      encoder.release();
      encoder = null;
    }
    wakeupExecutor = null;
    wakeupListener = null;
  }

  private synchronized void onImageReleased() {
    inUseCount--;
    if (wakeupExecutor != null && wakeupListener != null) {
      wakeupExecutor.execute(checkNotNull(wakeupListener));
      wakeupExecutor = null;
      wakeupListener = null;
    }
  }

  private static boolean isPixelFormatSupported(Format format) {
    // ImageWriter only supports HardwareBuffer.RGBA_1010102 from API 34.
    return SDK_INT >= 34 || getPixelFormat(format) != HardwareBuffer.RGBA_1010102;
  }

  private static int getPixelFormat(Format format) {
    if (format.pixelFormat != Format.NO_VALUE) {
      return format.pixelFormat;
    }
    return ColorInfo.isTransferHdr(format.colorInfo)
        ? HardwareBuffer.RGBA_1010102
        : HardwareBuffer.RGBA_8888;
  }
}
