/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.transformer;

import static com.google.common.base.Preconditions.checkNotNull;

import android.content.Context;
import android.media.metrics.LogSessionId;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import androidx.annotation.Nullable;
import androidx.media3.common.C.TrackType;
import androidx.media3.common.DebugViewProvider;
import androidx.media3.common.Format;
import androidx.media3.common.VideoFrameProcessor;
import androidx.media3.common.util.Clock;
import androidx.media3.common.util.HandlerWrapper;
import androidx.media3.common.video.FrameProcessor;
import androidx.media3.effect.HardwareBufferJniWrapper;
import androidx.media3.muxer.Muxer;
import androidx.media3.transformer.ExportResult.ProcessedInput;
import androidx.media3.transformer.Transformer.ProgressState;
import com.google.common.collect.ImmutableList;
import java.io.IOException;

/** An {@link ExportOperation} implementation for single export operations. */
/* package */ final class DefaultExportOperation implements ExportOperation {

  private final Context context;
  private final Composition composition;
  private final TransformationRequest transformationRequest;
  @Nullable private final AssetLoader.Factory assetLoaderFactory;
  private final AudioMixer.Factory audioMixerFactory;
  private final VideoFrameProcessor.Factory videoFrameProcessorFactory;
  private final Codec.EncoderFactory encoderFactory;
  private final ImmutableList<Integer> allowedEncodingRotationDegrees;
  private final int maxFramesInEncoder;
  private final ExportOperation.Listener listener;
  private final FallbackListener fallbackListener;
  private final HandlerWrapper applicationHandler;
  private final DebugViewProvider debugViewProvider;
  private final Clock clock;

  @Nullable private final FrameProcessor.Factory frameProcessorFactory;

  @Nullable private final HardwareBufferJniWrapper hardwareBufferJniWrapper;

  @Nullable private final LogSessionId logSessionId;
  private final boolean applyMp4EditListTrim;
  private final Muxer.Factory muxerFactory;
  private final TransformerOutput transformerOutput;
  private final boolean fileStartsOnVideoFrameEnabled;
  private final ExportResult.Builder exportResultBuilder;
  private final ComponentListener componentListener;
  @Nullable private Uri mediaStoreUri;

  @Nullable private TransformerInternal transformerInternal;

  public DefaultExportOperation(
      Context context,
      Composition composition,
      TransformationRequest transformationRequest,
      @Nullable AssetLoader.Factory assetLoaderFactory,
      AudioMixer.Factory audioMixerFactory,
      VideoFrameProcessor.Factory videoFrameProcessorFactory,
      Codec.EncoderFactory encoderFactory,
      ImmutableList<Integer> allowedEncodingRotationDegrees,
      int maxFramesInEncoder,
      ExportOperation.Listener listener,
      FallbackListener fallbackListener,
      HandlerWrapper applicationHandler,
      DebugViewProvider debugViewProvider,
      Clock clock,
      @Nullable FrameProcessor.Factory frameProcessorFactory,
      @Nullable HardwareBufferJniWrapper hardwareBufferJniWrapper,
      @Nullable LogSessionId logSessionId,
      boolean applyMp4EditListTrim,
      Muxer.Factory muxerFactory,
      TransformerOutput transformerOutput,
      boolean fileStartsOnVideoFrameEnabled) {
    this.context = context;
    this.composition = composition;
    this.transformationRequest = transformationRequest;
    this.assetLoaderFactory = assetLoaderFactory;
    this.audioMixerFactory = audioMixerFactory;
    this.videoFrameProcessorFactory = videoFrameProcessorFactory;
    this.encoderFactory = encoderFactory;
    this.allowedEncodingRotationDegrees = allowedEncodingRotationDegrees;
    this.maxFramesInEncoder = maxFramesInEncoder;
    this.listener = listener;
    this.fallbackListener = fallbackListener;
    this.applicationHandler = applicationHandler;
    this.debugViewProvider = debugViewProvider;
    this.clock = clock;
    this.frameProcessorFactory = frameProcessorFactory;
    this.hardwareBufferJniWrapper = hardwareBufferJniWrapper;
    this.logSessionId = logSessionId;
    this.muxerFactory = muxerFactory;
    this.transformerOutput = transformerOutput;
    this.fileStartsOnVideoFrameEnabled = fileStartsOnVideoFrameEnabled;
    this.applyMp4EditListTrim = applyMp4EditListTrim;
    exportResultBuilder = new ExportResult.Builder();
    componentListener = new ComponentListener();
  }

  @Override
  public void start() {
    MuxerWrapper muxerWrapper;
    if (transformerOutput.outputType == TransformerOutput.TYPE_MEDIA_STORE) {
      try {
        muxerWrapper = createMuxerWrapperForMediaStore();
      } catch (IOException | RuntimeException e) {
        // The entry may have been inserted before opening its file descriptor failed.
        deleteMediaStoreEntryIfPresent();
        listener.onError(
            exportResultBuilder.build(),
            ExportException.createForMuxer(e, ExportException.ERROR_CODE_MUXING_FAILED));
        return;
      }
    } else {
      muxerWrapper =
          new MuxerWrapper(
              checkNotNull(transformerOutput.path),
              muxerFactory,
              componentListener,
              MuxerWrapper.MUXER_MODE_DEFAULT,
              /* dropSamplesBeforeFirstVideoSample= */ fileStartsOnVideoFrameEnabled,
              /* appendVideoFormat= */ null);
    }
    transformerInternal =
        new TransformerInternal(
            context,
            composition,
            transformationRequest,
            assetLoaderFactory,
            audioMixerFactory,
            videoFrameProcessorFactory,
            encoderFactory,
            allowedEncodingRotationDegrees,
            maxFramesInEncoder,
            muxerWrapper,
            componentListener,
            fallbackListener,
            applicationHandler,
            debugViewProvider,
            clock,
            frameProcessorFactory,
            hardwareBufferJniWrapper,
            /* videoSampleTimestampOffsetUs= */ 0,
            logSessionId,
            applyMp4EditListTrim,
            /* forceRemuxing= */ false);
    transformerInternal.start();
  }

  @Override
  public @ProgressState int getProgress(ProgressHolder progressHolder) {
    return transformerInternal == null
        ? Transformer.PROGRESS_STATE_NOT_STARTED
        : transformerInternal.getProgress(progressHolder);
  }

  @Override
  public void cancel() {
    if (transformerInternal != null) {
      // Blocks until the export pipeline has ended, releasing the muxer and closing the file
      // descriptor, so that the MediaStore entry can be safely deleted below.
      transformerInternal.cancel();
    }
    deleteMediaStoreEntryIfPresent();
  }

  @Override
  public void endWithException(ExportException exportException) {
    checkNotNull(transformerInternal).endWithException(exportException);
  }

  private MuxerWrapper createMuxerWrapperForMediaStore() throws IOException {
    Uri itemUri =
        TransformerOutputResolver.insertMediaStoreEntry(
            context,
            checkNotNull(transformerOutput.collectionUri),
            checkNotNull(transformerOutput.contentValues));
    this.mediaStoreUri = itemUri;
    ParcelFileDescriptor pfd = TransformerOutputResolver.openFileDescriptor(context, itemUri);
    return new MuxerWrapper(
        pfd,
        muxerFactory,
        componentListener,
        MuxerWrapper.MUXER_MODE_DEFAULT,
        /* dropSamplesBeforeFirstVideoSample= */ fileStartsOnVideoFrameEnabled,
        /* appendVideoFormat= */ null);
  }

  /**
   * Deletes the MediaStore entry created for this export, if any, so that an export that did not
   * complete successfully does not leave an orphaned entry behind.
   */
  private void deleteMediaStoreEntryIfPresent() {
    if (mediaStoreUri != null) {
      TransformerOutputResolver.deleteMediaStoreEntry(context, mediaStoreUri);
      mediaStoreUri = null;
    }
  }

  private final class ComponentListener
      implements TransformerInternal.Listener, MuxerWrapper.Listener {

    // TransformerInternal.Listener implementation

    @Override
    public void onCompleted(
        ImmutableList<ProcessedInput> processedInputs,
        @Nullable String audioEncoderName,
        @Nullable String videoEncoderName) {
      if (mediaStoreUri != null) {
        TransformerOutputResolver.clearMediaStorePendingFlag(context, mediaStoreUri);
        // The entry is published, so it must not be deleted by a subsequent cancel().
        mediaStoreUri = null;
      }
      ExportResultUtil.updateProcessingDetails(
          exportResultBuilder, processedInputs, audioEncoderName, videoEncoderName);
      listener.onCompleted(exportResultBuilder.build());
    }

    @Override
    @SuppressWarnings("UngroupedOverloads") // Grouped by interface.
    public void onError(
        ImmutableList<ProcessedInput> processedInputs,
        @Nullable String audioEncoderName,
        @Nullable String videoEncoderName,
        ExportException exportException) {
      deleteMediaStoreEntryIfPresent();
      ExportResultUtil.updateProcessingDetails(
          exportResultBuilder, processedInputs, audioEncoderName, videoEncoderName);
      listener.onError(
          exportResultBuilder.setExportException(exportException).build(), exportException);
    }

    // MuxerWrapper.Listener implementation

    @Override
    public void onTrackEnded(
        @TrackType int trackType, Format format, int averageBitrate, int sampleCount) {
      ExportResultUtil.updateTrackDetails(
          exportResultBuilder, trackType, format, averageBitrate, sampleCount);
    }

    @Override
    public void onSampleWrittenOrDropped() {
      listener.onSampleWrittenOrDropped();
    }

    @Override
    public void onEnded(long approximateDurationMs) {
      exportResultBuilder.setApproximateDurationMs(approximateDurationMs);
      checkNotNull(transformerInternal).endWithCompletion();
    }

    @Override
    public void onFileSizeBytesAvailable(long fileSizeBytes) {
      exportResultBuilder.setFileSizeBytes(fileSizeBytes);
    }

    @Override
    @SuppressWarnings("UngroupedOverloads") // Grouped by interface.
    public void onError(ExportException exportException) {
      endWithException(exportException);
    }
  }
}
