/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law-or-agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.transformer;

import static android.os.Build.VERSION.SDK_INT;
import static androidx.media3.transformer.CompositionFrameMetadata.asFrameMetadata;
import static androidx.media3.transformer.TransformerUtil.END_OF_STREAM_ASYNC_FRAME;
import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.base.Preconditions.checkState;

import android.graphics.Bitmap;
import android.graphics.ColorSpace;
import android.hardware.DataSpace;
import android.hardware.HardwareBuffer;
import android.os.Handler;
import android.os.Looper;
import android.view.Surface;
import androidx.annotation.GuardedBy;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.media3.common.C;
import androidx.media3.common.ColorInfo;
import androidx.media3.common.Format;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.util.HandlerExecutor;
import androidx.media3.common.util.HandlerWrapper;
import androidx.media3.common.util.Log;
import androidx.media3.common.util.TimestampIterator;
import androidx.media3.common.util.Util;
import androidx.media3.common.video.AsyncFrame;
import androidx.media3.common.video.DefaultHardwareBufferFrame;
import androidx.media3.common.video.Frame;
import androidx.media3.common.video.ReleaseCallback;
import androidx.media3.common.video.SyncFenceWrapper;
import androidx.media3.effect.HardwareBufferJniWrapper;
import androidx.media3.exoplayer.Renderer;
import com.google.common.collect.ImmutableMap;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Queue;
import java.util.concurrent.Executor;
import java.util.function.Consumer;
import org.checkerframework.checker.nullness.qual.MonotonicNonNull;

/** An adaptor between a sequence player and a {@link Consumer} of {@link AsyncFrame} instances. */
/* package */ final class HardwareBufferFrameReader {

  /** A listener for events. */
  public interface Listener {
    /** Reports an error. */
    void onError(Exception cause);
  }

  /** A listener for renderer wakeup events. */
  public interface RendererWakeupListener {
    /**
     * Requests the {@link Renderer} to render some frames.
     *
     * @see Renderer.WakeupListener
     */
    void onWakeup();
  }

  /**
   * The maximum number of frames that can be in use by the downstream components.
   *
   * <p>Starting API 29, android_graphics_cts_MediaVulkanGpuTest verifies that 3 outstanding images
   * can be held by the consumer.
   *
   * <p>Prior to API 28, cts/ImageReaderDecoderTest verified that video decoders support only a
   * single outstanding image with the consumer. A single outstanding image makes double buffering
   * impossible.
   *
   * <p>Using 2 images seems to work on older API levels in our tests, and allows double buffering.
   */
  /* package */ static final int CAPACITY = SDK_INT >= 29 ? 3 : 2;

  private static final int DEFAULT_FRAME_RATE = 30;
  private static final String TAG = "HBFrameReader";
  private static final long RELEASE_TIMEOUT_MS = 2000;

  private final Composition composition;
  private final int sequenceIndex;
  private final Consumer<AsyncFrame> frameConsumer;
  private final ImageReaderAdapter imageReader;
  private final Listener listener;
  private final Executor playbackExecutor;

  // TODO: b/478781219 - Ensure this class is only accessed from a single thread.
  /**
   * Information about frames that are waiting to be output.
   *
   * <p>At most one frame from {@link #queueFrameViaSurface} can be pending at a time.
   *
   * <p>Multiple frames from {@link #outputBitmap} can be pending.
   */
  @GuardedBy("this")
  private final Queue<FrameInfo> pendingFrameInfo;

  private final List<RendererWakeupListener> rendererWakeupListenerList;

  private @MonotonicNonNull Surface imageReaderSurface;

  @Nullable private Format lastFormat;
  private @MonotonicNonNull Format lastAdjustedFormat;

  private final HardwareBufferJniWrapper hardwareBufferJniWrapper;
  @Nullable private BitmapToHardwareBufferConverter bitmapToHardwareBufferConverter;

  // TODO: b/478781219 - Ensure this class is only accessed from a single thread.
  /** The number of frames that are currently in use by the downstream consumer. */
  @GuardedBy("this")
  private int framesInUse;

  /**
   * Creates an instance.
   *
   * @param composition The {@link Composition} for which this reader produces frames.
   * @param sequenceIndex The index of the {@link EditedMediaItemSequence} in the composition.
   * @param frameConsumer The downstream consumer of frames.
   * @param playbackLooper The looper associated with the playback thread.
   * @param defaultSurfacePixelFormat The default pixel format used by the {@linkplain #getSurface()
   *     surface}. Some producers override this format, but the behavior is device-specific.
   * @param imageReaderAdapterFactory The {@link ImageReaderAdapter.Factory} used to create the
   *     internal {@link ImageReaderAdapter}.
   * @param listener The listener.
   * @param listenerHandler A {@link HandlerWrapper} to dispatch {@link Listener} callbacks.
   * @param hardwareBufferJniWrapper A {@link HardwareBufferJniWrapper} used to convert software
   *     bitmaps to hardware buffers.
   */
  /* package */ HardwareBufferFrameReader(
      Composition composition,
      int sequenceIndex,
      Consumer<AsyncFrame> frameConsumer,
      Looper playbackLooper,
      int defaultSurfacePixelFormat,
      ImageReaderAdapter.Factory imageReaderAdapterFactory,
      Listener listener,
      HandlerWrapper listenerHandler,
      HardwareBufferJniWrapper hardwareBufferJniWrapper) {
    this.composition = composition;
    this.sequenceIndex = sequenceIndex;
    this.frameConsumer = frameConsumer;
    this.listener = listener;
    this.hardwareBufferJniWrapper = hardwareBufferJniWrapper;
    // The width and height are sensible defaults for tests and are typically ignored when writing
    // from MediaCodec.
    this.imageReader =
        imageReaderAdapterFactory.create(
            /* width= */ 640,
            /* height= */ 360,
            defaultSurfacePixelFormat,
            /* maxImages= */ CAPACITY,
            /* usage= */ SDK_INT >= 29 ? HardwareBuffer.USAGE_GPU_SAMPLED_IMAGE : 0);
    Handler playbackHandler = new Handler(playbackLooper);
    playbackExecutor =
        new HandlerExecutor(playbackHandler, e -> listenerHandler.post(() -> listener.onError(e)));
    rendererWakeupListenerList = new ArrayList<>();
    pendingFrameInfo = new ArrayDeque<>();
    imageReader.setOnImageAvailableListener(
        reader -> {
          try {
            pollImage();
          } catch (RuntimeException e) {
            listenerHandler.post(() -> listener.onError(e));
          }
        },
        playbackHandler);
  }

  /** Returns a Surface which can be used to produce frames into. */
  Surface getSurface() {
    if (imageReaderSurface == null) {
      imageReaderSurface = imageReader.getSurface();
    }
    return imageReaderSurface;
  }

  /**
   * Returns whether the frame reader can accept another frame from the sequence player via the
   * {@linkplain #getSurface() input surface}.
   */
  boolean canAcceptFrameViaSurface() {
    // Prior to API 29 MediaCodec drops frames when outputting to a Surface. Do not allow multiple
    // frames to be pending over the ImageReader Surface simultaneously. See
    // https://developer.android.com/reference/android/media/MediaCodec#using-an-output-surface
    // Even after API 29, some devices still drop frames on the Surface. See
    // https://github.com/androidx/media/blob/7cc1056f840ce226598d3b990d4a6f7cd17e2831/libraries/common/src/main/java/androidx/media3/common/util/Util.java#L3651
    synchronized (this) {
      if (!pendingFrameInfo.isEmpty()) {
        return false;
      }
      return framesInUse < CAPACITY;
    }
  }

  /**
   * Signals that a frame will be sent via the {@linkplain #getSurface() input surface}.
   *
   * <p>This method must be called prior to {@linkplain android.media.MediaCodec#releaseOutputBuffer
   * releasing} the frame to the {@linkplain #getSurface() input surface}.
   *
   * @param presentationTimeUs The presentation time of the frame relative to the start of the media
   *     item it belongs to, in microseconds.
   * @param sequenceOffsetUs The offset to add to {@code presentationTimeUs} to compute the
   *     sequence-relative presentation time, in microseconds. This is typically the cumulative
   *     duration of all preceding media items in the sequence.
   * @param indexOfItem The position of the edited media item in the sequence.
   * @param format The {@link Format} of the edited media item.
   */
  void queueFrameViaSurface(
      long presentationTimeUs, long sequenceOffsetUs, int indexOfItem, Format format) {
    synchronized (this) {
      pendingFrameInfo.add(
          FrameInfo.createForSurface(
              presentationTimeUs, sequenceOffsetUs, indexOfItem, getAdjustedFormat(format)));
    }
    imageReader.notifyFrameQueued(presentationTimeUs);
  }

  /**
   * Repeats a {@link Bitmap} to the downstream consumer, using timestamps from the {@code
   * timestampIterator}.
   *
   * @param bitmap The {@link Bitmap} to be repeated.
   * @param timestampIterator The {@link TimestampIterator} that provides the presentation
   *     timestamps of the frames to output.
   * @param sequenceOffsetUs The offset to add to the timestamps generated by the {@link
   *     TimestampIterator} to compute the sequence-relative presentation time, in microseconds.
   *     This is typically the cumulative duration of all preceding media items in the sequence.
   * @param indexOfItem The position of the edited media item in the sequence.
   */
  // TODO: b/319484746 - Move Bitmap repeating into the Renderer when ImageRenderer takes positionUs
  // into account.
  void outputBitmap(
      Bitmap bitmap, TimestampIterator timestampIterator, long sequenceOffsetUs, int indexOfItem) {
    String sampleMimeType =
        SDK_INT >= 34 && Api34.hasGainmap(bitmap) ? MimeTypes.IMAGE_JPEG_R : MimeTypes.IMAGE_RAW;
    Format format =
        new Format.Builder()
            .setSampleMimeType(sampleMimeType)
            .setWidth(bitmap.getWidth())
            .setHeight(bitmap.getHeight())
            .setColorInfo(resolveColorInfoFromBitmap(bitmap))
            .setFrameRate(/* frameRate= */ DEFAULT_FRAME_RATE)
            .build();
    synchronized (this) {
      pendingFrameInfo.add(
          FrameInfo.createForBitmap(
              bitmap, timestampIterator, sequenceOffsetUs, indexOfItem, format));
    }
    maybeOutputPendingBitmaps();
  }

  /**
   * Tries to read a frame from the {@linkplain #getSurface() input surface}. Forwards the frame
   * downstream, if a new frame was available.
   */
  void pollImage() {
    synchronized (this) {
      if (framesInUse >= CAPACITY) {
        return;
      }
      ImageAdapter image = imageReader.acquireNextImage();
      if (image == null) {
        return;
      }
      try {
        // Increment the framesInUse count before dequeueing pendingFrameInfo, to ensure only up to
        // CAPACITY images are queued.
        framesInUse++;
        @Nullable FrameInfo frameInfo = pendingFrameInfo.poll();
        // If the HardwareBufferFrameReader is flushed after queueFrameViaSurface is called, but
        // before onImageAvailable, then when onImageAvailable is called there will be no matching
        // pendingFrameInfo. Ignore Images with no matching pendingFrameInfo to avoid crashing in
        // this scenario.
        if (frameInfo == null) {
          image.close();
          framesInUse--;
          return;
        }
        long itemPresentationTimeUs = frameInfo.itemPresentationTimeUs;
        long sequenceOffsetUs = frameInfo.sequenceOffsetUs;
        int indexOfItem = frameInfo.itemIndex;
        checkState(
            image.getTimestampNs() == itemPresentationTimeUs * 1000,
            "%s != %s",
            image.getTimestampNs(),
            itemPresentationTimeUs * 1000);

        frameConsumer.accept(
            createAsyncFrameFromImage(
                image, itemPresentationTimeUs, sequenceOffsetUs, indexOfItem, frameInfo.format));
        maybeOutputPendingBitmaps();
        maybeWakeupVideoRenderer();
      } catch (RuntimeException e) {
        image.close();
        framesInUse--;
        throw e;
      }
    }
  }

  /**
   * Forwards a {@link TransformerUtil#END_OF_STREAM_ASYNC_FRAME} to the downstream consumer after
   * all pending frames have been forwarded.
   */
  void queueEndOfStream() {
    synchronized (this) {
      pendingFrameInfo.add(FrameInfo.END_OF_STREAM);
      maybeOutputPendingBitmaps();
    }
  }

  /**
   * Registers a listener to receive wakeup events from the frame reader.
   *
   * @param rendererWakeupListener The listener to register.
   */
  void addRendererWakeupListener(RendererWakeupListener rendererWakeupListener) {
    rendererWakeupListenerList.add(rendererWakeupListener);
  }

  /**
   * Unregisters a listener registered through {@link
   * #addRendererWakeupListener(RendererWakeupListener)}. The listener will no longer receive
   * events.
   *
   * @param rendererWakeupListener The listener to unregister.
   */
  void removeRendererWakeupListener(RendererWakeupListener rendererWakeupListener) {
    rendererWakeupListenerList.remove(rendererWakeupListener);
  }

  /** Clears all pending frames. */
  void flush() {
    synchronized (this) {
      pendingFrameInfo.clear();
      if (SDK_INT >= 26 && bitmapToHardwareBufferConverter != null) {
        bitmapToHardwareBufferConverter.flush();
      }
    }
  }

  /** Releases any resources. */
  void release() {
    if (imageReaderSurface != null) {
      imageReaderSurface.release();
    }
    imageReader.close();
    if (SDK_INT >= 26 && bitmapToHardwareBufferConverter != null) {
      bitmapToHardwareBufferConverter.close();
      bitmapToHardwareBufferConverter = null;
    }
  }

  /** Sets a default {@link ColorInfo} on the given {@link Format}. */
  private Format getAdjustedFormat(Format format) {
    if (format.equals(lastFormat)) {
      return checkNotNull(lastAdjustedFormat);
    }
    lastFormat = format;
    lastAdjustedFormat =
        format
            .buildUpon()
            .setColorInfo(
                format.colorInfo == null || !format.colorInfo.isDataSpaceValid()
                    ? ColorInfo.SDR_BT709_LIMITED
                    : format.colorInfo)
            .build();
    return lastAdjustedFormat;
  }

  private void maybeOutputPendingBitmaps() {
    synchronized (this) {
      @Nullable FrameInfo frameInfo = pendingFrameInfo.peek();
      while (framesInUse < CAPACITY && frameInfo != null && frameInfo.timestampIterator != null) {
        if (!frameInfo.timestampIterator.hasNext()) {
          pendingFrameInfo.remove();
          frameInfo = pendingFrameInfo.peek();
          continue;
        }

        long itemPresentationTimeUs = frameInfo.timestampIterator.next();
        long sequenceOffsetUs = frameInfo.sequenceOffsetUs;
        framesInUse++;
        AsyncFrame asyncFrame =
            createAsyncFrameFromBitmap(
                checkNotNull(frameInfo.bitmap),
                itemPresentationTimeUs,
                sequenceOffsetUs,
                frameInfo.itemIndex,
                frameInfo.format);
        frameConsumer.accept(asyncFrame);
      }
    }
    maybeOutputEndOfStream();
  }

  private void maybeOutputEndOfStream() {
    synchronized (this) {
      @Nullable FrameInfo frameInfo = pendingFrameInfo.peek();
      while (frameInfo == FrameInfo.END_OF_STREAM) {
        frameConsumer.accept(END_OF_STREAM_ASYNC_FRAME);
        pendingFrameInfo.remove();
        frameInfo = pendingFrameInfo.peek();
      }
    }
  }

  @SuppressWarnings("NewApi")
  private AsyncFrame createAsyncFrameFromImage(
      ImageAdapter image,
      long presentationTimeUs,
      long sequenceOffsetUs,
      int indexOfItem,
      Format format) {
    // TODO: b/449956936 - Add support for HardwareBuffer on API 26 using Media NDK methods such as
    // AImage_getHardwareBuffer.
    // TODO(b/531653682): Support frame types not backed by HardwareBuffer.
    HardwareBuffer hardwareBuffer = checkNotNull(image.getHardwareBuffer());
    checkState(!hardwareBuffer.isClosed());
    return createAsyncFrame(
        hardwareBuffer,
        image.getInternalImage(),
        playbackExecutor,
        /* releaseCallback= */ (releaseFence) -> releaseFrame(image, hardwareBuffer, releaseFence),
        presentationTimeUs,
        sequenceOffsetUs,
        indexOfItem,
        format);
  }

  @Nullable
  private BitmapToHardwareBufferConverter getOrCreateBitmapToHardwareBufferConverter() {
    if (SDK_INT >= 26 && bitmapToHardwareBufferConverter == null) {
      bitmapToHardwareBufferConverter =
          new BitmapToHardwareBufferConverter(
              hardwareBufferJniWrapper,
              /* internalExecutor= */ Util.newSingleThreadExecutor(
                  "BitmapToHardwareBufferConverter::Thread"),
              /* errorExecutor= */ playbackExecutor,
              /* errorCallback= */ listener::onError);
    }
    return bitmapToHardwareBufferConverter;
  }

  private AsyncFrame createAsyncFrameFromBitmap(
      Bitmap bitmap, long presentationTimeUs, long sequenceOffsetUs, int itemIndex, Format format) {
    // TODO: b/449956936 - Copy the Bitmap into a HardwareBuffer using NDK on earlier API levels.
    if (SDK_INT >= 31 && checkNotNull(bitmap).getConfig() == Bitmap.Config.HARDWARE) {
      HardwareBuffer hardwareBuffer = checkNotNull(bitmap.getHardwareBuffer());
      checkState(!hardwareBuffer.isClosed());
      return createAsyncFrame(
          hardwareBuffer,
          bitmap,
          playbackExecutor,
          /* releaseCallback= */ (releaseFence) -> {
            // Do not manually release the hardware buffer backing the bitmap, it will be reused
            // when the bitmap is repeated, and cleaned up when the bitmap is garbage collected.
            releaseFrame(/* image= */ null, /* hardwareBuffer= */ null, releaseFence);
          },
          presentationTimeUs,
          sequenceOffsetUs,
          itemIndex,
          format);
    }
    // TODO(b/531653682): Support frame types not backed by HardwareBuffer.
    DefaultHardwareBufferFrame retainedHandle =
        checkNotNull(getOrCreateBitmapToHardwareBufferConverter()).getOrCreateRetainedFrame(bitmap);
    return createAsyncFrame(
        checkNotNull(retainedHandle.getHardwareBuffer()),
        bitmap,
        playbackExecutor,
        /* releaseCallback= */ (releaseFence) -> {
          retainedHandle.release(releaseFence);
          releaseFrame(/* image= */ null, /* hardwareBuffer= */ null, /* releaseFence= */ null);
        },
        presentationTimeUs,
        sequenceOffsetUs,
        itemIndex,
        format);
  }

  @SuppressWarnings({"deprecation", "NewApi"}) // Uses deprecated CompositionFrameMetadata.
  private AsyncFrame createAsyncFrame(
      HardwareBuffer hardwareBuffer,
      @Nullable Object internalImage,
      Executor releaseExecutor,
      ReleaseCallback releaseCallback,
      long presentationTimeUs,
      long sequenceOffsetUs,
      int itemIndex,
      Format format) {
    // COLOR_TRANSFER_SRGB may not be supported by the encoder or display, but is equivalent to
    // COLOR_TRANSFER_SDR on Android which is widely supported.
    if (format.colorInfo != null
        && format.colorInfo.colorTransfer == C.COLOR_TRANSFER_SRGB
        && !Objects.equals(format.sampleMimeType, MimeTypes.IMAGE_JPEG_R)) {
      ColorInfo adjustedColorInfo =
          format.colorInfo.buildUpon().setColorTransfer(C.COLOR_TRANSFER_SDR).build();
      format = format.buildUpon().setColorInfo(adjustedColorInfo).build();
    }
    long sequencePresentationTimeUs = presentationTimeUs + sequenceOffsetUs;
    CompositionFrameMetadata compositionFrameMetadata =
        new CompositionFrameMetadata(composition, sequenceIndex, itemIndex);
    ImmutableMap<String, Object> metadata =
        ImmutableMap.<String, Object>builder()
            .put(Frame.KEY_PRESENTATION_TIME_US, presentationTimeUs)
            .put(CompositionFrameMetadata.KEY_COMPOSITION_FRAME_METADATA, compositionFrameMetadata)
            .putAll(asFrameMetadata(compositionFrameMetadata))
            .buildOrThrow();
    DefaultHardwareBufferFrame frame =
        new DefaultHardwareBufferFrame.Builder(hardwareBuffer, releaseExecutor, releaseCallback)
            .setContentTimeUs(sequencePresentationTimeUs)
            .setMetadata(metadata)
            .setFormat(format)
            .setInternalImage(internalImage)
            .build();
    return new AsyncFrame(frame, /* acquireFence= */ null);
  }

  private void releaseFrame(
      @Nullable ImageAdapter image,
      @Nullable HardwareBuffer hardwareBuffer,
      @Nullable SyncFenceWrapper releaseFence) {
    if (releaseFence != null) {
      // TODO: b/475744934 - Use the NDK to set the fence on the Image.
      if (!releaseFence.awaitMs(RELEASE_TIMEOUT_MS)) {
        Log.w(TAG, "Timed out waiting for release fence to signal.");
      }
      releaseFence.close();
    }
    synchronized (this) {
      framesInUse--;
      if (SDK_INT >= 26 && hardwareBuffer != null) {
        hardwareBuffer.close();
      }
      if (image != null) {
        image.close();
      }
    }
    maybeOutputPendingBitmaps();
    maybeWakeupVideoRenderer();
  }

  private void maybeWakeupVideoRenderer() {
    for (int i = 0; i < rendererWakeupListenerList.size(); i++) {
      rendererWakeupListenerList.get(i).onWakeup();
    }
  }

  private static ColorInfo resolveColorInfoFromBitmap(Bitmap bitmap) {
    if (SDK_INT >= 33) {
      return Api33.resolveColorInfoFromBitmap(bitmap);
    }
    return ColorInfo.SRGB_BT709_FULL;
  }

  private static final class FrameInfo {

    /** A {@link FrameInfo} marking that the sequence has ended. */
    private static final FrameInfo END_OF_STREAM =
        new FrameInfo(
            null,
            null,
            /* itemPresentationTimeUs= */ C.TIME_END_OF_SOURCE,
            /* sequenceOffsetUs= */ 0,
            /* itemIndex= */ C.INDEX_UNSET,
            /* format= */ new Format.Builder().build());

    /**
     * The pending frame {@link Bitmap}, or {@code null} if the frame will be output via {@link
     * #getSurface()}.
     */
    @Nullable final Bitmap bitmap;

    /**
     * The pending frame timestamps, or {@code null} if the frame will be output via {@link
     * #getSurface()}.
     */
    @Nullable final TimestampIterator timestampIterator;

    final Format format;
    final long itemPresentationTimeUs;
    final long sequenceOffsetUs;
    final int itemIndex;

    static FrameInfo createForBitmap(
        Bitmap bitmap,
        TimestampIterator timestampIterator,
        long sequenceOffsetUs,
        int itemIndex,
        Format format) {
      return new FrameInfo(
          bitmap, timestampIterator, C.TIME_UNSET, sequenceOffsetUs, itemIndex, format);
    }

    static FrameInfo createForSurface(
        long itemPresentationTimeUs, long sequenceOffsetUs, int itemIndex, Format format) {
      return new FrameInfo(null, null, itemPresentationTimeUs, sequenceOffsetUs, itemIndex, format);
    }

    private FrameInfo(
        @Nullable Bitmap bitmap,
        @Nullable TimestampIterator timestampIterator,
        long itemPresentationTimeUs,
        long sequenceOffsetUs,
        int itemIndex,
        Format format) {
      this.bitmap = bitmap;
      this.timestampIterator = timestampIterator;
      this.itemPresentationTimeUs = itemPresentationTimeUs;
      this.sequenceOffsetUs = sequenceOffsetUs;
      this.itemIndex = itemIndex;
      this.format = format;
    }
  }

  @RequiresApi(33)
  private static final class Api33 {
    private static final ColorInfo BT2020_HLG_FULL =
        new ColorInfo.Builder()
            .setColorSpace(C.COLOR_SPACE_BT2020)
            .setColorRange(C.COLOR_RANGE_FULL)
            .setColorTransfer(C.COLOR_TRANSFER_HLG)
            .build();

    private static final ColorInfo BT2020_PQ_FULL =
        new ColorInfo.Builder()
            .setColorSpace(C.COLOR_SPACE_BT2020)
            .setColorRange(C.COLOR_RANGE_FULL)
            .setColorTransfer(C.COLOR_TRANSFER_ST2084)
            .build();

    private static ColorInfo resolveColorInfoFromBitmap(Bitmap bitmap) {
      ColorSpace colorSpace = bitmap.getColorSpace();
      if (colorSpace != null) {
        return dataSpaceToColorInfo(colorSpace.getDataSpace());
      }
      return ColorInfo.SRGB_BT709_FULL;
    }

    private static ColorInfo dataSpaceToColorInfo(int dataSpace) {
      switch (dataSpace) {
        case DataSpace.STANDARD_BT2020 | DataSpace.TRANSFER_HLG | DataSpace.RANGE_FULL:
          return BT2020_HLG_FULL;
        case DataSpace.STANDARD_BT2020 | DataSpace.TRANSFER_ST2084 | DataSpace.RANGE_FULL:
          return BT2020_PQ_FULL;
        default:
          return ColorInfo.SRGB_BT709_FULL;
      }
    }
  }

  @RequiresApi(34)
  private static final class Api34 {
    private static boolean hasGainmap(Bitmap bitmap) {
      return bitmap.hasGainmap();
    }
  }
}
