/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.transformer;

import static androidx.media3.transformer.TransformerUtil.END_OF_STREAM_ASYNC_FRAME;
import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.base.Preconditions.checkState;

import android.graphics.Bitmap;
import android.graphics.ImageFormat;
import android.os.Looper;
import android.view.Surface;
import androidx.annotation.Nullable;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.util.HandlerWrapper;
import androidx.media3.common.util.TimestampIterator;
import androidx.media3.common.video.AsyncFrame;
import androidx.media3.common.video.DefaultHardwareBufferFrame;
import androidx.media3.common.video.Frame;
import androidx.media3.effect.HardwareBufferJniWrapper;
import androidx.media3.transformer.HardwareBufferFrameReader.Listener;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

/**
 * A {@link GraphInput} that wraps {@link HardwareBufferFrameReader}.
 *
 * <p>Offsets {@link Frame#KEY_DISPLAY_TIME_NS} based on preceding media item durations to ensure a
 * continuous timeline within the sequence.
 */
/* package */ final class HardwareBufferSampleConsumer implements GraphInput {

  private final HardwareBufferFrameReader hardwareBufferFrameReader;
  private final Composition composition;
  private final int sequenceIndex;

  @Nullable private Format currentFormat;
  // Start at -1 so the initial onMediaItemChanged increments the current index to 0.
  private int currentMediaItemIndex = C.INDEX_UNSET;
  private long currentTimeOffsetUs;
  private long nextTimeOffsetUs;

  /**
   * Creates a new instance.
   *
   * @param composition The {@link Composition} containing the sequences being exported.
   * @param sequenceIndex The index of the sequence this consumer belongs to.
   * @param playbackLooper The {@link Looper} for playback operations.
   * @param listenerHandler The {@link HandlerWrapper} for scheduling to dispatch {@link Listener}
   *     callbacks.
   * @param frameConsumer The {@link Consumer<AsyncFrame>} to which processed frames are output.
   * @param errorConsumer A consumer to accept {@link ExportException}s if errors occur.
   * @param hardwareBufferJniWrapper The {@link HardwareBufferJniWrapper} used to convert software
   *     bitmaps to hardware buffers.
   */
  public HardwareBufferSampleConsumer(
      Composition composition,
      int sequenceIndex,
      Looper playbackLooper,
      HandlerWrapper listenerHandler,
      Consumer<AsyncFrame> frameConsumer,
      Consumer<ExportException> errorConsumer,
      HardwareBufferJniWrapper hardwareBufferJniWrapper) {
    this.composition = composition;
    this.sequenceIndex = sequenceIndex;
    // Modify the release times of frames exiting the hardwareBufferFrameReader to account for
    // item duration.
    Consumer<AsyncFrame> intermediateConsumer =
        (asyncFrame) -> {
          if (asyncFrame != END_OF_STREAM_ASYNC_FRAME) {
            // The frame's sequencePresentationTimeUs is already adjusted by the
            // HardwareBufferFrameReader to be monotonic across the entire sequence.
            // Adjust the release times so they are valid for the encoder.
            long releaseTimeNs = asyncFrame.frame.getContentTimeUs() * 1000;
            Map<String, Object> updatedMetadata = new HashMap<>(asyncFrame.frame.getMetadata());
            updatedMetadata.put(Frame.KEY_DISPLAY_TIME_NS, releaseTimeNs);
            Frame frame =
                ((DefaultHardwareBufferFrame) asyncFrame.frame)
                    .buildUpon()
                    .setMetadata(updatedMetadata)
                    .build();
            asyncFrame = new AsyncFrame(frame, asyncFrame.acquireFence);
          }
          frameConsumer.accept(asyncFrame);
        };
    this.hardwareBufferFrameReader =
        new HardwareBufferFrameReader(
            checkNotNull(composition),
            sequenceIndex,
            intermediateConsumer,
            playbackLooper,
            /* defaultSurfacePixelFormat= */ ImageFormat.PRIVATE,
            new DefaultImageReaderAdapter.Factory(),
            e -> errorConsumer.accept(ExportException.createForUnexpected(e)),
            listenerHandler,
            hardwareBufferJniWrapper);
  }

  @Override
  public void onMediaItemChanged(
      EditedMediaItem editedMediaItem,
      long durationUs,
      @Nullable Format decodedFormat,
      boolean isLast,
      long positionOffsetUs) {
    this.currentFormat = decodedFormat;
    // The editedMediaItems passed to this method are different instances to those in the
    // composition, so they cannot be directly compared. Assume that media items are processed in
    // order, so every onMediaItemChanged call increments the media item index.
    EditedMediaItemSequence sequence = composition.sequences.get(sequenceIndex);
    currentMediaItemIndex =
        EditedMediaItemSequence.getEditedMediaItemIndex(sequence, currentMediaItemIndex + 1);
    currentTimeOffsetUs += nextTimeOffsetUs;
    nextTimeOffsetUs = durationUs;
  }

  @Override
  public @InputResult int queueInputBitmap(
      Bitmap inputBitmap, TimestampIterator timestampIterator) {
    hardwareBufferFrameReader.outputBitmap(
        inputBitmap, timestampIterator, currentTimeOffsetUs, currentMediaItemIndex);
    return INPUT_RESULT_SUCCESS;
  }

  @Override
  public Surface getInputSurface() {
    return hardwareBufferFrameReader.getSurface();
  }

  @Override
  public boolean registerVideoFrame(long presentationTimeUs) {
    if (!hardwareBufferFrameReader.canAcceptFrameViaSurface()) {
      return false;
    }
    checkState(currentFormat != null);
    hardwareBufferFrameReader.queueFrameViaSurface(
        presentationTimeUs, currentTimeOffsetUs, currentMediaItemIndex, currentFormat);
    return true;
  }

  @Override
  public void signalEndOfVideoInput() {
    EditedMediaItemSequence sequence = composition.sequences.get(sequenceIndex);
    if (sequence.isLooping || currentMediaItemIndex == sequence.editedMediaItems.size() - 1) {
      hardwareBufferFrameReader.queueEndOfStream();
    }
  }

  @Override
  public int getPendingVideoFrameCount() {
    // registerVideoFrame is always called before a sample is queued, that is the source of truth
    // for whether the underlying HardwareBufferFrameReader can accept a frame, so it is fine to
    // always return 0 here.
    return 0;
  }

  /** Releases resources associated the underlying {@link HardwareBufferFrameReader}. */
  public void release() {
    hardwareBufferFrameReader.release();
  }
}
