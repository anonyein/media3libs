/*
 * Copyright 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.media3.transformer;

import static androidx.media3.common.ColorInfo.SDR_BT709_LIMITED;
import static androidx.media3.common.ColorInfo.isTransferHdr;
import static androidx.media3.exoplayer.mediacodec.MediaCodecUtil.getAlternativeCodecMimeType;
import static androidx.media3.transformer.Composition.HDR_MODE_KEEP_HDR;
import static androidx.media3.transformer.Composition.HDR_MODE_TONE_MAP_HDR_TO_SDR_USING_OPEN_GL;
import static androidx.media3.transformer.EncoderUtil.getSupportedEncodersForHdrEditing;
import static com.google.common.base.Preconditions.checkState;
import static java.lang.Math.round;

import android.content.ContentResolver;
import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.metrics.LogSessionId;
import android.util.Pair;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.media3.common.C;
import androidx.media3.common.ColorInfo;
import androidx.media3.common.Effect;
import androidx.media3.common.Format;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Metadata;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.Timeline;
import androidx.media3.common.audio.AudioProcessor;
import androidx.media3.common.audio.SpeedChangingAudioProcessor;
import androidx.media3.common.audio.SpeedProvider;
import androidx.media3.common.util.CodecSpecificDataUtil;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.common.video.AsyncFrame;
import androidx.media3.common.video.Frame;
import androidx.media3.common.video.ReferenceCounter;
import androidx.media3.common.video.SyncFenceWrapper;
import androidx.media3.effect.GlEffect;
import androidx.media3.effect.ScaleAndRotateTransformation;
import androidx.media3.effect.SpeedChangeEffect;
import androidx.media3.effect.TimestampAdjustment;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.exoplayer.source.MediaSource.MediaPeriodId;
import androidx.media3.extractor.metadata.mp4.SlowMotionData;
import androidx.media3.transformer.Composition.HdrMode;
import com.google.common.base.Ascii;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import java.util.List;
import java.util.Objects;

/** Utility methods for Transformer. */
@UnstableApi
public final class TransformerUtil {

  /** An empty {@link AsyncFrame} representing the end of a stream. */
  /* package */ static final AsyncFrame END_OF_STREAM_ASYNC_FRAME =
      new AsyncFrame(
          new Frame() {
            private final Format format = new Format.Builder().build();

            @Override
            public Format getFormat() {
              return format;
            }

            @Override
            public ImmutableMap<String, Object> getMetadata() {
              return ImmutableMap.of();
            }

            @Override
            public long getContentTimeUs() {
              return C.TIME_END_OF_SOURCE;
            }
          },
          /* acquireFence= */ null);

  private TransformerUtil() {}

  /**
   * Returns the {@link C.TrackType track type} constant corresponding to how a specified MIME type
   * should be processed, which may be {@link C#TRACK_TYPE_UNKNOWN} if it could not be determined.
   *
   * <p>{@linkplain MimeTypes#isImage Image} MIME types are processed as {@link C#TRACK_TYPE_VIDEO}.
   *
   * <p>See {@link MimeTypes#getTrackType} for more details.
   */
  public static @C.TrackType int getProcessedTrackType(@Nullable String mimeType) {
    @C.TrackType int trackType = MimeTypes.getTrackType(mimeType);
    return trackType == C.TRACK_TYPE_IMAGE ? C.TRACK_TYPE_VIDEO : trackType;
  }

  /** Returns {@link MediaCodec} flags corresponding to {@link C.BufferFlags}. */
  public static int getMediaCodecFlags(@C.BufferFlags int flags) {
    int mediaCodecFlags = 0;
    if ((flags & C.BUFFER_FLAG_KEY_FRAME) == C.BUFFER_FLAG_KEY_FRAME) {
      mediaCodecFlags |= MediaCodec.BUFFER_FLAG_KEY_FRAME;
    }
    if ((flags & C.BUFFER_FLAG_END_OF_STREAM) == C.BUFFER_FLAG_END_OF_STREAM) {
      mediaCodecFlags |= MediaCodec.BUFFER_FLAG_END_OF_STREAM;
    }
    return mediaCodecFlags;
  }

  /** Returns whether the audio track should be transcoded. */
  /* package */ static boolean shouldTranscodeAudio(
      Format inputFormat,
      Composition composition,
      int sequenceIndex,
      TransformationRequest transformationRequest,
      Codec.EncoderFactory encoderFactory,
      MuxerWrapper muxerWrapper) {
    if (composition.sequences.size() > 1
        || composition.sequences.get(sequenceIndex).editedMediaItems.size() > 1) {
      return !composition.transmuxAudio;
    }
    if (composition.hasGaps()) {
      return true;
    }
    if (encoderFactory.audioNeedsEncoding()) {
      return true;
    }
    if (transformationRequest.audioMimeType != null
        && !transformationRequest.audioMimeType.equals(inputFormat.sampleMimeType)) {
      return true;
    }
    if (transformationRequest.audioMimeType == null
        && !muxerWrapper.supportsSampleMimeType(inputFormat.sampleMimeType)) {
      return true;
    }
    EditedMediaItem firstEditedMediaItem =
        composition.sequences.get(sequenceIndex).editedMediaItems.get(0);
    if (firstEditedMediaItem.flattenForSlowMotion && containsSlowMotionData(inputFormat)) {
      return true;
    }
    if (firstEditedMediaItem.speedProvider != SpeedProvider.DEFAULT) {
      return true;
    }
    if (!firstEditedMediaItem.effects.audioProcessors.isEmpty()) {
      return true;
    }
    if (!composition.effects.audioProcessors.isEmpty()) {
      return true;
    }
    return false;
  }

  /**
   * Returns whether the {@link Format} contains {@linkplain SlowMotionData slow motion metadata}.
   */
  private static boolean containsSlowMotionData(Format format) {
    @Nullable Metadata metadata = format.metadata;
    return metadata != null && metadata.getFirstEntryOfType(SlowMotionData.class) != null;
  }

  /** Returns whether the video track should be transcoded. */
  /* package */ static boolean shouldTranscodeVideo(
      Format inputFormat,
      Composition composition,
      int sequenceIndex,
      TransformationRequest transformationRequest,
      Codec.EncoderFactory encoderFactory,
      MuxerWrapper muxerWrapper,
      boolean hasFrameProcessorFactory) {
    if (composition.sequences.size() > 1
        || composition.sequences.get(sequenceIndex).editedMediaItems.size() > 1) {
      return !composition.transmuxVideo;
    }
    if (encoderFactory.videoNeedsEncoding()) {
      return true;
    }
    if (transformationRequest.hdrMode != HDR_MODE_KEEP_HDR) {
      return true;
    }
    @Nullable String requestedMimeType = transformationRequest.videoMimeType;
    if (requestedMimeType != null) {
      boolean requestedMimeTypeEqualsPrimaryOrAlternativeMimeType =
          requestedMimeType.equals(inputFormat.sampleMimeType)
              || requestedMimeType.equals(getAlternativeCodecMimeType(inputFormat));
      if (!requestedMimeTypeEqualsPrimaryOrAlternativeMimeType) {
        return true;
      }
    }
    if (Objects.equals(inputFormat.sampleMimeType, MimeTypes.VIDEO_DOLBY_VISION)
        && CodecSpecificDataUtil.getCodecProfileAndLevel(inputFormat) == null) {
      return true;
    }
    if (requestedMimeType == null
        && !muxerWrapper.supportsSampleMimeType(inputFormat.sampleMimeType)
        && !muxerWrapper.supportsSampleMimeType(getAlternativeCodecMimeType(inputFormat))) {
      return true;
    }
    if (inputFormat.pixelWidthHeightRatio != 1f) {
      return true;
    }
    if (hasFrameProcessorFactory) {
      // A PacketProcessor processes video frames, which requires decoding and re-encoding.
      return true;
    }
    EditedMediaItem firstEditedMediaItem =
        composition.sequences.get(sequenceIndex).editedMediaItems.get(0);
    ImmutableList<Effect> combinedEffects =
        new ImmutableList.Builder<Effect>()
            .addAll(firstEditedMediaItem.effects.videoEffects)
            .addAll(composition.effects.videoEffects)
            .build();
    if (firstEditedMediaItem.speedProvider != SpeedProvider.DEFAULT) {
      return true;
    }
    return !combinedEffects.isEmpty()
        && maybeCalculateTotalRotationDegreesAppliedInEffects(combinedEffects, inputFormat) == -1;
  }

  /**
   * Returns the total rotation degrees of all the rotations in {@code videoEffects}, or {@code -1}
   * if {@code videoEffects} contains any effects that are not no-ops or regular rotations.
   *
   * <p>If all the {@code videoEffects} are either noOps or regular rotations, then the rotations
   * can be applied in the {@linkplain #maybeSetMuxerWrapperAdditionalRotationDegrees(MuxerWrapper,
   * ImmutableList, Format) MuxerWrapper}.
   */
  private static float maybeCalculateTotalRotationDegreesAppliedInEffects(
      ImmutableList<Effect> videoEffects, Format inputFormat) {
    int width = (inputFormat.rotationDegrees % 180 == 0) ? inputFormat.width : inputFormat.height;
    int height = (inputFormat.rotationDegrees % 180 == 0) ? inputFormat.height : inputFormat.width;
    float totalRotationDegrees = 0;
    for (int i = 0; i < videoEffects.size(); i++) {
      Effect videoEffect = videoEffects.get(i);
      if (!(videoEffect instanceof GlEffect)) {
        // We cannot confirm whether Effect instances that are not GlEffect instances are
        // no-ops.
        return -1;
      }
      GlEffect glEffect = (GlEffect) videoEffect;
      if (videoEffect instanceof ScaleAndRotateTransformation) {
        ScaleAndRotateTransformation scaleAndRotateTransformation =
            (ScaleAndRotateTransformation) videoEffect;
        if (scaleAndRotateTransformation.scaleX != 1f
            || scaleAndRotateTransformation.scaleY != 1f) {
          return -1;
        }
        float rotationDegrees = scaleAndRotateTransformation.rotationDegrees;
        if (rotationDegrees % 90f != 0) {
          return -1;
        }
        totalRotationDegrees += rotationDegrees;
        width = (totalRotationDegrees % 180 == 0) ? inputFormat.width : inputFormat.height;
        height = (totalRotationDegrees % 180 == 0) ? inputFormat.height : inputFormat.width;
        continue;
      }
      if (!glEffect.isNoOp(width, height)) {
        return -1;
      }
    }
    totalRotationDegrees %= 360;
    return totalRotationDegrees % 90 == 0 ? totalRotationDegrees : -1;
  }

  /**
   * Sets {@linkplain MuxerWrapper#setAdditionalRotationDegrees(int) the additionalRotationDegrees}
   * on the given {@link MuxerWrapper} if the given {@code videoEffects} only contains a mix of
   * regular rotations and no-ops. A regular rotation is a rotation divisible by 90 degrees.
   */
  /* package */ static void maybeSetMuxerWrapperAdditionalRotationDegrees(
      MuxerWrapper muxerWrapper, ImmutableList<Effect> videoEffects, Format inputFormat) {
    float rotationDegrees =
        maybeCalculateTotalRotationDegreesAppliedInEffects(videoEffects, inputFormat);
    if (rotationDegrees == 90f || rotationDegrees == 180f || rotationDegrees == 270f) {
      // The MuxerWrapper rotation is clockwise while the ScaleAndRotateTransformation rotation
      // is counterclockwise.
      muxerWrapper.setAdditionalRotationDegrees(360 - round(rotationDegrees));
    }
  }

  /**
   * Adjust for invalid {@link ColorInfo} values, by defaulting to {@link
   * ColorInfo#SDR_BT709_LIMITED}.
   */
  public static ColorInfo getValidColor(@Nullable ColorInfo colorInfo) {
    if (colorInfo == null || !colorInfo.isDataSpaceValid()) {
      return ColorInfo.SDR_BT709_LIMITED;
    }
    return colorInfo;
  }

  /** Returns the decoder output color taking tone mapping into account. */
  public static ColorInfo getDecoderOutputColor(
      ColorInfo decoderInputColor, boolean isMediaCodecToneMappingRequested) {
    if (isMediaCodecToneMappingRequested && ColorInfo.isTransferHdr(decoderInputColor)) {
      return SDR_BT709_LIMITED;
    }
    return decoderInputColor;
  }

  /**
   * Calculate what the MIME type and {@link HdrMode} to use, applying fallback measure if
   * necessary.
   *
   * @param hdrMode The {@link HdrMode}.
   * @param requestedOutputMimeType The desired output MIME type.
   * @param colorInfo The {@link ColorInfo}.
   * @return a {@link Pair} of the output MIME type and {@link HdrMode}.
   */
  public static Pair<String, Integer> getOutputMimeTypeAndHdrModeAfterFallback(
      @HdrMode int hdrMode, String requestedOutputMimeType, @Nullable ColorInfo colorInfo) {
    // HdrMode fallback is only supported from HDR_MODE_KEEP_HDR to
    // HDR_MODE_TONE_MAP_HDR_TO_SDR_USING_OPEN_GL.
    if (hdrMode == HDR_MODE_KEEP_HDR && isTransferHdr(colorInfo)) {
      ImmutableList<MediaCodecInfo> hdrEncoders =
          getSupportedEncodersForHdrEditing(requestedOutputMimeType, colorInfo);
      if (hdrEncoders.isEmpty()) {
        // Fallback H.265/HEVC codecs for HDR content to avoid tonemapping.
        hdrEncoders = getSupportedEncodersForHdrEditing(MimeTypes.VIDEO_H265, colorInfo);
        if (!hdrEncoders.isEmpty()) {
          requestedOutputMimeType = MimeTypes.VIDEO_H265;
        } else {
          hdrMode = HDR_MODE_TONE_MAP_HDR_TO_SDR_USING_OPEN_GL;
        }
      }
    }
    return Pair.create(requestedOutputMimeType, hdrMode);
  }

  /** Returns whether the provided {@link MediaItem} corresponds to an image. */
  public static boolean isImage(Context context, MediaItem mediaItem) {
    @Nullable String mimeType = getImageMimeType(context, mediaItem);
    return mimeType != null && MimeTypes.isImage(mimeType);
  }

  /**
   * Returns the image MIME type corresponding to a {@link MediaItem}.
   *
   * <p>This method only supports some common image MIME types.
   *
   * @param context The {@link Context}.
   * @param mediaItem The {@link MediaItem} to inspect.
   * @return The MIME type.
   */
  @Nullable
  public static String getImageMimeType(Context context, MediaItem mediaItem) {
    if (mediaItem.localConfiguration == null) {
      return null;
    }
    MediaItem.LocalConfiguration localConfiguration = mediaItem.localConfiguration;
    @Nullable String mimeType = localConfiguration.mimeType;
    if (mimeType == null) {
      if (Objects.equals(localConfiguration.uri.getScheme(), ContentResolver.SCHEME_CONTENT)) {
        ContentResolver cr = context.getContentResolver();
        mimeType = cr.getType(localConfiguration.uri);
      } else {
        @Nullable String uriPath = localConfiguration.uri.getPath();
        if (uriPath == null) {
          return null;
        }
        int fileExtensionStart = uriPath.lastIndexOf(".");
        if (fileExtensionStart >= 0 && fileExtensionStart < uriPath.length() - 1) {
          String extension = Ascii.toLowerCase(uriPath.substring(fileExtensionStart + 1));
          mimeType = getCommonImageMimeTypeFromExtension(extension);
        }
      }
    }
    return mimeType;
  }

  /**
   * Checks whether any speed changing effects at the first position of each pipeline match {@code
   * speedProvider}.
   *
   * <p>The method verifies that any {@link TimestampAdjustment} or {@link
   * SpeedChangingAudioProcessor} instance set as the first effect of its pipeline has a {@link
   * SpeedProvider} equal to {@code speedProvider}.
   *
   * <p>If no speed changing effects are present, this method returns {@code true}.
   */
  @SuppressWarnings("deprecation") // Uses deprecated TimestampAdjustment.
  public static boolean validateSpeedChangingEffects(Effects effects, SpeedProvider speedProvider) {
    if (!effects.audioProcessors.isEmpty()) {
      AudioProcessor firstProcessor = effects.audioProcessors.get(0);
      if (firstProcessor instanceof SpeedChangingAudioProcessor) {
        SpeedChangingAudioProcessor speedChangingAudioProcessor =
            (SpeedChangingAudioProcessor) firstProcessor;
        if (!speedChangingAudioProcessor.getSpeedProvider().equals(speedProvider)) {
          return false;
        }
      }
    }

    if (!effects.videoEffects.isEmpty()) {
      Effect firstEffect = effects.videoEffects.get(0);
      if (firstEffect instanceof TimestampAdjustment) {
        TimestampAdjustment timestampAdjustmentEffect = (TimestampAdjustment) firstEffect;
        return timestampAdjustmentEffect.speedProvider.equals(speedProvider);
      }
    }

    return true;
  }

  /**
   * Returns whether {@link Effects} contains speed changing effects.
   *
   * <p>{@code ignoreFirstEffect} controls whether {@link TimestampAdjustment} and {@link
   * SpeedChangingAudioProcessor} are ignored as first elements of the video and audio pipelines,
   * respectively.
   */
  @SuppressWarnings("deprecation") // Uses deprecated SpeedChangeEffect and TimestampAdjustment.
  public static boolean containsSpeedChangingEffects(Effects effects, boolean ignoreFirstEffect) {
    for (int i = ignoreFirstEffect ? 1 : 0; i < effects.audioProcessors.size(); i++) {
      if (effects.audioProcessors.get(i) instanceof SpeedChangingAudioProcessor) {
        return true;
      }

      // Use an arbitrarily large number as a best effort check.
      if (effects.audioProcessors.get(i).getDurationAfterProcessorApplied(1_000_000_000L)
          != 1_000_000_000L) {
        return true;
      }
    }

    for (int i = 0; i < effects.videoEffects.size(); i++) {
      Effect effect = effects.videoEffects.get(i);
      if (effect instanceof SpeedChangeEffect) {
        return true;
      }

      if (effect instanceof TimestampAdjustment && (!ignoreFirstEffect || i > 0)) {
        return true;
      }
    }

    return false;
  }

  /**
   * Returns the offset between a renderer timestamp and the start of the {@link Composition}.
   *
   * @param timeline The {@link Timeline} associated with this renderer.
   * @param mediaPeriodId The {@link MediaSource.MediaPeriodId}.
   * @param offsetUs The offset added to timestamps of buffers to ensure monotonically increasing
   *     timestamps, in microseconds. This is the constant offset between the current MediaPeriod
   *     timestamps and the renderer timestamp.
   *     <p>See <a
   *     href="https://developer.android.com/reference/androidx/media3/exoplayer/Renderer#timestamps-and-offsets">this
   *     corresponding topic on timestamps</a>.
   */
  public static long getOffsetToCompositionTimeUs(
      Timeline timeline, MediaPeriodId mediaPeriodId, long offsetUs) {
    Timeline.Period period =
        timeline.getPeriodByUid(mediaPeriodId.periodUid, new Timeline.Period());
    return -offsetUs + period.positionInWindowUs;
  }

  /**
   * Returns the {@link EditedMediaItemSequence} corresponding to {@code mediaPeriodId} within
   * {@code timeline}.
   *
   * <p>If {@code mediaPeriodId} does not map to a sequence this method will throw a {@link
   * IllegalStateException}.
   *
   * @param timeline The {@link Timeline} associated to the {@link EditedMediaItemSequence}.
   * @param mediaPeriodId The {@link MediaPeriodId} associated to the {@link
   *     EditedMediaItemSequence}.
   */
  public static EditedMediaItemSequence getEditedMediaItemSequence(
      Timeline timeline, MediaPeriodId mediaPeriodId) {
    Timeline.Period period =
        timeline.getPeriodByUid(mediaPeriodId.periodUid, new Timeline.Period());
    checkState(period.id instanceof EditedMediaItemSequence);
    return (EditedMediaItemSequence) period.id;
  }

  /**
   * Returns the {@link EditedMediaItem} corresponding to {@code mediaPeriodId} within {@code
   * timeline}.
   *
   * @param timeline The {@link Timeline} associated to the {@link EditedMediaItem}.
   * @param mediaPeriodId The {@link MediaPeriodId} associated to the {@link EditedMediaItem}.
   */
  public static EditedMediaItem getEditedMediaItem(Timeline timeline, MediaPeriodId mediaPeriodId) {
    EditedMediaItemSequence sequence = getEditedMediaItemSequence(timeline, mediaPeriodId);
    return sequence.editedMediaItems.get(getEditedMediaItemIndex(timeline, mediaPeriodId));
  }

  /**
   * Returns the index of the {@link EditedMediaItem} corresponding to {@code mediaPeriodId} within
   * {@code timeline}.
   *
   * @param timeline The {@link Timeline} associated to the {@link EditedMediaItem}.
   * @param mediaPeriodId The {@link MediaPeriodId} associated to the {@link EditedMediaItem}.
   */
  public static int getEditedMediaItemIndex(Timeline timeline, MediaPeriodId mediaPeriodId) {
    int index = timeline.getIndexOfPeriod(mediaPeriodId.periodUid);
    EditedMediaItemSequence sequence = getEditedMediaItemSequence(timeline, mediaPeriodId);
    return EditedMediaItemSequence.getEditedMediaItemIndex(sequence, index);
  }

  /**
   * Releases {@code object} if it implements {@link ReferenceCounter}.
   *
   * <p>If {@code object} is not a {@link ReferenceCounter} and {@code releaseFence} is non-null,
   * the fence is closed silently to prevent leaks.
   *
   * @param object The object to release, or {@code null}.
   * @param releaseFence An optional {@link SyncFenceWrapper} signaling when hardware resources are
   *     safe for reuse.
   */
  /* package */ static void releaseIfNeeded(
      @Nullable Object object, @Nullable SyncFenceWrapper releaseFence) {
    if (object instanceof ReferenceCounter) {
      ((ReferenceCounter) object).release(releaseFence);
    } else if (releaseFence != null) {
      releaseFence.close();
    }
  }

  /**
   * Releases each object in {@code objects} if it implements {@link ReferenceCounter}.
   *
   * @param objects The collection of objects to release.
   */
  /* package */ static void releaseIfNeeded(List<?> objects) {
    for (int i = 0; i < objects.size(); i++) {
      releaseIfNeeded(objects.get(i), /* releaseFence= */ null);
    }
  }

  @Nullable
  private static String getCommonImageMimeTypeFromExtension(String extension) {
    switch (extension) {
      case "bmp":
      case "dib":
        return MimeTypes.IMAGE_BMP;
      case "heif":
        return MimeTypes.IMAGE_HEIF;
      case "heic":
        return MimeTypes.IMAGE_HEIC;
      case "jpg":
      case "jpeg":
      case "jpe":
      case "jif":
      case "jfif":
      case "jfi":
        return MimeTypes.IMAGE_JPEG;
      case "png":
        return MimeTypes.IMAGE_PNG;
      case "webp":
        return MimeTypes.IMAGE_WEBP;
      case "gif":
        return "image/gif";
      case "tiff":
      case "tif":
        return "image/tiff";
      case "raw":
      case "arw":
      case "cr2":
      case "k25":
        return "image/raw";
      case "svg":
      case "svgz":
        return "image/svg+xml";
      case "ico":
        return "image/x-icon";
      case "avif":
        return MimeTypes.IMAGE_AVIF;
      default:
        return null;
    }
  }

  /** Utility for setting LogSessionId on MediaFormat (API 35+). */
  @RequiresApi(35)
  public static final class Api35 {
    private Api35() {}

    /**
     * Sets the log session ID to the provided {@link MediaFormat}.
     *
     * @param mediaFormat The {@link MediaFormat} to set the log session ID on.
     * @param logSessionId The {@link LogSessionId} to set.
     */
    public static void setLogSessionIdToMediaCodecFormat(
        MediaFormat mediaFormat, LogSessionId logSessionId) {
      if (!logSessionId.equals(LogSessionId.LOG_SESSION_ID_NONE)) {
        mediaFormat.setString("log-session-id", logSessionId.getStringId());
      }
    }
  }
}
