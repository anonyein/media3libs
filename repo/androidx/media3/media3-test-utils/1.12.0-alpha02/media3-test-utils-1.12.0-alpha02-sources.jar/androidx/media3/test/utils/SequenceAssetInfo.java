/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.test.utils;

import static com.google.common.base.Preconditions.checkNotNull;

import androidx.media3.common.C.TrackType;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.transformer.EditedMediaItemSequence;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Iterables;
import java.util.List;
import java.util.Set;

/** Test assets that describe various {@link EditedMediaItemSequence} configurations. */
@UnstableApi
public final class SequenceAssetInfo {
  public final ImmutableList<EditedMediaItemAssetInfo> assets;
  public final ImmutableSet<@TrackType Integer> trackTypes;
  private final boolean isLooping;

  public SequenceAssetInfo(
      Set<@TrackType Integer> trackTypes,
      EditedMediaItemAssetInfo asset,
      EditedMediaItemAssetInfo... assets) {
    this(/* isLooping= */ false, trackTypes, asset, assets);
  }

  public SequenceAssetInfo(
      boolean isLooping,
      Set<@TrackType Integer> trackTypes,
      EditedMediaItemAssetInfo asset,
      EditedMediaItemAssetInfo... assets) {
    this.assets =
        new ImmutableList.Builder<EditedMediaItemAssetInfo>().add(asset).add(assets).build();
    this.trackTypes = ImmutableSet.copyOf(trackTypes);
    this.isLooping = isLooping;
  }

  public EditedMediaItemSequence getEditedMediaItemSequence() {
    EditedMediaItemSequence.Builder sequenceBuilder =
        new EditedMediaItemSequence.Builder(trackTypes);
    for (EditedMediaItemAssetInfo asset : assets) {
      sequenceBuilder.addItem(checkNotNull(asset.getEditedMediaItem()));
    }
    sequenceBuilder.setIsLooping(isLooping);
    return sequenceBuilder.build();
  }

  public ImmutableList<Long> getExpectedVideoTimestampsUs() {
    return getExpectedVideoTimestampsUs(assets, /* offsetUs= */ 0);
  }

  public static ImmutableList<Long> getExpectedVideoTimestampsUs(
      List<EditedMediaItemAssetInfo> assets, long offsetUs) {
    ImmutableList.Builder<Long> expectedVideoTimestampsUs = new ImmutableList.Builder<>();
    long previousDuration = offsetUs;
    for (EditedMediaItemAssetInfo asset : assets) {
      long finalPreviousDuration = previousDuration;
      ImmutableList<Long> videoTimestampsUs =
          asset.videoTimestampsUs == null ? ImmutableList.of() : asset.videoTimestampsUs;
      expectedVideoTimestampsUs.addAll(
          Iterables.transform(
              videoTimestampsUs, timestampUs -> finalPreviousDuration + timestampUs));
      previousDuration += checkNotNull(asset.getEditedMediaItem()).getPresentationDurationUs();
    }
    return expectedVideoTimestampsUs.build();
  }

  @Override
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    for (EditedMediaItemAssetInfo asset : assets) {
      stringBuilder.append(asset);
    }
    if (isLooping) {
      stringBuilder.append("Loop");
    }
    return stringBuilder.toString();
  }
}
