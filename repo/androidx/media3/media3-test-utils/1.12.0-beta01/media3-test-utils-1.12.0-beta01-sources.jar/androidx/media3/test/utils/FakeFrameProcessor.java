/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.test.utils;

import static com.google.common.base.Preconditions.checkState;
import static com.google.common.util.concurrent.MoreExecutors.directExecutor;

import androidx.media3.common.VideoFrameProcessingException;
import androidx.media3.common.util.ExperimentalApi;
import androidx.media3.common.video.AsyncFrame;
import androidx.media3.common.video.Frame;
import androidx.media3.common.video.FrameProcessor;
import androidx.media3.common.video.FrameWriter;
import androidx.media3.common.video.SyncFenceWrapper;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import org.jspecify.annotations.Nullable;

/** A fake {@link FrameProcessor} implementation. */
@ExperimentalApi // TODO: b/498176910 Remove once FrameProcessor is production ready.
public class FakeFrameProcessor implements FrameProcessor {

  /** A fake {@link FrameProcessor.Listener} implementation for tests. */
  public static class Listener implements FrameProcessor.Listener {

    private static final long DEFAULT_FENCE_TIMEOUT_MS = 10_000;

    public final List<Frame> processedFrames;
    public final AtomicReference<VideoFrameProcessingException> error;

    private final long fenceTimeoutMs;

    /** Creates a new instance with a default fence timeout of 10 seconds. */
    public Listener() {
      this(DEFAULT_FENCE_TIMEOUT_MS);
    }

    /**
     * Creates a new instance.
     *
     * @param fenceTimeoutMs The timeout in milliseconds when awaiting {@code onCompleteFence} in
     *     {@link #onFrameProcessed}.
     */
    public Listener(long fenceTimeoutMs) {
      this.fenceTimeoutMs = fenceTimeoutMs;
      processedFrames = new CopyOnWriteArrayList<>();
      error = new AtomicReference<>();
    }

    @Override
    public void onWakeup() {}

    @Override
    public void onError(VideoFrameProcessingException exception) {
      error.set(exception);
    }

    @Override
    public void onFrameProcessed(Frame frame, @Nullable SyncFenceWrapper onCompleteFence) {
      if (onCompleteFence != null) {
        try {
          checkState(onCompleteFence.awaitMs(fenceTimeoutMs), "Fence wait timeout");
        } finally {
          onCompleteFence.close();
        }
      }
      processedFrames.add(frame);
    }
  }

  /** A factory for {@link FakeFrameProcessor} implementations. */
  public static class Factory implements FrameProcessor.Factory {

    public @Nullable FakeFrameProcessor createdProcessor;

    private final boolean shouldCompleteIncomingFrames;

    /**
     * Creates a new instance.
     *
     * @param shouldCompleteIncomingFrames When true, the {@link FrameProcessor} will call the
     *     completion listener for every queued frame.
     */
    public Factory(boolean shouldCompleteIncomingFrames) {
      this.shouldCompleteIncomingFrames = shouldCompleteIncomingFrames;
    }

    @Override
    public FakeFrameProcessor create(
        FrameWriter output, Executor listenerExecutor, FrameProcessor.Listener listener) {
      createdProcessor =
          new FakeFrameProcessor(output, listenerExecutor, listener, shouldCompleteIncomingFrames);
      return createdProcessor;
    }

    /** Helper create method for tests that don't need to specify listener. */
    public FakeFrameProcessor create(FrameWriter output) {
      return create(output, directExecutor(), new Listener());
    }
  }

  public final FrameWriter output;
  public final AtomicBoolean eosSignaled;
  public final AtomicBoolean closed;

  public int queuedFramesCount;

  private final Executor listenerExecutor;
  private final FrameProcessor.Listener listener;
  private final boolean shouldCompleteIncomingFrames;

  private boolean configured;

  private FakeFrameProcessor(
      FrameWriter output,
      Executor listenerExecutor,
      FrameProcessor.Listener listener,
      boolean shouldCompleteIncomingFrames) {
    this.output = output;
    this.eosSignaled = new AtomicBoolean();
    this.closed = new AtomicBoolean();
    this.listenerExecutor = listenerExecutor;
    this.listener = listener;
    this.shouldCompleteIncomingFrames = shouldCompleteIncomingFrames;
  }

  @Override
  public boolean queue(List<AsyncFrame> frames) {
    queuedFramesCount++;
    if (!configured && !frames.isEmpty()) {
      output.configure(frames.get(0).frame.getFormat(), /* usage= */ 0);
      configured = true;
      @Nullable AsyncFrame placeholderFrame =
          output.dequeueInputFrame(directExecutor(), /* wakeupListener= */ () -> {});
      if (placeholderFrame != null) {
        if (placeholderFrame.acquireFence != null) {
          placeholderFrame.acquireFence.close();
        }
        // This forces lazy configuration on some FrameWriter implementations.
        output.queueInputFrame(placeholderFrame.frame, /* writeCompleteFence= */ null);
      }
    }
    if (shouldCompleteIncomingFrames) {
      for (AsyncFrame asyncFrame : frames) {
        listenerExecutor.execute(
            () -> listener.onFrameProcessed(asyncFrame.frame, /* onCompleteFence= */ null));
      }
    }
    return true;
  }

  @Override
  public void signalEndOfStream() {
    eosSignaled.set(true);
    output.signalEndOfStream();
  }

  @Override
  public void close() {
    closed.set(true);
  }

  /** Simulates a video frame processing error by notifying the listener. */
  public void triggerError(VideoFrameProcessingException exception) {
    listenerExecutor.execute(() -> listener.onError(exception));
  }
}
