/*
 * Copyright (C) 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.test.utils;

import static com.google.common.base.Preconditions.checkArgument;

import androidx.media3.common.AdPlaybackState;
import androidx.media3.common.AdViewProvider;
import androidx.media3.common.C.ContentType;
import androidx.media3.common.Player;
import androidx.media3.common.Timeline;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DataSpec;
import androidx.media3.exoplayer.source.ads.AdsLoader;
import androidx.media3.exoplayer.source.ads.AdsMediaSource;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.jspecify.annotations.Nullable;

/** A fake implementation of {@link AdsLoader}. */
@UnstableApi
public final class FakeAdsLoader implements AdsLoader {

  public final Map<Object, EventListener> eventListeners;
  private final Map<Object, AdPlaybackState> initialAdPlaybackStates;

  public @Nullable Player player;
  public int @ContentType [] supportedContentTypes;

  /** Creates an instance. */
  public FakeAdsLoader() {
    supportedContentTypes = new int[0];
    eventListeners = new HashMap<>();
    initialAdPlaybackStates = new HashMap<>();
  }

  /**
   * Pre-registers the initial {@link AdPlaybackState} to publish when {@link #start} is called for
   * {@code adsId}.
   *
   * @throws IllegalArgumentException If {@code initialAdPlaybackState.adsId} does not equal {@code
   *     adsId}.
   */
  public void setInitialAdPlaybackState(Object adsId, AdPlaybackState initialAdPlaybackState) {
    checkArgument(
        adsId.equals(initialAdPlaybackState.adsId),
        "initialAdPlaybackState.adsId (%s) must equal adsId (%s)",
        initialAdPlaybackState.adsId,
        adsId);
    initialAdPlaybackStates.put(adsId, initialAdPlaybackState);
  }

  @Override
  public void setSupportedContentTypes(@ContentType int... contentTypes) {
    supportedContentTypes = contentTypes;
  }

  @Override
  public void setPlayer(@Nullable Player player) {
    this.player = player;
  }

  @Override
  public void start(
      AdsMediaSource adsMediaSource,
      DataSpec adTagDataSpec,
      Object adsId,
      AdViewProvider adViewProvider,
      EventListener eventListener) {
    this.eventListeners.put(adsId, eventListener);
    @Nullable AdPlaybackState initialState = initialAdPlaybackStates.get(adsId);
    if (initialState != null) {
      eventListener.onAdPlaybackState(initialState);
    }
  }

  @Override
  public boolean handleContentTimelineChanged(AdsMediaSource adsMediaSource, Timeline timeline) {
    return false;
  }

  @Override
  public void handlePrepareComplete(
      AdsMediaSource adsMediaSource, int adGroupIndex, int adIndexInAdGroup) {
    // Do nothing.
  }

  @Override
  public void handlePrepareError(
      AdsMediaSource adsMediaSource,
      int adGroupIndex,
      int adIndexInAdGroup,
      IOException exception) {
    // Do nothing.
  }

  @Override
  public void stop(AdsMediaSource adsMediaSource, EventListener eventListener) {
    Object adsId = adsMediaSource.getAdsId();
    this.eventListeners.remove(adsId);
  }

  @Override
  public void release() {
    player = null;
    supportedContentTypes = new int[0];
  }
}
