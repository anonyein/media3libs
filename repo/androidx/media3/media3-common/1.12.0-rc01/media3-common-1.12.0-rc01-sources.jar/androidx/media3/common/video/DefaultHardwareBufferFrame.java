/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.common.video;

import android.hardware.HardwareBuffer;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.annotation.RestrictTo.Scope;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import com.google.common.collect.ImmutableMap;
import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.util.Map;
import java.util.concurrent.Executor;
import org.jspecify.annotations.Nullable;

/** Default implementation of {@link HardwareBufferFrame}. */
@RestrictTo(Scope.LIBRARY_GROUP)
public final class DefaultHardwareBufferFrame implements HardwareBufferFrame, ReferenceCounter {

  /** Concrete implementation of {@link HardwareBufferFrame.Builder}. */
  public static final class Builder
      implements HardwareBufferFrame.Builder, ReferenceCounter.Builder {

    private final HardwareBuffer hardwareBuffer;
    private final SharedStateReferenceCounter.Builder delegateCounterBuilder;
    private Format format;
    private ImmutableMap<String, Object> metadata;
    private long contentTimeUs;
    private @Nullable Object internalImage;

    /**
     * Creates a builder for {@link HardwareBufferFrame} instances without lifecycle management.
     *
     * @param hardwareBuffer The {@link HardwareBuffer} that backs the frame.
     */
    @RequiresApi(26)
    public Builder(HardwareBuffer hardwareBuffer) {
      this.hardwareBuffer = hardwareBuffer;
      this.delegateCounterBuilder = new SharedStateReferenceCounter.Builder();
      this.format = new Format.Builder().build();
      this.metadata = ImmutableMap.of();
      this.contentTimeUs = C.TIME_UNSET;
    }

    /**
     * Creates a builder for reference-counted {@link HardwareBufferFrame} instances.
     *
     * @param hardwareBuffer The {@link HardwareBuffer} that backs the frame.
     * @param releaseExecutor The {@link Executor} on which {@code releaseCallback} is called.
     * @param releaseCallback The callback invoked when the frame is fully released.
     */
    @RequiresApi(26)
    public Builder(
        HardwareBuffer hardwareBuffer, Executor releaseExecutor, ReleaseCallback releaseCallback) {
      this.hardwareBuffer = hardwareBuffer;
      this.delegateCounterBuilder =
          new SharedStateReferenceCounter.Builder(releaseExecutor, releaseCallback);
      this.format = new Format.Builder().build();
      this.metadata = ImmutableMap.of();
      this.contentTimeUs = C.TIME_UNSET;
    }

    private Builder(DefaultHardwareBufferFrame frame) {
      this.hardwareBuffer = frame.hardwareBuffer;
      this.delegateCounterBuilder =
          new SharedStateReferenceCounter.Builder(frame.delegateCounter.getSharedState());
      this.format = frame.format;
      this.metadata = frame.metadata;
      this.contentTimeUs = frame.contentTimeUs;
      this.internalImage = frame.internalImage;
    }

    @CanIgnoreReturnValue
    @Override
    public DefaultHardwareBufferFrame.Builder shouldIncrementReferenceCount() {
      delegateCounterBuilder.shouldIncrementReferenceCount();
      return this;
    }

    @Override
    public DefaultHardwareBufferFrame build() {
      return new DefaultHardwareBufferFrame(this);
    }

    @CanIgnoreReturnValue
    @Override
    public DefaultHardwareBufferFrame.Builder setMetadata(Map<String, Object> metadata) {
      this.metadata = ImmutableMap.copyOf(metadata);
      return this;
    }

    @CanIgnoreReturnValue
    @Override
    public DefaultHardwareBufferFrame.Builder setContentTimeUs(long contentTimeUs) {
      this.contentTimeUs = contentTimeUs;
      return this;
    }

    @CanIgnoreReturnValue
    public DefaultHardwareBufferFrame.Builder setFormat(Format format) {
      this.format = format;
      return this;
    }

    @CanIgnoreReturnValue
    public DefaultHardwareBufferFrame.Builder setInternalImage(@Nullable Object internalImage) {
      this.internalImage = internalImage;
      return this;
    }
  }

  private final HardwareBuffer hardwareBuffer;
  private final Format format;
  private final ImmutableMap<String, Object> metadata;
  private final long contentTimeUs;
  private final @Nullable Object internalImage;
  private final SharedStateReferenceCounter delegateCounter;

  /** Private constructor used by the builder. */
  private DefaultHardwareBufferFrame(Builder builder) {
    this.hardwareBuffer = builder.hardwareBuffer;
    this.format = builder.format;
    this.metadata = builder.metadata;
    this.contentTimeUs = builder.contentTimeUs;
    this.internalImage = builder.internalImage;
    this.delegateCounter = builder.delegateCounterBuilder.build();
  }

  @Override
  public Format getFormat() {
    return format;
  }

  @Override
  public ImmutableMap<String, Object> getMetadata() {
    return metadata;
  }

  @Override
  public long getContentTimeUs() {
    return contentTimeUs;
  }

  @RequiresApi(26)
  @Override
  public HardwareBuffer getHardwareBuffer() {
    return hardwareBuffer;
  }

  @Override
  public DefaultHardwareBufferFrame.Builder buildUpon() {
    delegateCounter.checkNotReleased(
        "Cannot buildUpon a DefaultHardwareBufferFrame that has already been released.");
    return new Builder(this);
  }

  @Override
  public void release(@Nullable SyncFenceWrapper releaseFence) {
    delegateCounter.release(releaseFence);
  }

  public @Nullable Object getInternalImage() {
    return internalImage;
  }
}
