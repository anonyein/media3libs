/*
 * Copyright (C) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.common.util;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.base.Preconditions.checkState;
import static java.lang.Math.max;

import android.annotation.SuppressLint;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaCodecInfo.CodecProfileLevel;
import android.os.Build.VERSION;
import android.util.Pair;
import androidx.annotation.Nullable;
import androidx.media3.common.C;
import androidx.media3.common.ColorInfo;
import androidx.media3.common.Format;
import androidx.media3.common.MimeTypes;
import com.google.common.collect.ImmutableList;
import com.google.common.primitives.UnsignedBytes;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Provides utilities for handling various types of codec-specific data. */
@SuppressLint("InlinedApi")
@UnstableApi
public final class CodecSpecificDataUtil {

  /**
   * A tuple of profile and level constants for {@link MediaCodec}.
   *
   * <p>This is similar to {@link MediaCodecInfo.CodecProfileLevel}, except it:
   *
   * <ul>
   *   <li>Is immutable.
   *   <li>Can be used to represent a profile and level that may be valid but isn't representable by
   *       {@link MediaCodecInfo.CodecProfileLevel} constants.
   * </ul>
   */
  public static final class MediaCodecProfileAndLevel {

    /**
     * An instance that represents a profile and level combination not representable with {@link
     * MediaCodecInfo.CodecProfileLevel} constants.
     */
    public static final MediaCodecProfileAndLevel UNSUPPORTABLE =
        new MediaCodecProfileAndLevel(
            /* profile= */ 0, /* level= */ 0, /* isSupportableByMediaCodec= */ false);

    private final int profile;
    private final int level;
    private final boolean isSupportableByMediaCodec;

    /** Constructs an instance with values from {@link MediaCodecInfo.CodecProfileLevel}. */
    public MediaCodecProfileAndLevel(int profile, int level) {
      this(profile, level, /* isSupportableByMediaCodec= */ true);
    }

    private MediaCodecProfileAndLevel(int profile, int level, boolean isSupportableByMediaCodec) {
      this.isSupportableByMediaCodec = isSupportableByMediaCodec;
      this.profile = profile;
      this.level = level;
    }

    /**
     * Returns the profile value, which will be a constant from {@link
     * MediaCodecInfo.CodecProfileLevel}.
     *
     * <p>Callers must check {@link #isSupportableByMediaCodec()} returns {@code true} before
     * calling this method.
     */
    public int getProfile() {
      checkState(isSupportableByMediaCodec);
      return profile;
    }

    /**
     * Returns the level value, which will be a constant from {@link
     * MediaCodecInfo.CodecProfileLevel}.
     *
     * <p>Callers must check {@link #isSupportableByMediaCodec()} returns {@code true} before
     * calling this method.
     */
    public int getLevel() {
      checkState(isSupportableByMediaCodec);
      return level;
    }

    /**
     * Returns whether the profile and level represented by this instance can be represented by
     * {@link MediaCodecInfo.CodecProfileLevel} constants.
     *
     * <p>This is based on the set of constants available when this library was compiled. It is not
     * related to the {@link VERSION#SDK_INT} of the current device.
     */
    public boolean isSupportableByMediaCodec() {
      return isSupportableByMediaCodec;
    }
  }

  private static final byte[] NAL_START_CODE = new byte[] {0, 0, 0, 1};
  private static final String[] HEVC_GENERAL_PROFILE_SPACE_STRINGS =
      new String[] {"", "A", "B", "C"};

  // MP4V-ES
  private static final int VISUAL_OBJECT_LAYER = 1;
  private static final int VISUAL_OBJECT_LAYER_START = 0x20;
  private static final int EXTENDED_PAR = 0x0F;
  private static final int RECTANGULAR = 0x00;

  // VP9 constants from VP9 Bitstream Specification.
  private static final int VP9_FRAME_MARKER = 0b10;
  private static final int VP9_FRAME_TYPE_KEY_FRAME = 0;
  private static final int VP9_SYNC_CODE = 0x498342;
  private static final int VP9_COLOR_SPACE_RGB = 7;
  private static final int VP9_CHROMA_SUBSAMPLING_420 = 0;
  private static final int VP9_CHROMA_SUBSAMPLING_422 = 2;
  private static final int VP9_CHROMA_SUBSAMPLING_444 = 3;
  private static final int VP9_MAX_UNCOMPRESSED_HEADER_SIZE_BYTES = 128;

  // IAMF OBU types.
  private static final int OBU_IA_CODEC_CONFIG = 0x00;
  private static final int OBU_IA_SEQUENCE_HEADER = 0x1F;

  // Codecs to constant mappings.
  // H263
  private static final String CODEC_ID_H263 = "s263";
  // AVC.
  private static final String CODEC_ID_AVC1 = "avc1";
  private static final String CODEC_ID_AVC2 = "avc2";
  // VP9
  private static final String CODEC_ID_VP09 = "vp09";
  // HEVC.
  private static final String CODEC_ID_HEV1 = "hev1";
  private static final String CODEC_ID_HVC1 = "hvc1";
  // VVC.
  private static final String CODEC_ID_VVC1 = "vvc1";
  private static final String CODEC_ID_VVI1 = "vvi1";
  // AV1.
  private static final String CODEC_ID_AV01 = "av01";
  // APV.
  private static final String CODEC_ID_APV1 = "apv1";
  // MP4A AAC.
  private static final String CODEC_ID_MP4A = "mp4a";
  // AC-4
  private static final String CODEC_ID_AC4 = "ac-4";
  // IAMF
  private static final String CODEC_ID_IAMF = "iamf";

  // TODO(b/482032815): Replace VVC literal constants with MediaCodecInfo.CodecProfileLevel
  // constants when compile SDK is updated to 37.
  private static final int VVC_PROFILE_MAIN_8 = 0x01;
  private static final int VVC_PROFILE_MAIN_10 = 0x02;
  private static final int VVC_PROFILE_MAIN_10_STILL = 0x04;
  private static final int VVC_PROFILE_MAIN_10_HDR10 = 0x1000;

  private static final int VVC_MAIN_TIER_LEVEL_1_0 = 0x01;
  private static final int VVC_MAIN_TIER_LEVEL_2_0 = 0x02;
  private static final int VVC_MAIN_TIER_LEVEL_2_1 = 0x04;
  private static final int VVC_MAIN_TIER_LEVEL_3_0 = 0x08;
  private static final int VVC_MAIN_TIER_LEVEL_3_1 = 0x10;
  private static final int VVC_MAIN_TIER_LEVEL_4_0 = 0x20;
  private static final int VVC_HIGH_TIER_LEVEL_4_0 = 0x40;
  private static final int VVC_MAIN_TIER_LEVEL_4_1 = 0x80;
  private static final int VVC_HIGH_TIER_LEVEL_4_1 = 0x100;
  private static final int VVC_MAIN_TIER_LEVEL_5_0 = 0x200;
  private static final int VVC_HIGH_TIER_LEVEL_5_0 = 0x400;
  private static final int VVC_MAIN_TIER_LEVEL_5_1 = 0x800;
  private static final int VVC_HIGH_TIER_LEVEL_5_1 = 0x1000;
  private static final int VVC_MAIN_TIER_LEVEL_5_2 = 0x2000;
  private static final int VVC_HIGH_TIER_LEVEL_5_2 = 0x4000;
  private static final int VVC_MAIN_TIER_LEVEL_6_0 = 0x8000;
  private static final int VVC_HIGH_TIER_LEVEL_6_0 = 0x10000;
  private static final int VVC_MAIN_TIER_LEVEL_6_1 = 0x20000;
  private static final int VVC_HIGH_TIER_LEVEL_6_1 = 0x40000;
  private static final int VVC_MAIN_TIER_LEVEL_6_2 = 0x80000;
  private static final int VVC_HIGH_TIER_LEVEL_6_2 = 0x100000;
  private static final int VVC_MAIN_TIER_LEVEL_6_3 = 0x200000;
  private static final int VVC_HIGH_TIER_LEVEL_6_3 = 0x400000;

  private static final Pattern PROFILE_PATTERN = Pattern.compile("^\\D?(\\d+)$");

  private static final String TAG = "CodecSpecificDataUtil";

  /**
   * Parses an ALAC AudioSpecificConfig (i.e. an <a
   * href="https://github.com/macosforge/alac/blob/master/ALACMagicCookieDescription.txt">ALACSpecificConfig</a>).
   *
   * @param audioSpecificConfig A byte array containing the AudioSpecificConfig to parse.
   * @return An int array consisting of the sample rate in Hz, the channel count and the bit depth.
   */
  public static int[] parseAlacAudioSpecificConfig(byte[] audioSpecificConfig) {
    ParsableByteArray byteArray = new ParsableByteArray(audioSpecificConfig);
    byteArray.setPosition(5);
    int bitDepth = byteArray.readUnsignedByte();
    byteArray.setPosition(9);
    int channelCount = byteArray.readUnsignedByte();
    byteArray.setPosition(20);
    int sampleRate = byteArray.readUnsignedIntToInt();
    return new int[] {sampleRate, channelCount, bitDepth};
  }

  /**
   * Returns initialization data for formats with MIME type {@link MimeTypes#APPLICATION_CEA708}.
   *
   * @param isWideAspectRatio Whether the CEA-708 closed caption service is formatted for displays
   *     with 16:9 aspect ratio.
   * @return Initialization data for formats with MIME type {@link MimeTypes#APPLICATION_CEA708}.
   */
  public static List<byte[]> buildCea708InitializationData(boolean isWideAspectRatio) {
    return Collections.singletonList(isWideAspectRatio ? new byte[] {1} : new byte[] {0});
  }

  /**
   * Builds an RFC 6381 IAMF codec string from the given {@code initializationData}.
   *
   * <p>The format is defined by the <a
   * href="https://aomediacodec.github.io/iamf/#codecsparameter">IAMF Codec Parameters String</a>
   * specification.
   */
  @Nullable
  public static String buildIamfCodecString(byte[] initializationData) {
    ParsableByteArray parsableByteArray = new ParsableByteArray(initializationData);

    @Nullable String iaSequenceHeader = null;
    @Nullable String codecConfigCodecId = null;

    while (parsableByteArray.bytesLeft() > 0
        && (iaSequenceHeader == null || codecConfigCodecId == null)) {
      // OBUHeader
      // obu_type (5 bits) + obu_redundant_copy (1 bit) + obu_trimming_status_flag  (1 bit) +
      // obu_extension_flag (1 bit)
      int obuHeaderByte = parsableByteArray.readUnsignedByte();
      int obuType = obuHeaderByte >> 3; // obu_type (5 bits)
      // skip obu_redundant_copy (1 bit)
      boolean obuTrimmingStatusFlag = (obuHeaderByte & 0x2) != 0; // obu_trimming_status (1 bit)
      boolean obuExtensionFlag = (obuHeaderByte & 0x1) != 0; // obu_extension (1 bit)

      int obuSize = parsableByteArray.readUnsignedLeb128ToInt(); // obu_size

      if ((obuType > 4 && obuType < 24) && obuTrimmingStatusFlag) {
        parsableByteArray.skipLeb128(); // num_samples_to_trim_at_end
        parsableByteArray.skipLeb128(); // num_samples_to_trim_at_start
      }
      if (obuExtensionFlag) {
        int extensionHeaderSize =
            parsableByteArray.readUnsignedLeb128ToInt(); // extension_header_size
        parsableByteArray.skipBytes(extensionHeaderSize); // extension_header_bytes
      }

      int nextObuPosition = parsableByteArray.getPosition() + obuSize;
      if (obuType == OBU_IA_SEQUENCE_HEADER) { // OBU_IA_Sequence_Header
        // IASequenceHeaderOBU
        parsableByteArray.skipBytes(4); // ia_code (4 bytes)
        int primaryProfile = parsableByteArray.readUnsignedByte(); // primary_profile (1 byte)
        int additionalProfile = parsableByteArray.readUnsignedByte(); // additional_profile (1 byte)
        iaSequenceHeader =
            Util.formatInvariant("iamf.%03X.%03X", primaryProfile, additionalProfile);
      } else if (obuType == OBU_IA_CODEC_CONFIG) { // OBU_IA_Codec_Config
        // CodecConfigOBU
        parsableByteArray.skipLeb128(); // codec_config_id
        codecConfigCodecId = parsableByteArray.readString(4); // codec_id (4 bytes)

        if (codecConfigCodecId.equals(CODEC_ID_MP4A)) {
          parsableByteArray.skipLeb128(); // num_samples_per_frame
          parsableByteArray.skipBytes(2); // audio_roll_distance (2 bytes)

          ParsableBitArray decoderConfigBitArray = new ParsableBitArray();
          decoderConfigBitArray.reset(parsableByteArray);
          int audioObjectType = decoderConfigBitArray.readBits(5);
          // If audioObjectType is an escape value, then we need to read extra 6 bits.
          // Refer to ISO/IEC 14496-3 (2005) Table 1.14 for more details.
          if (audioObjectType == 0x1F) {
            audioObjectType = 32 + decoderConfigBitArray.readBits(6);
          }
          codecConfigCodecId += ".40." + audioObjectType;
        }
      }

      parsableByteArray.setPosition(nextObuPosition);
    }

    if (iaSequenceHeader != null && codecConfigCodecId != null) {
      return iaSequenceHeader + "." + codecConfigCodecId;
    } else {
      return null;
    }
  }

  /**
   * Returns whether the CEA-708 closed caption service with the given initialization data is
   * formatted for displays with 16:9 aspect ratio.
   *
   * @param initializationData The initialization data to parse.
   * @return Whether the CEA-708 closed caption service is formatted for displays with 16:9 aspect
   *     ratio.
   */
  public static boolean parseCea708InitializationData(List<byte[]> initializationData) {
    return initializationData.size() == 1
        && initializationData.get(0).length == 1
        && initializationData.get(0)[0] == 1;
  }

  /**
   * Returns initialization data in CodecPrivate format of VP9.
   *
   * <p>Each feature of VP9 CodecPrivate is defined by the binary format of ID (1 byte), length (1
   * byte), and data (1 byte). See <a>
   * href="https://www.webmproject.org/docs/container/#vp9-codec-feature-metadata-codecprivate">CodecPrivate
   * format of VP9</a> for more details.
   *
   * @param profile The VP9 codec profile.
   * @param level The VP9 codec level.
   * @param bitDepth The bit depth of the luma and color components.
   * @param chromaSubsampling The chroma subsampling.
   */
  public static ImmutableList<byte[]> buildVp9CodecPrivateInitializationData(
      byte profile, byte level, byte bitDepth, byte chromaSubsampling) {
    byte profileId = 0x01;
    byte levelId = 0x02;
    byte bitDepthId = 0x03;
    byte chromaSubsamplingId = 0x04;
    byte length = 0x01;
    return ImmutableList.of(
        new byte[] {
          profileId, length, profile,
          levelId, length, level,
          bitDepthId, length, bitDepth,
          chromaSubsamplingId, length, chromaSubsampling
        });
  }

  /**
   * Builds VP9 CodecPrivate from the uncompressed header of the first frame.
   *
   * <p>This method parses the uncompressed header of the first frame to extract the VP9 profile,
   * bit depth, and chroma subsampling.
   *
   * <p>Refer to <a
   * href="https://storage.googleapis.com/downloads.webmproject.org/docs/vp9/vp9-bitstream-specification-v0.7-20170222-draft.pdf">6.2
   * of the VP9 bitstream specification</a> and <a
   * href="https://www.webmproject.org/vp9/mp4/#Semantics">VP9 in ISO Media File Format</a> for more
   * details.
   *
   * @param sample The first frame's data.
   * @return The CodecPrivate data for VP9 if parsing is successful, {@code null} otherwise.
   */
  @Nullable
  public static byte[] buildVp9CodecPrivateFromUncompressedHeader(ByteBuffer sample) {
    int headerSize = Math.min(sample.remaining(), VP9_MAX_UNCOMPRESSED_HEADER_SIZE_BYTES);
    byte[] data = new byte[headerSize];
    sample.get(data, /* offset= */ 0, headerSize);
    ParsableBitArray bits = new ParsableBitArray(data);
    // The uncompressed header should be at least 5 bytes to contain the profile, bit depth,
    // and chroma subsampling.
    checkState(sample.remaining() >= 5);

    // First 2 bits of the uncompressed header should be the frame_marker.
    if (bits.readBits(2) != VP9_FRAME_MARKER) {
      return null;
    }

    // profile_low_bit (1 bit), profile_high_bit (1 bit)
    int profileLowBit = bits.readBits(1);
    int profileHighBit = bits.readBits(1);
    int profile = (profileHighBit << 1) | profileLowBit;

    // One reserved '0' bit if profile is 3.
    if (profile == 3) {
      if (bits.bitsLeft() < 1 || bits.readBit()) {
        return null;
      }
    }

    // If show_existing_frame is set, we get no more data. Since this is
    // expected to be the first frame, we can return null, indicating a malformed stream.
    if (bits.readBit()) { // show_existing_frame
      return null;
    }

    int frameType = bits.readBits(1);
    boolean showFrame = bits.readBit();
    boolean errorResilientMode = bits.readBit();

    int bitDepth = 8;
    int chromaSubsampling = VP9_CHROMA_SUBSAMPLING_420;

    boolean isKeyFrame = frameType == VP9_FRAME_TYPE_KEY_FRAME;
    boolean canParseHeader = isKeyFrame;
    boolean colorConfigPresent = isKeyFrame;

    if (!isKeyFrame) {
      int intraOnly = 0;
      if (!showFrame) {
        intraOnly = bits.readBits(1);
      }
      if (!errorResilientMode) {
        bits.skipBits(2); // reset_frame_context
      }

      if (intraOnly != 0) {
        canParseHeader = true;
        // color_config() is only present for intra-only frames if profile > 0.
        colorConfigPresent = profile > 0;
      }
    }

    if (!canParseHeader) {
      return null;
    }

    if (bits.readBits(24) != VP9_SYNC_CODE) {
      return null;
    }

    if (colorConfigPresent) {
      Pair<Integer, Integer> results = getVp9BitdepthChromaSubSampling(bits, profile);
      if (results == null) {
        return null;
      }
      bitDepth = results.first;
      chromaSubsampling = results.second;
    } else {
      // For intra-only, profile 0 frames, color config is not present. The default
      // bitDepth (8) and chromaSubsampling (4:2:0) are used.
      bitDepth = 8;
      chromaSubsampling = VP9_CHROMA_SUBSAMPLING_420;
    }

    // Level 0 signals that the level is unknown/unspecified.
    return CodecSpecificDataUtil.buildVp9CodecPrivateInitializationData(
            (byte) profile, /* level= */ (byte) 0, (byte) bitDepth, (byte) chromaSubsampling)
        .get(0);
  }

  /**
   * Gets the bitdepth and subsampling from a VP9 uncompressed header.
   *
   * <p>Refer to <a
   * href="https://storage.googleapis.com/downloads.webmproject.org/docs/vp9/vp9-bitstream-specification-v0.7-20170222-draft.pdf">6.2
   * of the VP9 bitstream specification</a> and <a
   * href="https://www.webmproject.org/vp9/mp4/#Semantics">VP9 in ISO Media File Format</a> for more
   * details.
   *
   * @param bits The bitstream to parse.
   * @param profile The VP9 codec profile.
   * @return A {@link Pair} containing the bitdepth and subsampling, or {@code null} if parsing
   *     fails.
   */
  @Nullable
  private static Pair<Integer, Integer> getVp9BitdepthChromaSubSampling(
      ParsableBitArray bits, int profile) {
    int bitDepth;
    if (profile >= 2) {
      bitDepth = bits.readBit() ? 12 : 10;
    } else {
      bitDepth = 8;
    }
    int colorSpace = bits.readBits(3);
    int chromaSubsampling = VP9_CHROMA_SUBSAMPLING_420;

    if (colorSpace != VP9_COLOR_SPACE_RGB) {
      bits.skipBits(1); // yuv_range_flag
      if (profile == 1 || profile == 3) {
        int ssX = bits.readBits(1);
        int ssY = bits.readBits(1);
        // From bitstream chroma subsampling to MP4 equivalent chroma subsampling conversion.
        if (ssX == 1 && ssY == 1) {
          return null; // ERROR: 4:2:0 is invalid for Profiles 1 & 3
        } else if (ssX == 1 && ssY == 0) {
          chromaSubsampling = VP9_CHROMA_SUBSAMPLING_422;
        } else if (ssX == 0 && ssY == 0) {
          chromaSubsampling = VP9_CHROMA_SUBSAMPLING_444;
        } else {
          // ssX == 0 && ssY == 1 (4:4:0) is not supported in VP9 ISO MP4.
          return null;
        }
      } else {
        chromaSubsampling = VP9_CHROMA_SUBSAMPLING_420;
      }
    } else {
      chromaSubsampling = VP9_CHROMA_SUBSAMPLING_444;
    }
    return Pair.create(bitDepth, chromaSubsampling);
  }

  /**
   * Creates the Vorbis initialization data (CodecPrivate).
   *
   * <p>The format is as follows:
   *
   * <ul>
   *   <li>Byte 1: The number of packets minus one. This is 2 for Vorbis, representing the
   *       Identification, Comment, and Setup headers.
   *   <li>Bytes 2..n: The lengths of the first two packets (Identification and Comment headers),
   *       encoded using Xiph lacing. The length of the final packet (Setup header) is not
   *       explicitly stored.
   *   <li>Bytes n+1 onwards: The Vorbis identification header, Vorbis comment header and the codec
   *       setup header.
   * </ul>
   *
   * See <a href="https://www.matroska.org/technical/codec_specs.html">A_VORBIS</a> for CodecPrivate
   * format of Vorbis.
   *
   * @param format The {@link Format}.
   * @return A {@link ByteBuffer} containing the assembled Vorbis CodecPrivate data.
   */
  public static ByteBuffer getVorbisInitializationData(Format format) {
    checkArgument(
        format.initializationData.size() > 1, "csd-0 and csd-1 must be present for Vorbis.");

    byte[] identificationHeader = format.initializationData.get(0);
    byte[] setupHeader = format.initializationData.get(1);
    byte[] commentHeader =
        new byte[] {
          3, 'v', 'o', 'r', 'b', 'i', 's', 7, 0, 0, 0, 'a', 'n', 'd', 'r', 'o', 'i', 'd', 0, 0, 0,
          0, 1
        };

    int identificationHeaderSize = identificationHeader.length;
    int commentHeaderSize = commentHeader.length;
    int setupHeaderSize = setupHeader.length;

    byte[] identificationHeaderLaced = xiphLaceEnc(identificationHeaderSize);
    byte[] commentHeaderLaced = xiphLaceEnc(commentHeaderSize);

    int codecPrivateSize =
        /* headers count size */ 1
            + identificationHeaderLaced.length
            + commentHeaderLaced.length
            + identificationHeaderSize
            + commentHeaderSize
            + setupHeaderSize;

    ByteBuffer codecPrivateBuf = ByteBuffer.allocate(codecPrivateSize);

    codecPrivateBuf.put((byte) 0x02); // Number of headers - 1 (Id, Comment, Setup)

    // Encode and put Xiph laced lengths
    codecPrivateBuf.put(identificationHeaderLaced);
    codecPrivateBuf.put(commentHeaderLaced);

    codecPrivateBuf.put(identificationHeader);
    codecPrivateBuf.put(commentHeader);
    codecPrivateBuf.put(setupHeader);

    codecPrivateBuf.flip();

    return codecPrivateBuf;
  }

  /**
   * Encodes size into a byte array using Xiph lacing.
   *
   * <p>The lacing size is split into 255 values, stored as unsigned octets – for example, 500 is
   * coded 255;245 or [0xFF 0xF5]. A frame with a size multiple of 255 is coded with a 0 at the end
   * of the size – for example, 765 is coded 255;255;255;0 or [0xFF 0xFF 0xFF 0x00].
   *
   * @param size The size to encode.
   * @return A byte array containing the Xiph-laced representation of {@code size}.
   */
  private static byte[] xiphLaceEnc(int size) {
    byte[] xiphLacedSizeArray = new byte[(size / 255) + 1];

    Arrays.fill(xiphLacedSizeArray, (byte) 0xFF);

    xiphLacedSizeArray[xiphLacedSizeArray.length - 1] = (byte) (size % 255);
    return xiphLacedSizeArray;
  }

  /**
   * Returns initialization data for Dolby Vision according to <a
   * href="https://dolby.my.salesforce.com/sfc/p/#700000009YuG/a/4u000000l6FB/076wHYEmyEfz09m0V1bo85_25hlUJjaiWTbzorNmYY4">Dolby
   * Vision ISO MediaFormat (section 2.2) specification</a>.
   *
   * @param profile The Dolby Vision codec profile. This is the integer profile, not the {@link
   *     MediaCodecInfo.CodecProfileLevel} constant.
   * @param level The Dolby Vision codec level. This is the integer level, not the {@link
   *     MediaCodecInfo.CodecProfileLevel} constant.
   */
  public static byte[] buildDolbyVisionInitializationData(int profile, int level) {
    byte[] dolbyVisionCsd = new byte[24];
    byte blCompatibilityId = 0x00;
    // MD compression is not permitted for profile 7 and earlier. Only some devices
    // support it from profile 8
    byte mdCompression = 0x00;
    if (profile == 8) {
      blCompatibilityId = 0x04;
    } else if (profile == 9) {
      blCompatibilityId = 0x02;
      mdCompression = 0x01;
    }

    dolbyVisionCsd[0] = 0x01; // dv_version_major
    dolbyVisionCsd[1] = 0x00; // dv_version_minor
    dolbyVisionCsd[2] = (byte) ((profile & 0x7f) << 1); // dv_profile
    dolbyVisionCsd[2] = (byte) ((dolbyVisionCsd[2] | ((level >> 5) & 0x1)) & 0xff);
    dolbyVisionCsd[3] = (byte) ((level & 0x1f) << 3); // dv_level
    dolbyVisionCsd[3] = (byte) (dolbyVisionCsd[3] | (1 << 2)); // rpu_present_flag
    dolbyVisionCsd[3] = (byte) (dolbyVisionCsd[3] | (0 << 1)); // el_present_flag
    dolbyVisionCsd[3] = (byte) (dolbyVisionCsd[3] | 1); // bl_present_flag
    dolbyVisionCsd[4] = (byte) (blCompatibilityId << 4); // dv_bl_signal_compatibility_id
    dolbyVisionCsd[4] = (byte) (dolbyVisionCsd[4] | (mdCompression << 2)); // dv_md_compression
    return dolbyVisionCsd;
  }

  /**
   * Returns initialization data for Opus according to <a
   * href="https://tools.ietf.org/html/rfc7845#section-5.1">RFC 7845: 5.1</a>.
   *
   * @param format The {@link Format}.
   * @return A byte array containing the Opus initialization data.
   */
  public static byte[] getOpusInitializationData(Format format) {
    checkArgument(!format.initializationData.isEmpty(), "csd-0 must be present for Opus.");
    // If csd0 starts with "AOPUSHDR", it indicates a custom CSD structure of:
    // Marker (AOPUSHDR) | Length (Length of OpusIdentificationHeader) |
    // OpusIdentificationHeader("OpusHead" + data).
    //     8 bytes       |                    8 bytes                  |   Length no. of bytes
    // Reference:
    // https://cs.android.com/android/platform/superproject/main/+/main:frameworks/av/media/module/foundation/include/media/stagefright/foundation/OpusHeader.h;l=28
    int aopushdrSignatureLength = 8;
    int opusHeadSignatureLength = 8;
    byte[] csd0 = format.initializationData.get(0);
    checkArgument(csd0.length >= opusHeadSignatureLength);
    ParsableByteArray parsableCsd0 = new ParsableByteArray(csd0);
    int payloadOffset = 0;
    int payloadLength = csd0.length;
    String csd0SignatureString = parsableCsd0.readString(aopushdrSignatureLength);
    if (csd0SignatureString.equals("AOPUSHDR")) {
      // The offset of the OpusIdentificationHeader data within the "AOPUSHDR" custom CSD.
      int opusIdentificationHeaderOffset = 16;
      checkArgument(csd0.length >= opusIdentificationHeaderOffset + opusHeadSignatureLength);
      long identificationHeaderLength = parsableCsd0.readLittleEndianLong();
      checkArgument(opusIdentificationHeaderOffset + identificationHeaderLength <= csd0.length);
      payloadOffset = opusIdentificationHeaderOffset;
      payloadLength = (int) identificationHeaderLength;
    } else {
      // Otherwise, the OpusIdentificationHeader must start with "OpusHead" signature.
      checkArgument(csd0SignatureString.equals("OpusHead"));
    }
    return Arrays.copyOfRange(csd0, payloadOffset, payloadOffset + payloadLength);
  }

  /**
   * Parses an MPEG-4 Visual configuration information, as defined in ISO/IEC14496-2.
   *
   * @param videoSpecificConfig A byte array containing the MPEG-4 Visual configuration information
   *     to parse.
   * @return A pair of the video's width and height.
   */
  public static Pair<Integer, Integer> getVideoResolutionFromMpeg4VideoConfig(
      byte[] videoSpecificConfig) {
    int offset = 0;
    boolean foundVOL = false;
    ParsableByteArray scratchBytes = new ParsableByteArray(videoSpecificConfig);
    while (offset + 3 < videoSpecificConfig.length) {
      if (scratchBytes.readUnsignedInt24() != VISUAL_OBJECT_LAYER
          || (videoSpecificConfig[offset + 3] & 0xF0) != VISUAL_OBJECT_LAYER_START) {
        scratchBytes.setPosition(scratchBytes.getPosition() - 2);
        offset++;
        continue;
      }
      foundVOL = true;
      break;
    }

    checkArgument(foundVOL, "Invalid input: VOL not found.");

    ParsableBitArray scratchBits = new ParsableBitArray(videoSpecificConfig);
    // Skip the start codecs from the bitstream
    scratchBits.skipBits((offset + 4) * 8);
    scratchBits.skipBits(1); // random_accessible_vol
    scratchBits.skipBits(8); // video_object_type_indication

    if (scratchBits.readBit()) { // object_layer_identifier
      scratchBits.skipBits(4); // video_object_layer_verid
      scratchBits.skipBits(3); // video_object_layer_priority
    }

    int aspectRatioInfo = scratchBits.readBits(4);
    if (aspectRatioInfo == EXTENDED_PAR) {
      scratchBits.skipBits(8); // par_width
      scratchBits.skipBits(8); // par_height
    }

    if (scratchBits.readBit()) { // vol_control_parameters
      scratchBits.skipBits(2); // chroma_format
      scratchBits.skipBits(1); // low_delay
      if (scratchBits.readBit()) { // vbv_parameters
        scratchBits.skipBits(79);
      }
    }

    int videoObjectLayerShape = scratchBits.readBits(2);
    checkArgument(
        videoObjectLayerShape == RECTANGULAR,
        "Only supports rectangular video object layer shape.");

    checkArgument(scratchBits.readBit()); // marker_bit
    int vopTimeIncrementResolution = scratchBits.readBits(16);
    checkArgument(scratchBits.readBit()); // marker_bit

    if (scratchBits.readBit()) { // fixed_vop_rate
      checkArgument(vopTimeIncrementResolution > 0);
      vopTimeIncrementResolution--;
      int numBitsToSkip = 0;
      while (vopTimeIncrementResolution > 0) {
        numBitsToSkip++;
        vopTimeIncrementResolution >>= 1;
      }
      scratchBits.skipBits(numBitsToSkip); // fixed_vop_time_increment
    }

    checkArgument(scratchBits.readBit()); // marker_bit
    int videoObjectLayerWidth = scratchBits.readBits(13);
    checkArgument(scratchBits.readBit()); // marker_bit
    int videoObjectLayerHeight = scratchBits.readBits(13);
    checkArgument(scratchBits.readBit()); // marker_bit

    scratchBits.skipBits(1); // interlaced

    return Pair.create(videoObjectLayerWidth, videoObjectLayerHeight);
  }

  /**
   * Builds an RFC 6381 AVC codec string using the provided parameters.
   *
   * @param profileIdc The encoding profile.
   * @param constraintsFlagsAndReservedZero2Bits The constraint flags followed by the reserved zero
   *     2 bits, all contained in the least significant byte of the integer.
   * @param levelIdc The encoding level.
   * @return An RFC 6381 AVC codec string built using the provided parameters.
   */
  public static String buildAvcCodecString(
      int profileIdc, int constraintsFlagsAndReservedZero2Bits, int levelIdc) {
    return String.format(
        "avc1.%02X%02X%02X", profileIdc, constraintsFlagsAndReservedZero2Bits, levelIdc);
  }

  /** Builds an RFC 6381 HEVC codec string using the provided parameters. */
  public static String buildHevcCodecString(
      int generalProfileSpace,
      boolean generalTierFlag,
      int generalProfileIdc,
      int generalProfileCompatibilityFlags,
      int[] constraintBytes,
      int generalLevelIdc) {
    StringBuilder builder =
        new StringBuilder(
            Util.formatInvariant(
                "hvc1.%s%d.%X.%c%d",
                HEVC_GENERAL_PROFILE_SPACE_STRINGS[generalProfileSpace],
                generalProfileIdc,
                generalProfileCompatibilityFlags,
                generalTierFlag ? 'H' : 'L',
                generalLevelIdc));
    // Omit trailing zero bytes.
    int trailingZeroIndex = constraintBytes.length;
    while (trailingZeroIndex > 0 && constraintBytes[trailingZeroIndex - 1] == 0) {
      trailingZeroIndex--;
    }
    for (int i = 0; i < trailingZeroIndex; i++) {
      builder.append(String.format(".%02X", constraintBytes[i]));
    }
    return builder.toString();
  }

  /**
   * Returns an APV codec string based on the provided initialization data.
   *
   * <p>Reference: <a
   * href="https://github.com/AcademySoftwareFoundation/openapv/blob/main/readme/apv_isobmff.md#sub-parameters-for-the-mime-tyype-codecs-parameter">
   * Codecs Parameter in APV ISO Base Media File Format</a>
   *
   * @param initializationData The initialization data containing profile, level, and band
   *     information.
   * @return The generated APV codec string.
   */
  public static String buildApvCodecString(byte[] initializationData) {
    checkArgument(
        initializationData.length >= 17, "Invalid APV CSD length: %s", initializationData.length);
    checkArgument(
        initializationData[0] == 0x01,
        "Invalid APV CSD version: %s",
        initializationData[0]); // configurationVersion == 1

    int profile = UnsignedBytes.toInt(initializationData[5]);
    int level = UnsignedBytes.toInt(initializationData[6]);
    int band = UnsignedBytes.toInt(initializationData[7]);
    return Util.formatInvariant("apv1.apvf%d.apvl%d.apvb%d", profile, level, band);
  }

  /** Builds an RFC 6381 H263 codec string using profile and level. */
  public static String buildH263CodecString(int profile, int level) {
    return Util.formatInvariant("s263.%d.%d", profile, level);
  }

  /**
   * Builds a Dolby Vision codec string using profile and level.
   *
   * <p>Reference: <a>
   * href="https://professionalsupport.dolby.com/s/article/What-is-Dolby-Vision-Profile?language=en_US">
   * Dolby Vision Profile and Level (section 2.3)</a>
   */
  public static String buildDolbyVisionCodecString(int profile, int level) {
    if (profile > 9) {
      return Util.formatInvariant("dvh1.%02d.%02d", profile, level);
    } else if (profile > 8) {
      return Util.formatInvariant("dvav.%02d.%02d", profile, level);
    } else {
      return Util.formatInvariant("dvhe.%02d.%02d", profile, level);
    }
  }

  /**
   * Returns profile and level (as defined by {@link MediaCodecInfo.CodecProfileLevel})
   * corresponding to the codec description string (as defined by RFC 6381) of the given format.
   *
   * <p>Consider using {@link #getMediaCodecProfileAndLevel(Format)} instead in order to distinguish
   * between:
   *
   * <ul>
   *   <li>The {@code format} doesn't contain profile and level info, or it is malformed.
   *   <li>The {@code format} contains profile and level info, but it cannot be represented with
   *       constants from {@link MediaCodecInfo.CodecProfileLevel}.
   * </ul>
   *
   * @param format Media format with a codec description string, as defined by RFC 6381.
   * @return A pair (profile constant, level constant) if the codec of the {@code format} is
   *     well-formed and recognized, or null otherwise.
   */
  // TODO: b/492523731 - Consider moving this and related methods back to MediaCodecUtil.
  @Nullable
  public static Pair<Integer, Integer> getCodecProfileAndLevel(Format format) {
    MediaCodecProfileAndLevel mediaCodecProfileAndLevel = getMediaCodecProfileAndLevel(format);
    if (mediaCodecProfileAndLevel != null
        && mediaCodecProfileAndLevel.isSupportableByMediaCodec()) {
      return new Pair<>(
          mediaCodecProfileAndLevel.getProfile(), mediaCodecProfileAndLevel.getLevel());
    } else {
      return null;
    }
  }

  /**
   * Returns the profile and level corresponding to the codec description string (as defined by RFC
   * 6381) of the given format.
   *
   * @param format Media format with a codec description string, as defined by RFC 6381.
   * @return {@link MediaCodecProfileAndLevel} if the codec of the {@code format} is well-formed, or
   *     null otherwise.
   */
  @Nullable
  public static MediaCodecProfileAndLevel getMediaCodecProfileAndLevel(Format format) {
    if (format.codecs == null) {
      return null;
    }
    String[] parts = format.codecs.split("\\.");
    // Dolby Vision can use DV, AVC or HEVC codec IDs, so check the MIME type first.
    if (MimeTypes.VIDEO_DOLBY_VISION.equals(format.sampleMimeType)) {
      return getDolbyVisionProfileAndLevel(format.codecs, parts);
    }
    switch (parts[0]) {
      case CODEC_ID_H263:
        return getH263ProfileAndLevel(format.codecs, parts);
      case CODEC_ID_AVC1:
      case CODEC_ID_AVC2:
        return getAvcProfileAndLevel(format.codecs, parts);
      case CODEC_ID_VP09:
        return getVp9ProfileAndLevel(format.codecs, parts);
      case CODEC_ID_HEV1:
      case CODEC_ID_HVC1:
        return getHevcProfileAndLevel(format.codecs, parts, format.colorInfo);
      case CODEC_ID_VVC1:
      case CODEC_ID_VVI1:
        return getVvcProfileAndLevel(format.codecs, parts, format.colorInfo);
      case CODEC_ID_AV01:
        return getAv1ProfileAndLevel(format.codecs, parts, format.colorInfo);
      case CODEC_ID_APV1:
        return getApvProfileAndLevel(format.codecs, parts);
      case CODEC_ID_MP4A:
        return getAacCodecProfileAndLevel(format.codecs, parts);
      case CODEC_ID_AC4:
        return getAc4CodecProfileAndLevel(format.codecs, parts);
      case CODEC_ID_IAMF:
        return getIamfCodecProfileAndLevel(format.codecs, parts);
      default:
        return null;
    }
  }

  /**
   * Returns VVC profile and level corresponding to the codec description string (as defined by
   * ISO/IEC 14496-15:2021, Annex E.3) and its {@link ColorInfo}.
   *
   * @param codec The codec description string.
   * @param parts The codec string split by ".".
   * @param colorInfo The {@link ColorInfo}.
   * @return A pair (profile constant, level constant) if profile and level are recognized, or
   *     {@code null} otherwise.
   */
  @Nullable
  private static MediaCodecProfileAndLevel getVvcProfileAndLevel(
      String codec, String[] parts, @Nullable ColorInfo colorInfo) {
    if (parts.length < 3) {
      Log.w(TAG, "Ignoring malformed VVC codec string: " + codec);
      return null;
    }

    int profileIdc;
    try {
      profileIdc = Integer.parseInt(parts[1]);
    } catch (NumberFormatException e) {
      Log.w(TAG, "Ignoring malformed VVC codec string: " + codec);
      return null;
    }

    int profile;
    if (profileIdc == 1) {
      if (colorInfo != null && colorInfo.colorTransfer == C.COLOR_TRANSFER_ST2084) {
        profile = VVC_PROFILE_MAIN_10_HDR10;
      } else if (colorInfo != null && colorInfo.lumaBitdepth == 8) {
        profile = VVC_PROFILE_MAIN_8;
      } else {
        profile = VVC_PROFILE_MAIN_10;
      }
    } else if (profileIdc == 65) {
      profile = VVC_PROFILE_MAIN_10_STILL;
    } else {
      Log.w(TAG, "Unknown VVC profile IDC: " + parts[1]);
      return MediaCodecProfileAndLevel.UNSUPPORTABLE;
    }

    String levelString = parts[2];
    @Nullable Integer level = vvcCodecStringToProfileLevel(levelString);
    if (level == null) {
      Log.w(TAG, "Unknown VVC level string: " + levelString);
      return MediaCodecProfileAndLevel.UNSUPPORTABLE;
    }
    return new MediaCodecProfileAndLevel(profile, level);
  }

  /**
   * Returns the VVC level constant corresponding to the tier and level string (as defined by
   * ISO/IEC 14496-15:2021, Annex E.3).
   *
   * <p>The string consists of a tier indicator ('L' for Main, 'H' for High) followed by the
   * general_level_idc.
   *
   * @param codecString The VVC tier and level string (e.g., "L16" or "H64").
   * @return The VVC level constant, or {@code null} if the level is not recognized.
   * @see <a href="https://www.itu.int/rec/T-REC-H.266">ITU-T Rec. H.266, Annex A</a>
   */
  @Nullable
  private static Integer vvcCodecStringToProfileLevel(String codecString) {
    switch (codecString) {
      case "L16":
        return VVC_MAIN_TIER_LEVEL_1_0;
      case "L32":
        return VVC_MAIN_TIER_LEVEL_2_0;
      case "L35":
        return VVC_MAIN_TIER_LEVEL_2_1;
      case "L48":
        return VVC_MAIN_TIER_LEVEL_3_0;
      case "L51":
        return VVC_MAIN_TIER_LEVEL_3_1;
      case "L64":
        return VVC_MAIN_TIER_LEVEL_4_0;
      case "H64":
        return VVC_HIGH_TIER_LEVEL_4_0;
      case "L67":
        return VVC_MAIN_TIER_LEVEL_4_1;
      case "H67":
        return VVC_HIGH_TIER_LEVEL_4_1;
      case "L80":
        return VVC_MAIN_TIER_LEVEL_5_0;
      case "H80":
        return VVC_HIGH_TIER_LEVEL_5_0;
      case "L83":
        return VVC_MAIN_TIER_LEVEL_5_1;
      case "H83":
        return VVC_HIGH_TIER_LEVEL_5_1;
      case "L86":
        return VVC_MAIN_TIER_LEVEL_5_2;
      case "H86":
        return VVC_HIGH_TIER_LEVEL_5_2;
      case "L96":
        return VVC_MAIN_TIER_LEVEL_6_0;
      case "H96":
        return VVC_HIGH_TIER_LEVEL_6_0;
      case "L112":
        return VVC_MAIN_TIER_LEVEL_6_1;
      case "H112":
        return VVC_HIGH_TIER_LEVEL_6_1;
      case "L128":
        return VVC_MAIN_TIER_LEVEL_6_2;
      case "H128":
        return VVC_HIGH_TIER_LEVEL_6_2;
      case "L144":
        return VVC_MAIN_TIER_LEVEL_6_3;
      case "H144":
        return VVC_HIGH_TIER_LEVEL_6_3;
      default:
        return null;
    }
  }

  /**
   * Returns Hevc profile and level corresponding to the codec description string (as defined by RFC
   * 6381) and it {@link ColorInfo}.
   *
   * @param codec The codec description string (as defined by RFC 6381).
   * @param parts The codec string split by ".".
   * @param colorInfo The {@link ColorInfo}.
   * @return A pair (profile constant, level constant) if profile and level are recognized, or
   *     {@code null} otherwise.
   */
  @Nullable
  public static MediaCodecProfileAndLevel getHevcProfileAndLevel(
      String codec, String[] parts, @Nullable ColorInfo colorInfo) {
    if (parts.length < 4) {
      // The codec has fewer parts than required by the HEVC codec string format.
      Log.w(TAG, "Ignoring malformed HEVC codec string: " + codec);
      return null;
    }
    // The profile_space gets ignored.
    Matcher matcher = PROFILE_PATTERN.matcher(parts[1]);
    if (!matcher.matches()) {
      Log.w(TAG, "Ignoring malformed HEVC codec string: " + codec);
      return null;
    }
    @Nullable String profileString = matcher.group(1);
    int profile;
    if ("1".equals(profileString)) {
      profile = MediaCodecInfo.CodecProfileLevel.HEVCProfileMain;
    } else if ("2".equals(profileString)) {
      if (colorInfo != null && colorInfo.colorTransfer == C.COLOR_TRANSFER_ST2084) {
        profile = MediaCodecInfo.CodecProfileLevel.HEVCProfileMain10HDR10;
      } else {
        // For all other cases, we map to the Main10 profile. Note that this includes HLG
        // HDR. On Android 13+, the platform guarantees that a decoder that advertises
        // HEVCProfileMain10 will be able to decode HLG. This is not guaranteed for older
        // Android versions, but we still map to Main10 for backwards compatibility.
        profile = MediaCodecInfo.CodecProfileLevel.HEVCProfileMain10;
      }
    } else {
      Log.w(TAG, "Unknown HEVC profile string: " + profileString);
      return MediaCodecProfileAndLevel.UNSUPPORTABLE;
    }
    @Nullable String levelString = parts[3];
    @Nullable Integer level = hevcCodecStringToProfileLevel(levelString);
    if (level == null) {
      Log.w(TAG, "Unknown HEVC level string: " + levelString);
      return MediaCodecProfileAndLevel.UNSUPPORTABLE;
    }
    return new MediaCodecProfileAndLevel(profile, level);
  }

  /**
   * Constructs a NAL unit consisting of the NAL start code followed by the specified data.
   *
   * @param data An array containing the data that should follow the NAL start code.
   * @param offset The start offset into {@code data}.
   * @param length The number of bytes to copy from {@code data}
   * @return The constructed NAL unit.
   */
  public static byte[] buildNalUnit(byte[] data, int offset, int length) {
    byte[] nalUnit = new byte[length + NAL_START_CODE.length];
    System.arraycopy(NAL_START_CODE, 0, nalUnit, 0, NAL_START_CODE.length);
    System.arraycopy(data, offset, nalUnit, NAL_START_CODE.length, length);
    return nalUnit;
  }

  /**
   * Splits an array of NAL units.
   *
   * <p>If the input consists of NAL start code delimited units, then the returned array consists of
   * the split NAL units, each of which is still prefixed with the NAL start code. For any other
   * input, null is returned.
   *
   * @param data An array of data.
   * @return The individual NAL units, or null if the input did not consist of NAL start code
   *     delimited units.
   */
  @Nullable
  public static byte[][] splitNalUnits(byte[] data) {
    if (!isNalStartCode(data, 0)) {
      // data does not consist of NAL start code delimited units.
      return null;
    }
    List<Integer> starts = new ArrayList<>();
    int nalUnitIndex = 0;
    do {
      starts.add(nalUnitIndex);
      nalUnitIndex = findNalStartCode(data, nalUnitIndex + NAL_START_CODE.length);
    } while (nalUnitIndex != C.INDEX_UNSET);
    byte[][] split = new byte[starts.size()][];
    for (int i = 0; i < starts.size(); i++) {
      int startIndex = starts.get(i);
      int endIndex = i < starts.size() - 1 ? starts.get(i + 1) : data.length;
      byte[] nal = new byte[endIndex - startIndex];
      System.arraycopy(data, startIndex, nal, 0, nal.length);
      split[i] = nal;
    }
    return split;
  }

  /**
   * Returns Dolby Vision level number corresponding to the level constant.
   *
   * @param levelConstant The Dolby Vision level constant.
   * @return The Dolby Vision level number.
   * @throws IllegalArgumentException if the level constant is not recognized.
   */
  public static int dolbyVisionConstantToLevelNumber(int levelConstant) {
    switch (levelConstant) {
      case MediaCodecInfo.CodecProfileLevel.DolbyVisionLevelHd24:
        return 1;
      case MediaCodecInfo.CodecProfileLevel.DolbyVisionLevelHd30:
        return 2;
      case MediaCodecInfo.CodecProfileLevel.DolbyVisionLevelFhd24:
        return 3;
      case MediaCodecInfo.CodecProfileLevel.DolbyVisionLevelFhd30:
        return 4;
      case MediaCodecInfo.CodecProfileLevel.DolbyVisionLevelFhd60:
        return 5;
      case MediaCodecInfo.CodecProfileLevel.DolbyVisionLevelUhd24:
        return 6;
      case MediaCodecInfo.CodecProfileLevel.DolbyVisionLevelUhd30:
        return 7;
      case MediaCodecInfo.CodecProfileLevel.DolbyVisionLevelUhd48:
        return 8;
      case MediaCodecInfo.CodecProfileLevel.DolbyVisionLevelUhd60:
        return 9;
      case MediaCodecInfo.CodecProfileLevel.DolbyVisionLevelUhd120:
        return 10;
      case MediaCodecInfo.CodecProfileLevel.DolbyVisionLevel8k30:
        return 11;
      case MediaCodecInfo.CodecProfileLevel.DolbyVisionLevel8k60:
        return 12;
      // TODO: b/179261323 - use framework constant for level 13.
      case 0x1000:
        return 13;
      default:
        throw new IllegalArgumentException("Unknown Dolby Vision level: " + levelConstant);
    }
  }

  /**
   * Returns Dolby Vision profile number corresponding to the profile constant.
   *
   * @param profileConstant The Dolby Vision profile constant.
   * @return The Dolby Vision profile number.
   * @throws IllegalArgumentException if the profile constant is not recognized.
   */
  public static int dolbyVisionConstantToProfileNumber(int profileConstant) {
    switch (profileConstant) {
      case MediaCodecInfo.CodecProfileLevel.DolbyVisionProfileDvavPer:
        return 0;
      case MediaCodecInfo.CodecProfileLevel.DolbyVisionProfileDvavPen:
        return 1;
      case MediaCodecInfo.CodecProfileLevel.DolbyVisionProfileDvheDer:
        return 2;
      case MediaCodecInfo.CodecProfileLevel.DolbyVisionProfileDvheDen:
        return 3;
      case MediaCodecInfo.CodecProfileLevel.DolbyVisionProfileDvheDtr:
        return 4;
      case MediaCodecInfo.CodecProfileLevel.DolbyVisionProfileDvheStn:
        return 5;
      case MediaCodecInfo.CodecProfileLevel.DolbyVisionProfileDvheDth:
        return 6;
      case MediaCodecInfo.CodecProfileLevel.DolbyVisionProfileDvheDtb:
        return 7;
      case MediaCodecInfo.CodecProfileLevel.DolbyVisionProfileDvheSt:
        return 8;
      case MediaCodecInfo.CodecProfileLevel.DolbyVisionProfileDvavSe:
        return 9;
      case MediaCodecInfo.CodecProfileLevel.DolbyVisionProfileDvav110:
        return 10;
      default:
        throw new IllegalArgumentException("Unknown Dolby Vision profile: " + profileConstant);
    }
  }

  /**
   * Calculates the Dolby Vision level based on resolution and frame rate.
   *
   * <p>Refer to <a
   * href="https://professionalsupport.dolby.com/s/article/What-is-Dolby-Vision-Profile">Dolby
   * Vision profiles and levels</a> for more details.
   *
   * @param width The video width in pixels.
   * @param height The video height in pixels.
   * @param frameRate The video frame rate in frames per second.
   * @return The Android MediaCodec constants for the Dolby Vision level, or -1 if it could not be
   *     determined.
   */
  public static int calculateMediaCodecDolbyVisionLevel(int width, int height, float frameRate) {
    int maxWidthHeight = max(width, height);
    checkState(maxWidthHeight <= 7680);
    float pixelRate = width * height * frameRate;

    int level = -1;
    if (maxWidthHeight <= 1_280) {
      if (pixelRate <= 22_118_400) {
        level = MediaCodecInfo.CodecProfileLevel.DolbyVisionLevelHd24; // Level 01
      } else { // pixelRate <= 27_648_000
        level = MediaCodecInfo.CodecProfileLevel.DolbyVisionLevelHd30; // Level 02
      }
    } else if (maxWidthHeight <= 1_920 && pixelRate <= 49_766_400) {
      level = MediaCodecInfo.CodecProfileLevel.DolbyVisionLevelFhd24; // Level 03
    } else if (maxWidthHeight <= 2_560 && pixelRate <= 62_208_000) {
      level = MediaCodecInfo.CodecProfileLevel.DolbyVisionLevelFhd30; // Level 04
    } else if (maxWidthHeight <= 3_840) {
      if (pixelRate <= 124_416_000) {
        level = MediaCodecInfo.CodecProfileLevel.DolbyVisionLevelFhd60; // Level 05
      } else if (pixelRate <= 199_065_600) {
        level = MediaCodecInfo.CodecProfileLevel.DolbyVisionLevelUhd24; // Level 06
      } else if (pixelRate <= 248_832_000) {
        level = MediaCodecInfo.CodecProfileLevel.DolbyVisionLevelUhd30; // Level 07
      } else if (pixelRate <= 398_131_200) {
        level = MediaCodecInfo.CodecProfileLevel.DolbyVisionLevelUhd48; // Level 08
      } else if (pixelRate <= 497_664_000) {
        level = MediaCodecInfo.CodecProfileLevel.DolbyVisionLevelUhd60; // Level 09
      } else { // pixelRate <= 995_328_000
        level = MediaCodecInfo.CodecProfileLevel.DolbyVisionLevelUhd120; // Level 10
      }
    } else if (maxWidthHeight <= 7_680) {
      if (pixelRate <= 995_328_000) {
        level = MediaCodecInfo.CodecProfileLevel.DolbyVisionLevel8k30; // Level 11
      } else { // pixelRate <= 1_990_656_000
        level = MediaCodecInfo.CodecProfileLevel.DolbyVisionLevel8k60; // Level 12
      }
    }

    return level;
  }

  /**
   * Finds the next occurrence of the NAL start code from a given index.
   *
   * @param data The data in which to search.
   * @param index The first index to test.
   * @return The index of the first byte of the found start code, or {@link C#INDEX_UNSET}.
   */
  private static int findNalStartCode(byte[] data, int index) {
    int endIndex = data.length - NAL_START_CODE.length;
    for (int i = index; i <= endIndex; i++) {
      if (isNalStartCode(data, i)) {
        return i;
      }
    }
    return C.INDEX_UNSET;
  }

  /**
   * Tests whether there exists a NAL start code at a given index.
   *
   * @param data The data.
   * @param index The index to test.
   * @return Whether there exists a start code that begins at {@code index}.
   */
  private static boolean isNalStartCode(byte[] data, int index) {
    if (data.length - index <= NAL_START_CODE.length) {
      return false;
    }
    for (int j = 0; j < NAL_START_CODE.length; j++) {
      if (data[index + j] != NAL_START_CODE[j]) {
        return false;
      }
    }
    return true;
  }

  @Nullable
  private static MediaCodecProfileAndLevel getDolbyVisionProfileAndLevel(
      String codec, String[] parts) {
    if (parts.length < 3) {
      // The codec has fewer parts than required by the Dolby Vision codec string format.
      Log.w(TAG, "Ignoring malformed Dolby Vision codec string: " + codec);
      return null;
    }
    // The profile_space gets ignored.
    Matcher matcher = PROFILE_PATTERN.matcher(parts[1]);
    if (!matcher.matches()) {
      Log.w(TAG, "Ignoring malformed Dolby Vision codec string: " + codec);
      return null;
    }
    String profileString = checkNotNull(matcher.group(1));
    @Nullable Integer profile = dolbyVisionStringToProfile(profileString);
    if (profile == null) {
      Log.w(TAG, "Unknown Dolby Vision profile string: " + profileString);
      return MediaCodecProfileAndLevel.UNSUPPORTABLE;
    }
    String levelString = parts[2];
    @Nullable Integer level = dolbyVisionStringToLevel(levelString);
    if (level == null) {
      Log.w(TAG, "Unknown Dolby Vision level string: " + levelString);
      return null;
    }
    return new MediaCodecProfileAndLevel(profile, level);
  }

  /**
   * Returns a Dolby Vision base layer codec MIME type of the provided {@link Format}.
   *
   * @param format The media format.
   * @return A Dolby Vision base layer MIME type, or {@code null} if a Dolby Vision profile is not
   *     identified.
   */
  @Nullable
  public static String getDolbyVisionBaseLayerMimeType(Format format) {
    if (!Objects.equals(format.sampleMimeType, MimeTypes.VIDEO_DOLBY_VISION)) {
      return null;
    }
    @Nullable Pair<Integer, Integer> codecProfileAndLevel = getCodecProfileAndLevel(format);
    if (codecProfileAndLevel == null) {
      return null;
    }
    switch (codecProfileAndLevel.first) {
      case CodecProfileLevel.DolbyVisionProfileDvheDtr: // profile 4
      case CodecProfileLevel.DolbyVisionProfileDvheStn: // profile 5
      case CodecProfileLevel.DolbyVisionProfileDvheSt: // profile 8
        return MimeTypes.VIDEO_H265;
      case CodecProfileLevel.DolbyVisionProfileDvavSe: // profile 9
        return MimeTypes.VIDEO_H264;
      case CodecProfileLevel.DolbyVisionProfileDvav110: // profile 10
        return MimeTypes.VIDEO_AV1;
      default:
        return null;
    }
  }

  /** Returns H263 profile and level from codec string. */
  @Nullable
  private static MediaCodecProfileAndLevel getH263ProfileAndLevel(String codec, String[] parts) {
    if (parts.length < 3) {
      Log.w(TAG, "Ignoring malformed H263 codec string: " + codec);
      return null;
    }

    int profileInteger;
    int levelInteger;
    try {
      profileInteger = Integer.parseInt(parts[1]);
      levelInteger = Integer.parseInt(parts[2]);
    } catch (NumberFormatException e) {
      Log.w(TAG, "Ignoring malformed H263 codec string: " + codec);
      return null;
    }
    int profile = h263ProfileNumberToConst(profileInteger);
    if (profile == -1) {
      Log.w(TAG, "Unknown H263 profile: " + profileInteger);
      return MediaCodecProfileAndLevel.UNSUPPORTABLE;
    }
    int level = h263LevelNumberToConst(levelInteger);
    if (level == -1) {
      Log.w(TAG, "Unknown H263 level: " + levelInteger);
      return MediaCodecProfileAndLevel.UNSUPPORTABLE;
    }
    return new MediaCodecProfileAndLevel(profile, level);
  }

  @Nullable
  private static MediaCodecProfileAndLevel getAvcProfileAndLevel(String codec, String[] parts) {
    if (parts.length < 2) {
      // The codec has fewer parts than required by the AVC codec string format.
      Log.w(TAG, "Ignoring malformed AVC codec string: " + codec);
      return null;
    }
    int profileInteger;
    int levelInteger;
    try {
      if (parts[1].length() == 6) {
        // Format: avc1.xxccyy, where xx is profile and yy level, both hexadecimal.
        profileInteger = Integer.parseInt(parts[1].substring(0, 2), 16);
        levelInteger = Integer.parseInt(parts[1].substring(4), 16);
      } else if (parts.length >= 3) {
        // Format: avc1.xx.[y]yy where xx is profile and [y]yy level, both decimal.
        profileInteger = Integer.parseInt(parts[1]);
        levelInteger = Integer.parseInt(parts[2]);
      } else {
        // We don't recognize the format.
        Log.w(TAG, "Ignoring malformed AVC codec string: " + codec);
        return null;
      }
    } catch (NumberFormatException e) {
      Log.w(TAG, "Ignoring malformed AVC codec string: " + codec);
      return null;
    }

    int profile = avcProfileNumberToConst(profileInteger);
    if (profile == -1) {
      Log.w(TAG, "Unknown AVC profile: " + profileInteger);
      return MediaCodecProfileAndLevel.UNSUPPORTABLE;
    }
    int level = avcLevelNumberToConst(levelInteger);
    if (level == -1) {
      Log.w(TAG, "Unknown AVC level: " + levelInteger);
      return MediaCodecProfileAndLevel.UNSUPPORTABLE;
    }
    return new MediaCodecProfileAndLevel(profile, level);
  }

  @Nullable
  private static MediaCodecProfileAndLevel getVp9ProfileAndLevel(String codec, String[] parts) {
    if (parts.length < 3) {
      Log.w(TAG, "Ignoring malformed VP9 codec string: " + codec);
      return null;
    }
    int profileInteger;
    int levelInteger;
    try {
      profileInteger = Integer.parseInt(parts[1]);
      levelInteger = Integer.parseInt(parts[2]);
    } catch (NumberFormatException e) {
      Log.w(TAG, "Ignoring malformed VP9 codec string: " + codec);
      return null;
    }

    int profile = vp9ProfileNumberToConst(profileInteger);
    if (profile == -1) {
      Log.w(TAG, "Unknown VP9 profile: " + profileInteger);
      return MediaCodecProfileAndLevel.UNSUPPORTABLE;
    }
    int level = vp9LevelNumberToConst(levelInteger);
    if (level == -1) {
      Log.w(TAG, "Unknown VP9 level: " + levelInteger);
      return MediaCodecProfileAndLevel.UNSUPPORTABLE;
    }
    return new MediaCodecProfileAndLevel(profile, level);
  }

  @Nullable
  private static MediaCodecProfileAndLevel getAv1ProfileAndLevel(
      String codec, String[] parts, @Nullable ColorInfo colorInfo) {
    if (parts.length < 4) {
      Log.w(TAG, "Ignoring malformed AV1 codec string: " + codec);
      return null;
    }
    int profileInteger;
    int levelInteger;
    int bitDepthInteger;
    try {
      profileInteger = Integer.parseInt(parts[1]);
      levelInteger = Integer.parseInt(parts[2].substring(0, 2));
      bitDepthInteger = Integer.parseInt(parts[3]);
    } catch (NumberFormatException e) {
      Log.w(TAG, "Ignoring malformed AV1 codec string: " + codec);
      return null;
    }

    if (profileInteger != 0) {
      Log.w(TAG, "Unknown AV1 profile: " + profileInteger);
      return MediaCodecProfileAndLevel.UNSUPPORTABLE;
    }
    if (bitDepthInteger != 8 && bitDepthInteger != 10) {
      Log.w(TAG, "Unknown AV1 bit depth: " + bitDepthInteger);
      return MediaCodecProfileAndLevel.UNSUPPORTABLE;
    }
    int profile;
    if (bitDepthInteger == 8) {
      profile = MediaCodecInfo.CodecProfileLevel.AV1ProfileMain8;
    } else if (colorInfo != null
        && (colorInfo.hdrStaticInfo != null
            || colorInfo.colorTransfer == C.COLOR_TRANSFER_HLG
            || colorInfo.colorTransfer == C.COLOR_TRANSFER_ST2084)) {
      profile = MediaCodecInfo.CodecProfileLevel.AV1ProfileMain10HDR10;
    } else {
      profile = MediaCodecInfo.CodecProfileLevel.AV1ProfileMain10;
    }

    int level = av1LevelNumberToConst(levelInteger);
    if (level == -1) {
      Log.w(TAG, "Unknown AV1 level: " + levelInteger);
      return MediaCodecProfileAndLevel.UNSUPPORTABLE;
    }
    return new MediaCodecProfileAndLevel(profile, level);
  }

  @Nullable
  private static MediaCodecProfileAndLevel getApvProfileAndLevel(String codec, String[] parts) {
    if (parts.length < 4) {
      Log.w(TAG, "Ignoring malformed APV codec string: " + codec);
      return null;
    }
    int profileInteger;
    int levelInteger;
    int bandInteger;
    try {
      profileInteger = Integer.parseInt(parts[1].substring(4));
      levelInteger = Integer.parseInt(parts[2].substring(4));
      bandInteger = Integer.parseInt(parts[3].substring(4));
    } catch (NumberFormatException e) {
      Log.w(TAG, "Ignoring malformed APV codec string: " + codec, e);
      return null;
    }

    int profile;
    if (profileInteger == 33) {
      profile = MediaCodecInfo.CodecProfileLevel.APVProfile422_10;
    } else if (profileInteger == 44) {
      profile = MediaCodecInfo.CodecProfileLevel.APVProfile422_10HDR10Plus;
    } else {
      Log.w(TAG, "Unrecognized APV profile: " + profileInteger);
      return MediaCodecProfileAndLevel.UNSUPPORTABLE;
    }
    int level = apvLevelAndBandNumberToConst(levelInteger, bandInteger);
    if (level == -1) {
      return MediaCodecProfileAndLevel.UNSUPPORTABLE;
    }
    return new MediaCodecProfileAndLevel(profile, level);
  }

  private static int apvLevelAndBandNumberToConst(int levelNumber, int bandNumber) {
    // levelInteger is 30x larger than the decimal level value, as defined by
    // https://www.ietf.org/archive/id/draft-lim-apv-02.html#_table-levels
    switch (levelNumber) {
      case 30:
        switch (bandNumber) {
          case 0:
            return CodecProfileLevel.APVLevel1Band0;
          case 1:
            return CodecProfileLevel.APVLevel1Band1;
          case 2:
            return CodecProfileLevel.APVLevel1Band2;
          case 3:
            return CodecProfileLevel.APVLevel1Band3;
          default:
            Log.w(TAG, "Unrecognized APV band: " + bandNumber);
            return -1;
        }
      case 33:
        switch (bandNumber) {
          case 0:
            return CodecProfileLevel.APVLevel11Band0;
          case 1:
            return CodecProfileLevel.APVLevel11Band1;
          case 2:
            return CodecProfileLevel.APVLevel11Band2;
          case 3:
            return CodecProfileLevel.APVLevel11Band3;
          default:
            Log.w(TAG, "Unrecognized APV band: " + bandNumber);
            return -1;
        }
      case 60:
        switch (bandNumber) {
          case 0:
            return CodecProfileLevel.APVLevel2Band0;
          case 1:
            return CodecProfileLevel.APVLevel2Band1;
          case 2:
            return CodecProfileLevel.APVLevel2Band2;
          case 3:
            return CodecProfileLevel.APVLevel2Band3;
          default:
            Log.w(TAG, "Unrecognized APV band: " + bandNumber);
            return -1;
        }
      case 63:
        switch (bandNumber) {
          case 0:
            return CodecProfileLevel.APVLevel21Band0;
          case 1:
            return CodecProfileLevel.APVLevel21Band1;
          case 2:
            return CodecProfileLevel.APVLevel21Band2;
          case 3:
            return CodecProfileLevel.APVLevel21Band3;
          default:
            Log.w(TAG, "Unrecognized APV band: " + bandNumber);
            return -1;
        }
      case 90:
        switch (bandNumber) {
          case 0:
            return CodecProfileLevel.APVLevel3Band0;
          case 1:
            return CodecProfileLevel.APVLevel3Band1;
          case 2:
            return CodecProfileLevel.APVLevel3Band2;
          case 3:
            return CodecProfileLevel.APVLevel3Band3;
          default:
            Log.w(TAG, "Unrecognized APV band: " + bandNumber);
            return -1;
        }
      case 93:
        switch (bandNumber) {
          case 0:
            return CodecProfileLevel.APVLevel31Band0;
          case 1:
            return CodecProfileLevel.APVLevel31Band1;
          case 2:
            return CodecProfileLevel.APVLevel31Band2;
          case 3:
            return CodecProfileLevel.APVLevel31Band3;
          default:
            Log.w(TAG, "Unrecognized APV band: " + bandNumber);
            return -1;
        }
      case 120:
        switch (bandNumber) {
          case 0:
            return CodecProfileLevel.APVLevel4Band0;
          case 1:
            return CodecProfileLevel.APVLevel4Band1;
          case 2:
            return CodecProfileLevel.APVLevel4Band2;
          case 3:
            return CodecProfileLevel.APVLevel4Band3;
          default:
            Log.w(TAG, "Unrecognized APV band: " + bandNumber);
            return -1;
        }
      case 123:
        switch (bandNumber) {
          case 0:
            return CodecProfileLevel.APVLevel41Band0;
          case 1:
            return CodecProfileLevel.APVLevel41Band1;
          case 2:
            return CodecProfileLevel.APVLevel41Band2;
          case 3:
            return CodecProfileLevel.APVLevel41Band3;
          default:
            Log.w(TAG, "Unrecognized APV band: " + bandNumber);
            return -1;
        }
      case 150:
        switch (bandNumber) {
          case 0:
            return CodecProfileLevel.APVLevel5Band0;
          case 1:
            return CodecProfileLevel.APVLevel5Band1;
          case 2:
            return CodecProfileLevel.APVLevel5Band2;
          case 3:
            return CodecProfileLevel.APVLevel5Band3;
          default:
            Log.w(TAG, "Unrecognized APV band: " + bandNumber);
            return -1;
        }
      case 153:
        switch (bandNumber) {
          case 0:
            return CodecProfileLevel.APVLevel51Band0;
          case 1:
            return CodecProfileLevel.APVLevel51Band1;
          case 2:
            return CodecProfileLevel.APVLevel51Band2;
          case 3:
            return CodecProfileLevel.APVLevel51Band3;
          default:
            Log.w(TAG, "Unrecognized APV band: " + bandNumber);
            return -1;
        }
      case 180:
        switch (bandNumber) {
          case 0:
            return CodecProfileLevel.APVLevel6Band0;
          case 1:
            return CodecProfileLevel.APVLevel6Band1;
          case 2:
            return CodecProfileLevel.APVLevel6Band2;
          case 3:
            return CodecProfileLevel.APVLevel6Band3;
          default:
            Log.w(TAG, "Unrecognized APV band: " + bandNumber);
            return -1;
        }
      case 183:
        switch (bandNumber) {
          case 0:
            return CodecProfileLevel.APVLevel61Band0;
          case 1:
            return CodecProfileLevel.APVLevel61Band1;
          case 2:
            return CodecProfileLevel.APVLevel61Band2;
          case 3:
            return CodecProfileLevel.APVLevel61Band3;
          default:
            Log.w(TAG, "Unrecognized APV band: " + bandNumber);
            return -1;
        }
      case 210:
        switch (bandNumber) {
          case 0:
            return CodecProfileLevel.APVLevel7Band0;
          case 1:
            return CodecProfileLevel.APVLevel7Band1;
          case 2:
            return CodecProfileLevel.APVLevel7Band2;
          case 3:
            return CodecProfileLevel.APVLevel7Band3;
          default:
            Log.w(TAG, "Unrecognized APV band: " + bandNumber);
            return -1;
        }
      case 213:
        switch (bandNumber) {
          case 0:
            return CodecProfileLevel.APVLevel71Band0;
          case 1:
            return CodecProfileLevel.APVLevel71Band1;
          case 2:
            return CodecProfileLevel.APVLevel71Band2;
          case 3:
            return CodecProfileLevel.APVLevel71Band3;
          default:
            Log.w(TAG, "Unrecognized APV band: " + bandNumber);
            return -1;
        }
      default:
        Log.w(TAG, "Unrecognized APV level index: " + levelNumber);
        return -1;
    }
  }

  @Nullable
  private static MediaCodecProfileAndLevel getAacCodecProfileAndLevel(
      String codec, String[] parts) {
    if (parts.length != 3) {
      Log.w(TAG, "Ignoring malformed MP4A codec string: " + codec);
      return null;
    }
    try {
      // Get the object type indication, which is a hexadecimal value (see RFC 6381/ISO 14496-1).
      int objectTypeIndication = Integer.parseInt(parts[1], 16);
      @Nullable String mimeType = MimeTypes.getMimeTypeFromMp4ObjectType(objectTypeIndication);
      if (MimeTypes.AUDIO_AAC.equals(mimeType)) {
        // For MPEG-4 audio this is followed by an audio object type indication as a decimal number.
        int audioObjectTypeIndication = Integer.parseInt(parts[2]);
        int profile = mp4aAudioObjectTypeToProfile(audioObjectTypeIndication);
        if (profile == -1) {
          Log.w(TAG, "Unrecognized MP4A profile: " + profile);
          return MediaCodecProfileAndLevel.UNSUPPORTABLE;
        }
        // Level is set to zero in AAC decoder CodecProfileLevels.
        return new MediaCodecProfileAndLevel(profile, 0);
      }
    } catch (NumberFormatException e) {
      Log.w(TAG, "Ignoring malformed MP4A codec string: " + codec);
    }
    return null;
  }

  @Nullable
  private static MediaCodecProfileAndLevel getAc4CodecProfileAndLevel(
      String codec, String[] parts) {
    if (parts.length != 4) {
      Log.w(TAG, "Ignoring malformed AC-4 codec string: " + codec);
      return null;
    }
    int bitstreamVersionInteger;
    int presentationVersionInteger;
    int levelInteger;
    try {
      bitstreamVersionInteger = Integer.parseInt(parts[1]);
      presentationVersionInteger = Integer.parseInt(parts[2]);
      levelInteger = Integer.parseInt(parts[3]);
    } catch (NumberFormatException e) {
      Log.w(TAG, "Ignoring malformed AC-4 codec string: " + codec);
      return null;
    }

    int profile =
        ac4BitstreamAndPresentationVersionsToProfileConst(
            bitstreamVersionInteger, presentationVersionInteger);
    if (profile == -1) {
      Log.w(
          TAG,
          "Unknown AC-4 profile: " + bitstreamVersionInteger + "." + presentationVersionInteger);
      return MediaCodecProfileAndLevel.UNSUPPORTABLE;
    }
    int level = ac4LevelNumberToConst(levelInteger);
    if (level == -1) {
      Log.w(TAG, "Unknown AC-4 level: " + levelInteger);
      return MediaCodecProfileAndLevel.UNSUPPORTABLE;
    }
    return new MediaCodecProfileAndLevel(profile, level);
  }

  @Nullable
  private static MediaCodecProfileAndLevel getIamfCodecProfileAndLevel(
      String codec, String[] parts) {
    if (parts.length < 4) {
      Log.w(TAG, "Ignoring malformed IAMF codec string: " + codec);
      return null;
    }

    int profileNumber;
    try {
      profileNumber = Integer.parseInt(parts[1]);
    } catch (NumberFormatException e) {
      Log.w(TAG, "Ignoring malformed primary profile in IAMF codec string: " + parts[1], e);
      return null;
    }
    int profile = iamfProfileNumberToConst(/* codec= */ parts[3], profileNumber);
    if (profile == -1) {
      return MediaCodecProfileAndLevel.UNSUPPORTABLE;
    }
    return new MediaCodecProfileAndLevel(profile, /* level= */ 0);
  }

  private static int iamfProfileNumberToConst(String codec, int profileNumber) {
    switch (codec) {
      case "Opus":
        switch (profileNumber) {
          case 0:
            return CodecProfileLevel.IAMFProfileSimpleOpus;
          case 1:
            return CodecProfileLevel.IAMFProfileBaseOpus;
          case 2:
            return CodecProfileLevel.IAMFProfileBaseEnhancedOpus;
          default:
            Log.w(TAG, "Unrecognized IAMF Opus profile: " + profileNumber);
            return -1;
        }
      case "mp4a":
        switch (profileNumber) {
          case 0:
            return CodecProfileLevel.IAMFProfileSimpleAac;
          case 1:
            return CodecProfileLevel.IAMFProfileBaseAac;
          case 2:
            return CodecProfileLevel.IAMFProfileBaseEnhancedAac;
          default:
            Log.w(TAG, "Unrecognized IAMF AAC profile: " + profileNumber);
            return -1;
        }
      case "fLaC":
        switch (profileNumber) {
          case 0:
            return CodecProfileLevel.IAMFProfileSimpleFlac;
          case 1:
            return CodecProfileLevel.IAMFProfileBaseFlac;
          case 2:
            return CodecProfileLevel.IAMFProfileBaseEnhancedFlac;
          default:
            Log.w(TAG, "Unrecognized IAMF FLAC profile: " + profileNumber);
            return -1;
        }
      case "ipcm":
        switch (profileNumber) {
          case 0:
            return CodecProfileLevel.IAMFProfileSimplePcm;
          case 1:
            return CodecProfileLevel.IAMFProfileBasePcm;
          case 2:
            return CodecProfileLevel.IAMFProfileBaseEnhancedPcm;
          default:
            Log.w(TAG, "Unrecognized IAMF PCM profile: " + profileNumber);
            return -1;
        }
      default:
        Log.w(TAG, "Unrecognized codec identifier for IAMF auxiliary profile: " + codec);
        return -1;
    }
  }

  private static int avcProfileNumberToConst(int profileNumber) {
    switch (profileNumber) {
      case 66:
        return MediaCodecInfo.CodecProfileLevel.AVCProfileBaseline;
      case 77:
        return MediaCodecInfo.CodecProfileLevel.AVCProfileMain;
      case 88:
        return MediaCodecInfo.CodecProfileLevel.AVCProfileExtended;
      case 100:
        return MediaCodecInfo.CodecProfileLevel.AVCProfileHigh;
      case 110:
        return MediaCodecInfo.CodecProfileLevel.AVCProfileHigh10;
      case 122:
        return MediaCodecInfo.CodecProfileLevel.AVCProfileHigh422;
      case 244:
        return MediaCodecInfo.CodecProfileLevel.AVCProfileHigh444;
      default:
        return -1;
    }
  }

  private static int avcLevelNumberToConst(int levelNumber) {
    // TODO: Find int for CodecProfileLevel.AVCLevel1b.
    switch (levelNumber) {
      case 10:
        return MediaCodecInfo.CodecProfileLevel.AVCLevel1;
      case 11:
        return MediaCodecInfo.CodecProfileLevel.AVCLevel11;
      case 12:
        return MediaCodecInfo.CodecProfileLevel.AVCLevel12;
      case 13:
        return MediaCodecInfo.CodecProfileLevel.AVCLevel13;
      case 20:
        return MediaCodecInfo.CodecProfileLevel.AVCLevel2;
      case 21:
        return MediaCodecInfo.CodecProfileLevel.AVCLevel21;
      case 22:
        return MediaCodecInfo.CodecProfileLevel.AVCLevel22;
      case 30:
        return MediaCodecInfo.CodecProfileLevel.AVCLevel3;
      case 31:
        return MediaCodecInfo.CodecProfileLevel.AVCLevel31;
      case 32:
        return MediaCodecInfo.CodecProfileLevel.AVCLevel32;
      case 40:
        return MediaCodecInfo.CodecProfileLevel.AVCLevel4;
      case 41:
        return MediaCodecInfo.CodecProfileLevel.AVCLevel41;
      case 42:
        return MediaCodecInfo.CodecProfileLevel.AVCLevel42;
      case 50:
        return MediaCodecInfo.CodecProfileLevel.AVCLevel5;
      case 51:
        return MediaCodecInfo.CodecProfileLevel.AVCLevel51;
      case 52:
        return MediaCodecInfo.CodecProfileLevel.AVCLevel52;
      default:
        return -1;
    }
  }

  private static int vp9ProfileNumberToConst(int profileNumber) {
    switch (profileNumber) {
      case 0:
        return MediaCodecInfo.CodecProfileLevel.VP9Profile0;
      case 1:
        return MediaCodecInfo.CodecProfileLevel.VP9Profile1;
      case 2:
        return MediaCodecInfo.CodecProfileLevel.VP9Profile2;
      case 3:
        return MediaCodecInfo.CodecProfileLevel.VP9Profile3;
      default:
        return -1;
    }
  }

  private static int vp9LevelNumberToConst(int levelNumber) {
    switch (levelNumber) {
      case 10:
        return MediaCodecInfo.CodecProfileLevel.VP9Level1;
      case 11:
        return MediaCodecInfo.CodecProfileLevel.VP9Level11;
      case 20:
        return MediaCodecInfo.CodecProfileLevel.VP9Level2;
      case 21:
        return MediaCodecInfo.CodecProfileLevel.VP9Level21;
      case 30:
        return MediaCodecInfo.CodecProfileLevel.VP9Level3;
      case 31:
        return MediaCodecInfo.CodecProfileLevel.VP9Level31;
      case 40:
        return MediaCodecInfo.CodecProfileLevel.VP9Level4;
      case 41:
        return MediaCodecInfo.CodecProfileLevel.VP9Level41;
      case 50:
        return MediaCodecInfo.CodecProfileLevel.VP9Level5;
      case 51:
        return MediaCodecInfo.CodecProfileLevel.VP9Level51;
      case 60:
        return MediaCodecInfo.CodecProfileLevel.VP9Level6;
      case 61:
        return MediaCodecInfo.CodecProfileLevel.VP9Level61;
      case 62:
        return MediaCodecInfo.CodecProfileLevel.VP9Level62;
      default:
        return -1;
    }
  }

  @Nullable
  private static Integer hevcCodecStringToProfileLevel(String codecString) {
    switch (codecString) {
      case "L30":
        return MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel1;
      case "L60":
        return MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel2;
      case "L63":
        return MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel21;
      case "L90":
        return MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel3;
      case "L93":
        return MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel31;
      case "L120":
        return MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel4;
      case "L123":
        return MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel41;
      case "L150":
        return MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel5;
      case "L153":
        return MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel51;
      case "L156":
        return MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel52;
      case "L180":
        return MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel6;
      case "L183":
        return MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel61;
      case "L186":
        return MediaCodecInfo.CodecProfileLevel.HEVCMainTierLevel62;
      case "H30":
        return MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel1;
      case "H60":
        return MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel2;
      case "H63":
        return MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel21;
      case "H90":
        return MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel3;
      case "H93":
        return MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel31;
      case "H120":
        return MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel4;
      case "H123":
        return MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel41;
      case "H150":
        return MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel5;
      case "H153":
        return MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel51;
      case "H156":
        return MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel52;
      case "H180":
        return MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel6;
      case "H183":
        return MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel61;
      case "H186":
        return MediaCodecInfo.CodecProfileLevel.HEVCHighTierLevel62;
      default:
        return null;
    }
  }

  @Nullable
  private static Integer dolbyVisionStringToProfile(String profileString) {
    if (profileString == null) {
      return null;
    }
    switch (profileString) {
      case "00":
        return MediaCodecInfo.CodecProfileLevel.DolbyVisionProfileDvavPer;
      case "01":
        return MediaCodecInfo.CodecProfileLevel.DolbyVisionProfileDvavPen;
      case "02":
        return MediaCodecInfo.CodecProfileLevel.DolbyVisionProfileDvheDer;
      case "03":
        return MediaCodecInfo.CodecProfileLevel.DolbyVisionProfileDvheDen;
      case "04":
        return MediaCodecInfo.CodecProfileLevel.DolbyVisionProfileDvheDtr;
      case "05":
        return MediaCodecInfo.CodecProfileLevel.DolbyVisionProfileDvheStn;
      case "06":
        return MediaCodecInfo.CodecProfileLevel.DolbyVisionProfileDvheDth;
      case "07":
        return MediaCodecInfo.CodecProfileLevel.DolbyVisionProfileDvheDtb;
      case "08":
        return MediaCodecInfo.CodecProfileLevel.DolbyVisionProfileDvheSt;
      case "09":
        return MediaCodecInfo.CodecProfileLevel.DolbyVisionProfileDvavSe;
      case "10":
        return MediaCodecInfo.CodecProfileLevel.DolbyVisionProfileDvav110;
      default:
        return null;
    }
  }

  @Nullable
  private static Integer dolbyVisionStringToLevel(String levelString) {
    // TODO (Internal: b/179261323): use framework constant for level 13.
    switch (levelString) {
      case "01":
        return MediaCodecInfo.CodecProfileLevel.DolbyVisionLevelHd24;
      case "02":
        return MediaCodecInfo.CodecProfileLevel.DolbyVisionLevelHd30;
      case "03":
        return MediaCodecInfo.CodecProfileLevel.DolbyVisionLevelFhd24;
      case "04":
        return MediaCodecInfo.CodecProfileLevel.DolbyVisionLevelFhd30;
      case "05":
        return MediaCodecInfo.CodecProfileLevel.DolbyVisionLevelFhd60;
      case "06":
        return MediaCodecInfo.CodecProfileLevel.DolbyVisionLevelUhd24;
      case "07":
        return MediaCodecInfo.CodecProfileLevel.DolbyVisionLevelUhd30;
      case "08":
        return MediaCodecInfo.CodecProfileLevel.DolbyVisionLevelUhd48;
      case "09":
        return MediaCodecInfo.CodecProfileLevel.DolbyVisionLevelUhd60;
      case "10":
        return MediaCodecInfo.CodecProfileLevel.DolbyVisionLevelUhd120;
      case "11":
        return MediaCodecInfo.CodecProfileLevel.DolbyVisionLevel8k30;
      case "12":
        return MediaCodecInfo.CodecProfileLevel.DolbyVisionLevel8k60;
      case "13":
        return 0x1000;
      default:
        return null;
    }
  }

  private static int av1LevelNumberToConst(int levelNumber) {
    // See https://aomediacodec.github.io/av1-spec/av1-spec.pdf Annex A: Profiles and levels for
    // more information on mapping AV1 codec strings to levels.
    switch (levelNumber) {
      case 0:
        return MediaCodecInfo.CodecProfileLevel.AV1Level2;
      case 1:
        return MediaCodecInfo.CodecProfileLevel.AV1Level21;
      case 2:
        return MediaCodecInfo.CodecProfileLevel.AV1Level22;
      case 3:
        return MediaCodecInfo.CodecProfileLevel.AV1Level23;
      case 4:
        return MediaCodecInfo.CodecProfileLevel.AV1Level3;
      case 5:
        return MediaCodecInfo.CodecProfileLevel.AV1Level31;
      case 6:
        return MediaCodecInfo.CodecProfileLevel.AV1Level32;
      case 7:
        return MediaCodecInfo.CodecProfileLevel.AV1Level33;
      case 8:
        return MediaCodecInfo.CodecProfileLevel.AV1Level4;
      case 9:
        return MediaCodecInfo.CodecProfileLevel.AV1Level41;
      case 10:
        return MediaCodecInfo.CodecProfileLevel.AV1Level42;
      case 11:
        return MediaCodecInfo.CodecProfileLevel.AV1Level43;
      case 12:
        return MediaCodecInfo.CodecProfileLevel.AV1Level5;
      case 13:
        return MediaCodecInfo.CodecProfileLevel.AV1Level51;
      case 14:
        return MediaCodecInfo.CodecProfileLevel.AV1Level52;
      case 15:
        return MediaCodecInfo.CodecProfileLevel.AV1Level53;
      case 16:
        return MediaCodecInfo.CodecProfileLevel.AV1Level6;
      case 17:
        return MediaCodecInfo.CodecProfileLevel.AV1Level61;
      case 18:
        return MediaCodecInfo.CodecProfileLevel.AV1Level62;
      case 19:
        return MediaCodecInfo.CodecProfileLevel.AV1Level63;
      case 20:
        return MediaCodecInfo.CodecProfileLevel.AV1Level7;
      case 21:
        return MediaCodecInfo.CodecProfileLevel.AV1Level71;
      case 22:
        return MediaCodecInfo.CodecProfileLevel.AV1Level72;
      case 23:
        return MediaCodecInfo.CodecProfileLevel.AV1Level73;
      default:
        return -1;
    }
  }

  private static int mp4aAudioObjectTypeToProfile(int profileNumber) {
    switch (profileNumber) {
      case 1:
        return MediaCodecInfo.CodecProfileLevel.AACObjectMain;
      case 2:
        return MediaCodecInfo.CodecProfileLevel.AACObjectLC;
      case 3:
        return MediaCodecInfo.CodecProfileLevel.AACObjectSSR;
      case 4:
        return MediaCodecInfo.CodecProfileLevel.AACObjectLTP;
      case 5:
        return MediaCodecInfo.CodecProfileLevel.AACObjectHE;
      case 6:
        return MediaCodecInfo.CodecProfileLevel.AACObjectScalable;
      case 17:
        return MediaCodecInfo.CodecProfileLevel.AACObjectERLC;
      case 20:
        return MediaCodecInfo.CodecProfileLevel.AACObjectERScalable;
      case 23:
        return MediaCodecInfo.CodecProfileLevel.AACObjectLD;
      case 29:
        return MediaCodecInfo.CodecProfileLevel.AACObjectHE_PS;
      case 39:
        return MediaCodecInfo.CodecProfileLevel.AACObjectELD;
      case 42:
        return MediaCodecInfo.CodecProfileLevel.AACObjectXHE;
      default:
        return -1;
    }
  }

  private static int ac4BitstreamAndPresentationVersionsToProfileConst(
      int bitstreamVersionInteger, int presentationVersionInteger) {
    int ac4Profile = -1;
    switch (bitstreamVersionInteger) {
      case 0:
        if (presentationVersionInteger == 0) {
          ac4Profile = MediaCodecInfo.CodecProfileLevel.AC4Profile00;
        }
        break;
      case 1:
        if (presentationVersionInteger == 0) {
          ac4Profile = MediaCodecInfo.CodecProfileLevel.AC4Profile10;
        } else if (presentationVersionInteger == 1) {
          ac4Profile = MediaCodecInfo.CodecProfileLevel.AC4Profile11;
        }
        break;
      case 2:
        if (presentationVersionInteger == 1) {
          ac4Profile = MediaCodecInfo.CodecProfileLevel.AC4Profile21;
        } else if (presentationVersionInteger == 2) {
          ac4Profile = MediaCodecInfo.CodecProfileLevel.AC4Profile22;
        }
        break;
      default:
        break;
    }
    return ac4Profile;
  }

  private static int ac4LevelNumberToConst(int levelNumber) {
    switch (levelNumber) {
      case 0:
        return MediaCodecInfo.CodecProfileLevel.AC4Level0;
      case 1:
        return MediaCodecInfo.CodecProfileLevel.AC4Level1;
      case 2:
        return MediaCodecInfo.CodecProfileLevel.AC4Level2;
      case 3:
        return MediaCodecInfo.CodecProfileLevel.AC4Level3;
      case 4:
        return MediaCodecInfo.CodecProfileLevel.AC4Level4;
      default:
        return -1;
    }
  }

  /** Maps H.263 Profile numbers to Android MediaCodec constants. */
  private static int h263ProfileNumberToConst(int profileNumber) {
    switch (profileNumber) {
      case 0:
        return MediaCodecInfo.CodecProfileLevel.H263ProfileBaseline;
      case 1:
        return MediaCodecInfo.CodecProfileLevel.H263ProfileH320Coding;
      case 2:
        return MediaCodecInfo.CodecProfileLevel.H263ProfileBackwardCompatible;
      case 3:
        return MediaCodecInfo.CodecProfileLevel.H263ProfileISWV2;
      case 4:
        return MediaCodecInfo.CodecProfileLevel.H263ProfileISWV3;
      case 5:
        return MediaCodecInfo.CodecProfileLevel.H263ProfileHighCompression;
      case 6:
        return MediaCodecInfo.CodecProfileLevel.H263ProfileInternet;
      case 7:
        return MediaCodecInfo.CodecProfileLevel.H263ProfileInterlace;
      case 8:
        return MediaCodecInfo.CodecProfileLevel.H263ProfileHighLatency;
      default:
        return -1;
    }
  }

  /** Maps H.263 Level numbers to Android MediaCodec constants. */
  private static int h263LevelNumberToConst(int levelNumber) {
    switch (levelNumber) {
      case 10:
        return MediaCodecInfo.CodecProfileLevel.H263Level10;
      case 20:
        return MediaCodecInfo.CodecProfileLevel.H263Level20;
      case 30:
        return MediaCodecInfo.CodecProfileLevel.H263Level30;
      case 40:
        return MediaCodecInfo.CodecProfileLevel.H263Level40;
      case 45:
        return MediaCodecInfo.CodecProfileLevel.H263Level45;
      case 50:
        return MediaCodecInfo.CodecProfileLevel.H263Level50;
      case 60:
        return MediaCodecInfo.CodecProfileLevel.H263Level60;
      case 70:
        return MediaCodecInfo.CodecProfileLevel.H263Level70;
      default:
        return -1;
    }
  }

  /**
   * Maps Android MediaCodec constants to H.263 Profile numbers.
   *
   * @param profileConst The MediaCodec H.263 profile constant.
   * @return The H.263 profile number, or -1 if the constant is not recognized.
   */
  public static int h263ConstToProfileNumber(int profileConst) {
    switch (profileConst) {
      case MediaCodecInfo.CodecProfileLevel.H263ProfileBaseline:
        return 0;
      case MediaCodecInfo.CodecProfileLevel.H263ProfileH320Coding:
        return 1;
      case MediaCodecInfo.CodecProfileLevel.H263ProfileBackwardCompatible:
        return 2;
      case MediaCodecInfo.CodecProfileLevel.H263ProfileISWV2:
        return 3;
      case MediaCodecInfo.CodecProfileLevel.H263ProfileISWV3:
        return 4;
      case MediaCodecInfo.CodecProfileLevel.H263ProfileHighCompression:
        return 5;
      case MediaCodecInfo.CodecProfileLevel.H263ProfileInternet:
        return 6;
      case MediaCodecInfo.CodecProfileLevel.H263ProfileInterlace:
        return 7;
      case MediaCodecInfo.CodecProfileLevel.H263ProfileHighLatency:
        return 8;
      default:
        return -1;
    }
  }

  /**
   * Maps Android MediaCodec constants to H.263 Level numbers.
   *
   * @param levelConst The MediaCodec H.263 level constant.
   * @return The H.263 level number, or -1 if the constant is not recognized.
   */
  public static int h263ConstToLevelNumber(int levelConst) {
    switch (levelConst) {
      case MediaCodecInfo.CodecProfileLevel.H263Level10:
        return 10;
      case MediaCodecInfo.CodecProfileLevel.H263Level20:
        return 20;
      case MediaCodecInfo.CodecProfileLevel.H263Level30:
        return 30;
      case MediaCodecInfo.CodecProfileLevel.H263Level40:
        return 40;
      case MediaCodecInfo.CodecProfileLevel.H263Level45:
        return 45;
      case MediaCodecInfo.CodecProfileLevel.H263Level50:
        return 50;
      case MediaCodecInfo.CodecProfileLevel.H263Level60:
        return 60;
      case MediaCodecInfo.CodecProfileLevel.H263Level70:
        return 70;
      default:
        return -1;
    }
  }

  // Expected magic bytes for HAGC (ST 2094-50) metadata in AV1 OBU or HEVC SEI.
  private static final byte[] expectedHagcPayloadPrefix = {
    // itu_t_t35_country_code == 0xB5
    (byte) 0xB5,
    // itu_t_t35_terminal_provider_code == 0x0090
    (byte) 0x00,
    (byte) 0x90,
    // itu_t_t35_terminal_provider_oriented_code == 0x0001
    (byte) 0x00,
    (byte) 0x01,
  };

  /**
   * Returns whether the given {@code data} contains HAGC (ST 2094-50) ITU-T T.35 metadata.
   *
   * @param data The payload data.
   * @param length The length of the payload data.
   */
  public static boolean isHagcMetadata(byte[] data, int length) {
    if (length < expectedHagcPayloadPrefix.length) {
      return false;
    }
    for (int i = 0; i < expectedHagcPayloadPrefix.length; i++) {
      if (data[i] != expectedHagcPayloadPrefix[i]) {
        return false;
      }
    }
    return true;
  }

  /**
   * Returns whether the given {@link ByteBuffer} contains HAGC (ST 2094-50) ITU-T T.35 metadata,
   * without consuming any bytes.
   *
   * @param buffer The payload data.
   */
  public static boolean isHagcMetadata(ByteBuffer buffer) {
    if (buffer.remaining() < expectedHagcPayloadPrefix.length) {
      return false;
    }
    int pos = buffer.position();
    for (int i = 0; i < expectedHagcPayloadPrefix.length; i++) {
      if (buffer.get(pos + i) != expectedHagcPayloadPrefix[i]) {
        return false;
      }
    }
    return true;
  }

  /**
   * Returns whether the given {@link Format} represents an HAGC (ST 2094-50) metadata track.
   *
   * @param format The format of the track.
   */
  public static boolean isHagcTrack(Format format) {
    if (!Objects.equals(format.sampleMimeType, MimeTypes.APPLICATION_ITUT_T35)) {
      return false;
    }
    for (byte[] initData : format.initializationData) {
      if (isHagcMetadata(initData, initData.length)) {
        return true;
      }
    }
    return false;
  }

  private CodecSpecificDataUtil() {}
}
