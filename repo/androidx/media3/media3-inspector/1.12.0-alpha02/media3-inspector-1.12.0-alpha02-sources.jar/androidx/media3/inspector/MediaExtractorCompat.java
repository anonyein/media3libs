/*
 * Copyright 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.inspector;

import static androidx.annotation.VisibleForTesting.NONE;
import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.base.Preconditions.checkState;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.MediaCodec;
import android.media.MediaDataSource;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.metrics.LogSessionId;
import android.net.Uri;
import android.os.PersistableBundle;
import androidx.annotation.IntDef;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.VisibleForTesting;
import androidx.media3.common.C;
import androidx.media3.common.DrmInitData;
import androidx.media3.common.MediaLibraryInfo;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.common.util.Util;
import androidx.media3.datasource.DataSource;
import androidx.media3.datasource.DataSpec;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.datasource.FileDataSource;
import androidx.media3.datasource.TransferListener;
import androidx.media3.exoplayer.source.BundledExtractorsAdapter;
import androidx.media3.exoplayer.source.ProgressiveMediaExtractor;
import androidx.media3.exoplayer.source.UnrecognizedInputFormatException;
import androidx.media3.exoplayer.upstream.Allocator;
import androidx.media3.extractor.DefaultExtractorsFactory;
import androidx.media3.extractor.Extractor;
import androidx.media3.extractor.ExtractorsFactory;
import androidx.media3.extractor.mp4.FragmentedMp4Extractor;
import androidx.media3.extractor.mp4.Mp4Extractor;
import com.google.common.base.Ascii;
import com.google.common.collect.ImmutableMap;
import java.io.FileDescriptor;
import java.io.IOException;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * A drop-in replacement for {@link MediaExtractor} that provides similar functionality, based on
 * the {@code media3.extractor} logic.
 */
@UnstableApi
public final class MediaExtractorCompat {

  static {
    MediaLibraryInfo.registerModule("media3.inspector");
  }

  /**
   * The seeking mode. One of {@link #SEEK_TO_PREVIOUS_SYNC}, {@link #SEEK_TO_NEXT_SYNC}, or {@link
   * #SEEK_TO_CLOSEST_SYNC}.
   */
  @IntDef({
    SEEK_TO_PREVIOUS_SYNC,
    SEEK_TO_NEXT_SYNC,
    SEEK_TO_CLOSEST_SYNC,
  })
  @Retention(RetentionPolicy.SOURCE)
  public @interface SeekMode {}

  /** See {@link MediaExtractor#SEEK_TO_PREVIOUS_SYNC}. */
  public static final int SEEK_TO_PREVIOUS_SYNC = MediaExtractor.SEEK_TO_PREVIOUS_SYNC;

  /** See {@link MediaExtractor#SEEK_TO_NEXT_SYNC}. */
  public static final int SEEK_TO_NEXT_SYNC = MediaExtractor.SEEK_TO_NEXT_SYNC;

  /** See {@link MediaExtractor#SEEK_TO_CLOSEST_SYNC}. */
  public static final int SEEK_TO_CLOSEST_SYNC = MediaExtractor.SEEK_TO_CLOSEST_SYNC;

  private final MediaExtractorCompatInternal delegate;

  /**
   * Creates a new instance using a {@link DefaultExtractorsFactory} and a default {@link
   * DataSource.Factory} that supports local files and HTTP/HTTPS streams.
   *
   * <p>Note: Without a {@link Context}, {@code content://} and {@code android.resource://} URIs are
   * only supported via {@link #setDataSource(Context, Uri, Map)}. For full {@link
   * DefaultDataSource} support (including {@code asset://} URIs), use {@link
   * #MediaExtractorCompat(Context)}.
   */
  public MediaExtractorCompat() {
    this(createDefaultExtractorsFactory(), MediaExtractorDataSource.FACTORY);
  }

  /**
   * Creates a new instance using a {@link DefaultExtractorsFactory} and a {@link
   * DefaultDataSource.Factory} configured with the given {@link Context}.
   */
  public MediaExtractorCompat(Context context) {
    this(createDefaultExtractorsFactory(), new DefaultDataSource.Factory(context));
  }

  private static DefaultExtractorsFactory createDefaultExtractorsFactory() {
    return new DefaultExtractorsFactory()
        .setMp4ExtractorFlags(Mp4Extractor.FLAG_EMIT_RAW_MEBX_DATA)
        .setFragmentedMp4ExtractorFlags(FragmentedMp4Extractor.FLAG_EMIT_RAW_MEBX_DATA);
  }

  /**
   * Creates a new instance using the given {@link ProgressiveMediaExtractor} and a default {@link
   * DataSource.Factory} that supports local files and HTTP/HTTPS streams.
   *
   * <p>Note: Without a {@link Context}, {@code content://} and {@code android.resource://} URIs are
   * only supported via {@link #setDataSource(Context, Uri, Map)}. For full {@link
   * DefaultDataSource} support (including {@code asset://} URIs), use {@link
   * #MediaExtractorCompat(ProgressiveMediaExtractor, DataSource.Factory)} with a {@link
   * DefaultDataSource.Factory}.
   */
  public MediaExtractorCompat(ProgressiveMediaExtractor progressiveMediaExtractor) {
    this(progressiveMediaExtractor, MediaExtractorDataSource.FACTORY);
  }

  /**
   * Creates a new instance using the given {@link ExtractorsFactory} to create the {@linkplain
   * Extractor extractors} to use for obtaining media samples from a {@link DataSource} generated by
   * the given {@link DataSource.Factory}.
   *
   * <p>Note: The {@link DataSource.Factory} provided will not be used to generate {@link
   * DataSource} when setting data source using methods:
   *
   * <ul>
   *   <li>{@link #setDataSource(AssetFileDescriptor)}
   *   <li>{@link #setDataSource(FileDescriptor)}
   *   <li>{@link #setDataSource(FileDescriptor, long, long)}
   * </ul>
   *
   * <p>Note: The {@link DataSource.Factory} provided may not be used to generate {@link DataSource}
   * when setting data source using method {@link #setDataSource(Context, Uri, Map)} as the behavior
   * depends on the fallthrough logic related to the scheme of the provided URI.
   */
  public MediaExtractorCompat(
      ExtractorsFactory extractorsFactory, DataSource.Factory dataSourceFactory) {
    this(new BundledExtractorsAdapter(extractorsFactory), dataSourceFactory);
  }

  /**
   * Creates a new instance using the given {@link ProgressiveMediaExtractor} to obtain media
   * samples from a {@link DataSource} generated by the given {@link DataSource.Factory}.
   *
   * <p>Note: The {@link DataSource.Factory} provided will not be used to generate {@link
   * DataSource} when setting data source using methods:
   *
   * <ul>
   *   <li>{@link #setDataSource(AssetFileDescriptor)}
   *   <li>{@link #setDataSource(FileDescriptor)}
   *   <li>{@link #setDataSource(FileDescriptor, long, long)}
   * </ul>
   *
   * <p>Note: The {@link DataSource.Factory} provided may not be used to generate {@link DataSource}
   * when setting data source using method {@link #setDataSource(Context, Uri, Map)} as the behavior
   * depends on the fallthrough logic related to the scheme of the provided URI.
   */
  public MediaExtractorCompat(
      ProgressiveMediaExtractor progressiveMediaExtractor, DataSource.Factory dataSourceFactory) {
    delegate = new MediaExtractorCompatInternal(progressiveMediaExtractor, dataSourceFactory);
  }

  /**
   * Sets the data source using the media stream obtained from the given {@link Uri} at the given
   * {@code offset}.
   *
   * @param uri The content {@link Uri} to extract from.
   * @param offset The offset into the file where the data to be extracted starts, in bytes.
   * @throws IOException If an error occurs while extracting the media.
   * @throws UnrecognizedInputFormatException If none of the available extractors successfully
   *     sniffs the input.
   * @throws IllegalStateException If this method is called twice on the same instance.
   */
  public void setDataSource(Uri uri, long offset) throws IOException {
    delegate.setDataSource(uri, offset);
  }

  /**
   * Sets the data source using the media stream obtained from the provided {@link
   * AssetFileDescriptor}.
   *
   * <p>Note: The caller is responsible for closing the {@link AssetFileDescriptor}. It is safe to
   * do so immediately after this method returns.
   *
   * @param assetFileDescriptor The {@link AssetFileDescriptor} for the file to extract from.
   * @throws IOException If an error occurs while extracting the media.
   * @throws UnrecognizedInputFormatException If none of the available extractors successfully
   *     sniffs the input.
   * @throws IllegalStateException If this method is called twice on the same instance.
   */
  public void setDataSource(AssetFileDescriptor assetFileDescriptor) throws IOException {
    delegate.setDataSource(assetFileDescriptor);
  }

  /**
   * Sets the data source using the media stream obtained from the provided {@link FileDescriptor}.
   *
   * <p>Note: The caller is responsible for closing the {@link FileDescriptor}. It is safe to do so
   * immediately after this method returns.
   *
   * @param fileDescriptor The {@link FileDescriptor} for the file to extract from.
   * @throws IOException If an error occurs while extracting the media.
   * @throws UnrecognizedInputFormatException If none of the available extractors successfully
   *     sniffs the input.
   * @throws IllegalStateException If this method is called twice on the same instance.
   */
  public void setDataSource(FileDescriptor fileDescriptor) throws IOException {
    delegate.setDataSource(fileDescriptor);
  }

  /**
   * Sets the data source using the media stream obtained from the provided {@link FileDescriptor},
   * with a specified {@code offset} and {@code length}.
   *
   * <p>Note: The caller is responsible for closing the {@link FileDescriptor}. It is safe to do so
   * immediately after this method returns.
   *
   * @param fileDescriptor The {@link FileDescriptor} for the file to extract from.
   * @param offset The offset into the file where the data to be extracted starts, in bytes.
   * @param length The length of the data to be extracted, in bytes, or {@link C#LENGTH_UNSET} if it
   *     is unknown.
   * @throws IOException If an error occurs while extracting the media.
   * @throws UnrecognizedInputFormatException If none of the available extractors successfully
   *     sniffs the input.
   * @throws IllegalStateException If this method is called twice on the same instance.
   */
  public void setDataSource(FileDescriptor fileDescriptor, long offset, long length)
      throws IOException {
    delegate.setDataSource(fileDescriptor, offset, length);
  }

  /**
   * Sets the data source using the media stream obtained from the given {@linkplain Uri content
   * URI} and optional HTTP request headers.
   *
   * @param context The {@link Context} used to resolve the {@link Uri}.
   * @param uri The {@linkplain Uri content URI} of the media to extract from.
   * @param headers An optional {@link Map} of HTTP request headers to include when fetching the
   *     data, or {@code null} if no headers are to be included.
   * @throws IOException If an error occurs while extracting the media.
   * @throws UnrecognizedInputFormatException If none of the available extractors successfully
   *     sniffs the input.
   * @throws IllegalStateException If this method is called twice on the same instance.
   */
  public void setDataSource(Context context, Uri uri, @Nullable Map<String, String> headers)
      throws IOException {
    delegate.setDataSource(context, uri, headers);
  }

  /**
   * Sets the data source using the media stream obtained from the given file path or HTTP URL.
   *
   * @param path The path of the file, or the HTTP URL, to extract media from.
   * @throws IOException If an error occurs while extracting the media.
   * @throws UnrecognizedInputFormatException If none of the available extractors successfully
   *     sniffs the input.
   * @throws IllegalStateException If this method is called twice on the same instance.
   */
  public void setDataSource(String path) throws IOException {
    delegate.setDataSource(path);
  }

  /**
   * Sets the data source using the media stream obtained from the given file path or HTTP URL, with
   * optional HTTP request headers.
   *
   * @param path The path of the file, or the HTTP URL, to extract media from.
   * @param headers An optional {@link Map} of HTTP request headers to include when fetching the
   *     data, or {@code null} if no headers are to be included.
   * @throws IOException If an error occurs while extracting the media.
   * @throws UnrecognizedInputFormatException If none of the available extractors successfully
   *     sniffs the input.
   * @throws IllegalStateException If this method is called twice on the same instance.
   */
  public void setDataSource(String path, @Nullable Map<String, String> headers) throws IOException {
    delegate.setDataSource(path, headers);
  }

  /**
   * Sets the data source using the media stream obtained from the given {@link MediaDataSource}.
   *
   * @param mediaDataSource The {@link MediaDataSource} to extract media from.
   * @throws IOException If an error occurs while extracting the media.
   * @throws UnrecognizedInputFormatException If none of the available extractors successfully
   *     sniffs the input.
   * @throws IllegalStateException If this method is called twice on the same instance.
   */
  public void setDataSource(MediaDataSource mediaDataSource) throws IOException {
    delegate.setDataSource(mediaDataSource);
  }

  /**
   * Releases any resources held by this instance.
   *
   * <p>Note: Make sure you call this when you're done to free up any resources instead of relying
   * on the garbage collector to do this for you at some point in the future.
   */
  public void release() {
    delegate.release();
  }

  /** Returns the number of tracks found in the data source. */
  public int getTrackCount() {
    return delegate.getTrackCount();
  }

  /** Returns the track {@link MediaFormat} at the specified {@code trackIndex}. */
  public MediaFormat getTrackFormat(int trackIndex) {
    return delegate.getTrackFormat(trackIndex);
  }

  /**
   * Selects a track at the specified {@code trackIndex}.
   *
   * <p>Subsequent calls to {@link #readSampleData}, {@link #getSampleTrackIndex} and {@link
   * #getSampleTime} only retrieve information for the subset of tracks selected.
   *
   * <p>Note: Selecting the same track multiple times has no effect, the track is only selected
   * once.
   */
  public void selectTrack(int trackIndex) {
    delegate.selectTrack(trackIndex);
  }

  /**
   * Unselects the track at the specified {@code trackIndex}.
   *
   * <p>Subsequent calls to {@link #readSampleData}, {@link #getSampleTrackIndex} and {@link
   * #getSampleTime} only retrieve information for the subset of tracks selected.
   */
  public void unselectTrack(int trackIndex) {
    delegate.unselectTrack(trackIndex);
  }

  /**
   * All selected tracks seek near the requested {@code timeUs} according to the specified {@code
   * mode}.
   */
  public void seekTo(long timeUs, @SeekMode int mode) {
    delegate.seekTo(timeUs, mode);
  }

  /**
   * Advances to the next sample. Returns {@code false} if no more sample data is available (i.e.,
   * end of stream), or {@code true} otherwise.
   *
   * <p>Note: When extracting from a local file, the behavior of {@link #advance} and {@link
   * #readSampleData} is undefined if there are concurrent writes to the same file. This may result
   * in an unexpected end of stream being signaled.
   */
  public boolean advance() {
    return delegate.advance();
  }

  /**
   * Retrieves the current encoded sample and stores it in the byte {@code buffer} starting at the
   * given {@code offset}.
   *
   * <p><b>Note:</b>On success, the position and limit of {@code buffer} is updated to point to the
   * data just read.
   *
   * @param buffer the destination byte buffer.
   * @param offset The offset into the byte buffer at which to write.
   * @return the sample size, or -1 if no more samples are available.
   */
  public int readSampleData(ByteBuffer buffer, int offset) {
    return delegate.readSampleData(buffer, offset);
  }

  /**
   * Returns the track index the current sample originates from, or -1 if no more samples are
   * available.
   */
  public int getSampleTrackIndex() {
    return delegate.getSampleTrackIndex();
  }

  /** Returns the current sample's size in bytes, or -1 if no more samples are available. */
  public long getSampleSize() {
    return delegate.getSampleSize();
  }

  /**
   * Returns the current sample's presentation time in microseconds, or -1 if no more samples are
   * available.
   */
  public long getSampleTime() {
    return delegate.getSampleTime();
  }

  /** Returns the current sample's flags. */
  public int getSampleFlags() {
    return delegate.getSampleFlags();
  }

  /**
   * Returns {@code true} if the current sample is at least partially encrypted and fills the
   * provided {@link MediaCodec.CryptoInfo} structure with relevant decryption information.
   *
   * @param info The {@link MediaCodec.CryptoInfo} structure to be filled with decryption data.
   * @return {@code true} if the sample is at least partially encrypted, {@code false} otherwise.
   */
  public boolean getSampleCryptoInfo(MediaCodec.CryptoInfo info) {
    return delegate.getSampleCryptoInfo(info);
  }

  /** Sets the {@link LogSessionId} for MediaExtractorCompat. */
  @RequiresApi(31)
  public void setLogSessionId(LogSessionId logSessionId) {
    delegate.setLogSessionId(logSessionId);
  }

  /** Returns the {@link LogSessionId} for MediaExtractorCompat. */
  @RequiresApi(31)
  public LogSessionId getLogSessionId() {
    return delegate.getLogSessionId();
  }

  /**
   * Extracts the DRM initialization data from the available tracks, if it exists.
   *
   * @return The {@link DrmInitData} in the content, or {@code null} if no recognizable DRM format
   *     is found.
   */
  @Nullable
  public DrmInitData getDrmInitData() {
    return delegate.getDrmInitData();
  }

  /**
   * Returns an estimate of how much data is presently cached in memory, expressed in microseconds,
   * or -1 if this information is unavailable or not applicable (i.e., no cache exists).
   */
  public long getCachedDuration() {
    return delegate.getCachedDuration();
  }

  /**
   * Returns {@code true} if data is being cached and the cache has reached the end of the data
   * stream. This indicates that no additional data is currently available for caching, although a
   * future seek may restart data fetching. This method only returns a meaningful result if {@link
   * #getCachedDuration} indicates the presence of a cache (i.e., does not return -1).
   */
  public boolean hasCacheReachedEndOfStream() {
    return delegate.hasCacheReachedEndOfStream();
  }

  /**
   * Returns a {@link PersistableBundle} containing metrics data for the current media container.
   *
   * <p>The bundle includes attributes and values for the media container, as described in {@link
   * MediaExtractor.MetricsConstants}.
   */
  @RequiresApi(26)
  public PersistableBundle getMetrics() {
    return delegate.getMetrics();
  }

  /**
   * Extracts PSSH data from the media, if present.
   *
   * @return A {@link Map} of UUID-to-byte[] pairs, where the {@link UUID} identifies the crypto
   *     scheme, and the byte array contains the scheme-specific data. Returns {@code null} if no
   *     PSSH data exists.
   */
  @Nullable
  public Map<UUID, byte[]> getPsshInfo() {
    return delegate.getPsshInfo();
  }

  @VisibleForTesting(otherwise = NONE)
  public Allocator getAllocator() {
    return delegate.getAllocator();
  }

  /**
   * A {@link DataSource} that supports only the URI schemes handled by framework {@link
   * MediaExtractor} when no {@link Context} is provided (local files and HTTP/HTTPS streams).
   */
  private static final class MediaExtractorDataSource implements DataSource {

    private static final DataSource.Factory FACTORY = MediaExtractorDataSource::new;

    @Nullable private DataSource fileDataSource;
    @Nullable private DataSource httpDataSource;
    @Nullable private DataSource currentDataSource;

    @Override
    public void addTransferListener(TransferListener transferListener) {
      // Do nothing: MediaExtractorCompatInternal never registers a TransferListener.
    }

    @Override
    public long open(DataSpec dataSpec) throws IOException {
      checkState(currentDataSource == null);
      String scheme = dataSpec.uri.getScheme();
      if (Util.isLocalFileUri(dataSpec.uri)) {
        String uriPath = dataSpec.uri.getPath();
        if (uriPath != null && uriPath.startsWith("/android_asset/")) {
          throw new IOException("Asset URIs require a Context: " + dataSpec.uri);
        }
        if (fileDataSource == null) {
          fileDataSource = new FileDataSource();
        }
        currentDataSource = fileDataSource;
      } else if (scheme != null
          && (Ascii.equalsIgnoreCase(scheme, "http") || Ascii.equalsIgnoreCase(scheme, "https"))) {
        if (httpDataSource == null) {
          httpDataSource = new DefaultHttpDataSource.Factory().createDataSource();
        }
        currentDataSource = httpDataSource;
      } else {
        throw new IOException("Unsupported URI scheme without a Context: " + scheme);
      }
      return currentDataSource.open(dataSpec);
    }

    @Override
    public int read(byte[] buffer, int offset, int length) throws IOException {
      return checkNotNull(currentDataSource).read(buffer, offset, length);
    }

    @Override
    @Nullable
    public Uri getUri() {
      return currentDataSource == null ? null : currentDataSource.getUri();
    }

    @Override
    public Map<String, List<String>> getResponseHeaders() {
      return currentDataSource == null ? ImmutableMap.of() : currentDataSource.getResponseHeaders();
    }

    @Override
    public void close() throws IOException {
      if (currentDataSource != null) {
        try {
          currentDataSource.close();
        } finally {
          currentDataSource = null;
        }
      }
    }
  }
}
