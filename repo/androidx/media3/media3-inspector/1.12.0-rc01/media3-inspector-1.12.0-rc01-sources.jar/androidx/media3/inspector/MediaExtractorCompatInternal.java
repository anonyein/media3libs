/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.inspector;

import static android.os.Build.VERSION.SDK_INT;
import static androidx.media3.exoplayer.source.SampleStream.FLAG_OMIT_SAMPLE_DATA;
import static androidx.media3.exoplayer.source.SampleStream.FLAG_PEEK;
import static androidx.media3.exoplayer.source.SampleStream.FLAG_REQUIRE_FORMAT;
import static androidx.media3.inspector.MediaExtractorCompat.SEEK_TO_CLOSEST_SYNC;
import static androidx.media3.inspector.MediaExtractorCompat.SEEK_TO_NEXT_SYNC;
import static androidx.media3.inspector.MediaExtractorCompat.SEEK_TO_PREVIOUS_SYNC;
import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.base.Preconditions.checkState;
import static java.lang.Math.max;

import android.content.ContentResolver;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.MediaCodec;
import android.media.MediaDataSource;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.metrics.LogSessionId;
import android.net.Uri;
import android.os.PersistableBundle;
import android.system.ErrnoException;
import android.system.Os;
import android.util.Pair;
import android.util.SparseArray;
import androidx.annotation.RequiresApi;
import androidx.media3.common.C;
import androidx.media3.common.DrmInitData;
import androidx.media3.common.Format;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.ParserException;
import androidx.media3.common.util.CodecSpecificDataUtil;
import androidx.media3.common.util.Log;
import androidx.media3.common.util.MediaFormatUtil;
import androidx.media3.common.util.Util;
import androidx.media3.datasource.DataSource;
import androidx.media3.datasource.DataSourceUtil;
import androidx.media3.datasource.DataSpec;
import androidx.media3.datasource.FileDescriptorDataSource;
import androidx.media3.datasource.MediaDataSourceAdapter;
import androidx.media3.decoder.CryptoInfo;
import androidx.media3.decoder.DecoderInputBuffer;
import androidx.media3.exoplayer.FormatHolder;
import androidx.media3.exoplayer.mediacodec.MediaCodecUtil;
import androidx.media3.exoplayer.source.ProgressiveMediaExtractor;
import androidx.media3.exoplayer.source.SampleQueue;
import androidx.media3.exoplayer.source.SampleStream.ReadDataResult;
import androidx.media3.exoplayer.source.UnrecognizedInputFormatException;
import androidx.media3.exoplayer.upstream.Allocator;
import androidx.media3.exoplayer.upstream.DefaultAllocator;
import androidx.media3.extractor.DiscardingTrackOutput;
import androidx.media3.extractor.Extractor;
import androidx.media3.extractor.Extractor.ReadResult;
import androidx.media3.extractor.ExtractorOutput;
import androidx.media3.extractor.PositionHolder;
import androidx.media3.extractor.SeekMap;
import androidx.media3.extractor.SeekMap.SeekPoints;
import androidx.media3.extractor.SeekPoint;
import androidx.media3.extractor.TrackAwareSeekMap;
import androidx.media3.extractor.TrackOutput;
import androidx.media3.extractor.mp4.PsshAtomUtil;
import java.io.FileDescriptor;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.checkerframework.checker.nullness.qual.EnsuresNonNullIf;
import org.jspecify.annotations.Nullable;

/** Implements the internal behavior of {@code MediaExtractorCompat}. */
/* package */ final class MediaExtractorCompatInternal {

  /**
   * A default duration added to the largest queued sample timestamp to provide a more realistic
   * estimate of the cached duration. Since the duration of the last sample is unknown, this value
   * prevents the duration of the last sample from being assumed as zero, which would otherwise make
   * the estimated duration appear shorter than it actually is.
   */
  private static final long DEFAULT_LAST_SAMPLE_DURATION_US = 10_000;

  private static final String TAG = "MediaExtractorCompatInt";

  private final ProgressiveMediaExtractor progressiveMediaExtractor;
  private final DataSource.Factory dataSourceFactory;
  private final PositionHolder positionHolder;
  private final Allocator allocator;
  private final ArrayList<MediaExtractorTrack> tracks;
  private final SparseArray<MediaExtractorSampleQueue> sampleQueues;
  private final SampleMetadataQueue sampleMetadataQueue;
  private final FormatHolder formatHolder;
  private final DecoderInputBuffer sampleHolderWithBufferReplacementDisabled;
  private final Set<Integer> selectedTrackIndices;

  private boolean hasBeenPrepared;
  private long offsetInCurrentFile;
  private @Nullable DataSource currentDataSource;
  private @Nullable FileDescriptor duplicatedFileDescriptor;
  private @Nullable SeekPoint pendingSeek;
  private boolean hasReachedEndOfInput;

  private @Nullable SeekMap seekMap;
  private boolean tracksEnded;
  private int upstreamFormatsCount;
  private @Nullable Map<String, String> httpRequestHeaders;
  private @Nullable LogSessionId logSessionId;

  /**
   * Creates a new instance using the given {@link ProgressiveMediaExtractor} to obtain media
   * samples from a {@link DataSource} generated by the given {@link DataSource.Factory}.
   *
   * <p>Note: The {@link DataSource.Factory} provided will not be used to generate {@link
   * DataSource} when setting data source using methods:
   *
   * <ul>
   *   <li>{@link #setDataSource(AssetFileDescriptor)}
   *   <li>{@link #setDataSource(FileDescriptor)}
   *   <li>{@link #setDataSource(FileDescriptor, long, long)}
   * </ul>
   *
   * <p>Note: The {@link DataSource.Factory} provided may not be used to generate {@link DataSource}
   * when setting data source using method {@link #setDataSource(Context, Uri, Map)} as the behavior
   * depends on the fallthrough logic related to the scheme of the provided URI.
   */
  /* package */ MediaExtractorCompatInternal(
      ProgressiveMediaExtractor progressiveMediaExtractor, DataSource.Factory dataSourceFactory) {
    this.progressiveMediaExtractor = progressiveMediaExtractor;
    this.dataSourceFactory = dataSourceFactory;
    positionHolder = new PositionHolder();
    allocator = new DefaultAllocator(/* trimOnReset= */ true, C.DEFAULT_BUFFER_SEGMENT_SIZE);
    tracks = new ArrayList<>();
    sampleQueues = new SparseArray<>();
    sampleMetadataQueue = new SampleMetadataQueue();
    formatHolder = new FormatHolder();
    sampleHolderWithBufferReplacementDisabled = DecoderInputBuffer.newNoDataInstance();
    selectedTrackIndices = new HashSet<>();
  }

  /**
   * Sets the data source using the media stream obtained from the given {@link Uri} at the given
   * {@code offset}.
   *
   * @param uri The content {@link Uri} to extract from.
   * @param offset The offset into the file where the data to be extracted starts, in bytes.
   * @throws IOException If an error occurs while extracting the media.
   * @throws UnrecognizedInputFormatException If none of the available extractors successfully
   *     sniffs the input.
   * @throws IllegalStateException If this method is called twice on the same instance.
   */
  /* package */ void setDataSource(Uri uri, long offset) throws IOException {
    prepareDataSource(
        dataSourceFactory.createDataSource(), buildDataSpec(uri, /* position= */ offset));
  }

  /**
   * Sets the data source using the media stream obtained from the provided {@link
   * AssetFileDescriptor}.
   *
   * <p>Note: The caller is responsible for closing the {@link AssetFileDescriptor}. It is safe to
   * do so immediately after this method returns.
   *
   * @param assetFileDescriptor The {@link AssetFileDescriptor} for the file to extract from.
   * @throws IOException If an error occurs while extracting the media.
   * @throws UnrecognizedInputFormatException If none of the available extractors successfully
   *     sniffs the input.
   * @throws IllegalStateException If this method is called twice on the same instance.
   */
  /* package */ void setDataSource(AssetFileDescriptor assetFileDescriptor) throws IOException {
    // Using getDeclaredLength() to match platform behavior, even though it may result in reading
    // across multiple logical files when they share the same physical file.
    // Reference implementation in platform MediaExtractor:
    // https://cs.android.com/android/platform/superproject/main/+/main:frameworks/base/media/java/android/media/MediaExtractor.java;l=219-226;drc=3181772b27c6bf3e9625677d1d8afc89d938a60e
    if (assetFileDescriptor.getDeclaredLength() == AssetFileDescriptor.UNKNOWN_LENGTH) {
      setDataSource(assetFileDescriptor.getFileDescriptor());
    } else {
      setDataSource(
          assetFileDescriptor.getFileDescriptor(),
          assetFileDescriptor.getStartOffset(),
          assetFileDescriptor.getDeclaredLength());
    }
  }

  /**
   * Sets the data source using the media stream obtained from the provided {@link FileDescriptor}.
   *
   * <p>Note: The caller is responsible for closing the {@link FileDescriptor}. It is safe to do so
   * immediately after this method returns.
   *
   * @param fileDescriptor The {@link FileDescriptor} for the file to extract from.
   * @throws IOException If an error occurs while extracting the media.
   * @throws UnrecognizedInputFormatException If none of the available extractors successfully
   *     sniffs the input.
   * @throws IllegalStateException If this method is called twice on the same instance.
   */
  /* package */ void setDataSource(FileDescriptor fileDescriptor) throws IOException {
    setDataSource(fileDescriptor, /* offset= */ 0, /* length= */ C.LENGTH_UNSET);
  }

  /**
   * Sets the data source using the media stream obtained from the provided {@link FileDescriptor},
   * with a specified {@code offset} and {@code length}.
   *
   * <p>Note: The caller is responsible for closing the {@link FileDescriptor}. It is safe to do so
   * immediately after this method returns.
   *
   * @param fileDescriptor The {@link FileDescriptor} for the file to extract from.
   * @param offset The offset into the file where the data to be extracted starts, in bytes.
   * @param length The length of the data to be extracted, in bytes, or {@link C#LENGTH_UNSET} if it
   *     is unknown.
   * @throws IOException If an error occurs while extracting the media.
   * @throws UnrecognizedInputFormatException If none of the available extractors successfully
   *     sniffs the input.
   * @throws IllegalStateException If this method is called twice on the same instance.
   */
  /* package */ void setDataSource(FileDescriptor fileDescriptor, long offset, long length)
      throws IOException {
    checkState(!hasBeenPrepared);
    try {
      duplicatedFileDescriptor = Os.dup(fileDescriptor);
    } catch (ErrnoException e) {
      throw new IOException("Failed to duplicate FileDescriptor.", e);
    }
    FileDescriptorDataSource fileDescriptorDataSource =
        new FileDescriptorDataSource(duplicatedFileDescriptor, offset, length);
    prepareDataSource(fileDescriptorDataSource, buildDataSpec(Uri.EMPTY, /* position= */ 0));
  }

  /**
   * Sets the data source using the media stream obtained from the given {@linkplain Uri content
   * URI} and optional HTTP request headers.
   *
   * @param context The {@link Context} used to resolve the {@link Uri}.
   * @param uri The {@linkplain Uri content URI} of the media to extract from.
   * @param headers An optional {@link Map} of HTTP request headers to include when fetching the
   *     data, or {@code null} if no headers are to be included.
   * @throws IOException If an error occurs while extracting the media.
   * @throws UnrecognizedInputFormatException If none of the available extractors successfully
   *     sniffs the input.
   * @throws IllegalStateException If this method is called twice on the same instance.
   */
  /* package */ void setDataSource(Context context, Uri uri, @Nullable Map<String, String> headers)
      throws IOException {
    if (Util.isLocalFileUri(uri)) {
      setDataSource(checkNotNull(uri.getPath()));
      return;
    }

    ContentResolver resolver = context.getContentResolver();
    try (AssetFileDescriptor assetFileDescriptor = resolver.openAssetFileDescriptor(uri, "r")) {
      if (assetFileDescriptor != null) {
        // If the URI points to a content provider resource, use the AssetFileDescriptor
        setDataSource(assetFileDescriptor);
        return;
      }
    } catch (SecurityException | FileNotFoundException e) {
      // Fall back to using the URI as a string if the file is not found or the mode is invalid
    }

    // Assume the URI is an HTTP URL and use it with optional headers
    setDataSource(uri.toString(), headers);
  }

  /**
   * Sets the data source using the media stream obtained from the given file path or HTTP URL.
   *
   * @param path The path of the file, or the HTTP URL, to extract media from.
   * @throws IOException If an error occurs while extracting the media.
   * @throws UnrecognizedInputFormatException If none of the available extractors successfully
   *     sniffs the input.
   * @throws IllegalStateException If this method is called twice on the same instance.
   */
  /* package */ void setDataSource(String path) throws IOException {
    setDataSource(path, /* headers= */ null);
  }

  /**
   * Sets the data source using the media stream obtained from the given file path or HTTP URL, with
   * optional HTTP request headers.
   *
   * @param path The path of the file, or the HTTP URL, to extract media from.
   * @param headers An optional {@link Map} of HTTP request headers to include when fetching the
   *     data, or {@code null} if no headers are to be included.
   * @throws IOException If an error occurs while extracting the media.
   * @throws UnrecognizedInputFormatException If none of the available extractors successfully
   *     sniffs the input.
   * @throws IllegalStateException If this method is called twice on the same instance.
   */
  /* package */ void setDataSource(String path, @Nullable Map<String, String> headers)
      throws IOException {
    httpRequestHeaders = headers;
    prepareDataSource(
        dataSourceFactory.createDataSource(), buildDataSpec(Uri.parse(path), /* position= */ 0));
  }

  /**
   * Sets the data source using the media stream obtained from the given {@link MediaDataSource}.
   *
   * @param mediaDataSource The {@link MediaDataSource} to extract media from.
   * @throws IOException If an error occurs while extracting the media.
   * @throws UnrecognizedInputFormatException If none of the available extractors successfully
   *     sniffs the input.
   * @throws IllegalStateException If this method is called twice on the same instance.
   */
  /* package */ void setDataSource(MediaDataSource mediaDataSource) throws IOException {
    // MediaDataSourceAdapter is created privately here, so TransferListeners cannot be registered.
    // Therefore, the isNetwork parameter is hardcoded to false as it has no effect.
    MediaDataSourceAdapter mediaDataSourceAdapter =
        new MediaDataSourceAdapter(mediaDataSource, /* isNetwork= */ false);
    prepareDataSource(mediaDataSourceAdapter, buildDataSpec(Uri.EMPTY, /* position= */ 0));
  }

  private void prepareDataSource(DataSource dataSource, DataSpec dataSpec) throws IOException {
    // Assert that this instance is not being re-prepared, which is not currently supported.
    checkState(!hasBeenPrepared);
    hasBeenPrepared = true;
    offsetInCurrentFile = dataSpec.position;
    currentDataSource = dataSource;

    try {
      long length = currentDataSource.open(dataSpec);
      progressiveMediaExtractor.init(
          currentDataSource,
          checkNotNull(currentDataSource.getUri()),
          currentDataSource.getResponseHeaders(),
          /* position= */ 0,
          length,
          new ExtractorOutputImpl());

      boolean preparing = true;
      Throwable error = null;
      while (preparing) {
        int result;
        try {
          result = progressiveMediaExtractor.read(positionHolder);
        } catch (Exception | OutOfMemoryError e) {
          // This value is ignored but initializes result to avoid static analysis errors.
          result = Extractor.RESULT_END_OF_INPUT;
          error = e;
        }
        preparing = !tracksEnded || upstreamFormatsCount < sampleQueues.size() || seekMap == null;
        if (error != null || (preparing && result == Extractor.RESULT_END_OF_INPUT)) {
          // TODO(b/178501820): Support files with incomplete track information.
          String message =
              error != null
                  ? "Exception encountered while parsing input media."
                  : "Reached end of input before preparation completed.";
          throw ParserException.createForMalformedContainer(message, /* cause= */ error);
        } else if (result == Extractor.RESULT_SEEK) {
          reopenCurrentDataSource(positionHolder.position);
        } else if (result == Extractor.RESULT_END_OF_INPUT) {
          hasReachedEndOfInput = true;
        }
      }
    } catch (Exception | OutOfMemoryError e) {
      release(); // Release resources as soon as possible, in case we are low on memory.
      throw e;
    }
    // At this point, we know how many tracks we have, and their format.
  }

  /**
   * Releases any resources held by this instance.
   *
   * <p>Note: Make sure you call this when you're done to free up any resources instead of relying
   * on the garbage collector to do this for you at some point in the future.
   */
  /* package */ void release() {
    for (int i = 0; i < sampleQueues.size(); i++) {
      sampleQueues.valueAt(i).release();
    }
    sampleQueues.clear();
    tracks.clear();
    sampleMetadataQueue.release();
    selectedTrackIndices.clear();
    formatHolder.clear();
    sampleHolderWithBufferReplacementDisabled.clear();
    sampleHolderWithBufferReplacementDisabled.data = null;
    sampleHolderWithBufferReplacementDisabled.supplementalData = null;
    progressiveMediaExtractor.release();
    seekMap = null;
    pendingSeek = null;
    httpRequestHeaders = null;
    DataSourceUtil.closeQuietly(currentDataSource);
    currentDataSource = null;
    if (duplicatedFileDescriptor != null) {
      try {
        Os.close(duplicatedFileDescriptor);
      } catch (ErrnoException e) {
        Log.e(TAG, "Failed to close duplicated file descriptor.", e);
      }
      duplicatedFileDescriptor = null;
    }
  }

  /** Returns the number of tracks found in the data source. */
  /* package */ int getTrackCount() {
    return tracks.size();
  }

  /** Returns the track {@link MediaFormat} at the specified {@code trackIndex}. */
  /* package */ MediaFormat getTrackFormat(int trackIndex) {
    checkTrackIndex(trackIndex);
    MediaExtractorTrack track = tracks.get(trackIndex);
    MediaFormat mediaFormat =
        track.createDownstreamMediaFormat(formatHolder, sampleHolderWithBufferReplacementDisabled);
    long trackDurationUs = track.sampleQueue.trackDurationUs;
    if (trackDurationUs != C.TIME_UNSET) {
      mediaFormat.setLong(MediaFormat.KEY_DURATION, trackDurationUs);
    } else if (seekMap != null && seekMap.getDurationUs() != C.TIME_UNSET) {
      mediaFormat.setLong(MediaFormat.KEY_DURATION, seekMap.getDurationUs());
    }
    return mediaFormat;
  }

  /**
   * Selects a track at the specified {@code trackIndex}.
   *
   * <p>Subsequent calls to {@link #readSampleData}, {@link #getSampleTrackIndex} and {@link
   * #getSampleTime} only retrieve information for the subset of tracks selected.
   *
   * <p>Note: Selecting the same track multiple times has no effect, the track is only selected
   * once.
   */
  /* package */ void selectTrack(int trackIndex) {
    checkTrackIndex(trackIndex);
    selectedTrackIndices.add(trackIndex);
  }

  /**
   * Unselects the track at the specified {@code trackIndex}.
   *
   * <p>Subsequent calls to {@link #readSampleData}, {@link #getSampleTrackIndex} and {@link
   * #getSampleTime} only retrieve information for the subset of tracks selected.
   */
  /* package */ void unselectTrack(int trackIndex) {
    checkTrackIndex(trackIndex);
    selectedTrackIndices.remove(trackIndex);
  }

  private void checkTrackIndex(int trackIndex) {
    checkArgument(trackIndex >= 0 && trackIndex < tracks.size(), "Invalid track index");
  }

  /**
   * All selected tracks seek near the requested {@code timeUs} according to the specified {@code
   * mode}.
   */
  /* package */ void seekTo(long timeUs, @MediaExtractorCompat.SeekMode int mode) {
    if (seekMap == null || selectedTrackIndices.isEmpty()) {
      return;
    }

    SeekPoints seekPoints;
    if (selectedTrackIndices.size() == 1 && seekMap instanceof TrackAwareSeekMap) {
      TrackAwareSeekMap trackAwareSeekMap = (TrackAwareSeekMap) seekMap;
      int trackId = tracks.get(selectedTrackIndices.iterator().next()).getIdOfBackingTrack();
      if (trackAwareSeekMap.isSeekable(trackId)) {
        seekPoints = trackAwareSeekMap.getSeekPoints(timeUs, trackId);
      } else {
        seekPoints = trackAwareSeekMap.getSeekPoints(timeUs);
      }
    } else {
      seekPoints = seekMap.getSeekPoints(timeUs);
    }
    SeekPoint seekPoint;
    switch (mode) {
      case SEEK_TO_CLOSEST_SYNC:
        seekPoint =
            Math.abs(timeUs - seekPoints.second.timeUs)
                    <= Math.abs(timeUs - seekPoints.first.timeUs)
                ? seekPoints.second
                : seekPoints.first;
        break;
      case SEEK_TO_NEXT_SYNC:
        seekPoint = seekPoints.second;
        break;
      case SEEK_TO_PREVIOUS_SYNC:
        seekPoint = seekPoints.first;
        break;
      default:
        // Should never happen.
        throw new IllegalArgumentException();
    }
    sampleMetadataQueue.clear();
    for (int i = 0; i < sampleQueues.size(); i++) {
      sampleQueues.valueAt(i).reset();
    }
    pendingSeek = seekPoint;
    hasReachedEndOfInput = false;
  }

  /**
   * Advances to the next sample. Returns {@code false} if no more sample data is available (i.e.,
   * end of stream), or {@code true} otherwise.
   *
   * <p>Note: When extracting from a local file, the behavior of {@link #advance} and {@link
   * #readSampleData} is undefined if there are concurrent writes to the same file. This may result
   * in an unexpected end of stream being signaled.
   */
  /* package */ boolean advance() {
    // Ensure there is a sample to discard.
    if (!advanceToSampleOrEndOfInput()) {
      // The end of input has been reached.
      return false;
    }
    skipOneSample();
    return advanceToSampleOrEndOfInput();
  }

  /**
   * Retrieves the current encoded sample and stores it in the byte {@code buffer} starting at the
   * given {@code offset}.
   *
   * <p><b>Note:</b>On success, the position and limit of {@code buffer} is updated to point to the
   * data just read.
   *
   * @param buffer the destination byte buffer.
   * @param offset The offset into the byte buffer at which to write.
   * @return the sample size, or -1 if no more samples are available.
   */
  /* package */ int readSampleData(ByteBuffer buffer, int offset) {
    if (!advanceToSampleOrEndOfInput()) {
      return -1;
    }
    // The platform media extractor implementation ignores the buffer's input position and limit.
    buffer.limit(buffer.capacity());
    buffer.position(offset);
    sampleHolderWithBufferReplacementDisabled.data = buffer;
    try {
      peekNextSelectedTrackSample(
          sampleHolderWithBufferReplacementDisabled, /* omitSampleData= */ false);
    } finally {
      sampleHolderWithBufferReplacementDisabled.data = null;
    }
    buffer.flip();
    buffer.position(offset);
    return buffer.remaining();
  }

  /**
   * Returns the track index the current sample originates from, or -1 if no more samples are
   * available.
   */
  /* package */ int getSampleTrackIndex() {
    if (!advanceToSampleOrEndOfInput()) {
      return -1;
    }
    return sampleMetadataQueue.peekFirst().trackIndex;
  }

  /** Returns the current sample's size in bytes, or -1 if no more samples are available. */
  /* package */ long getSampleSize() {
    if (!advanceToSampleOrEndOfInput()) {
      return -1;
    }
    MediaExtractorTrack trackOfSample =
        tracks.get(checkNotNull(sampleMetadataQueue.peekFirst()).trackIndex);
    return trackOfSample.sampleQueue.peekNextSampleSize();
  }

  /**
   * Returns the current sample's presentation time in microseconds, or -1 if no more samples are
   * available.
   */
  /* package */ long getSampleTime() {
    if (!advanceToSampleOrEndOfInput()) {
      return -1;
    }
    return sampleMetadataQueue.peekFirst().timeUs;
  }

  /** Returns the current sample's flags. */
  /* package */ int getSampleFlags() {
    if (!advanceToSampleOrEndOfInput()) {
      return -1;
    }
    return sampleMetadataQueue.peekFirst().flags;
  }

  /**
   * Returns {@code true} if the current sample is at least partially encrypted and fills the
   * provided {@link MediaCodec.CryptoInfo} structure with relevant decryption information.
   *
   * @param info The {@link MediaCodec.CryptoInfo} structure to be filled with decryption data.
   * @return {@code true} if the sample is at least partially encrypted, {@code false} otherwise.
   */
  /* package */ boolean getSampleCryptoInfo(MediaCodec.CryptoInfo info) {
    if (!advanceToSampleOrEndOfInput()) {
      return false;
    }
    boolean isEncrypted =
        (sampleMetadataQueue.peekFirst().flags & MediaExtractor.SAMPLE_FLAG_ENCRYPTED) != 0;
    if (!isEncrypted) {
      return false;
    }
    try {
      peekNextSelectedTrackSample(
          sampleHolderWithBufferReplacementDisabled, /* omitSampleData= */ true);
      populatePlatformCryptoInfoParameters(info);
    } finally {
      sampleHolderWithBufferReplacementDisabled.clear();
    }
    return true;
  }

  private void populatePlatformCryptoInfoParameters(MediaCodec.CryptoInfo info) {
    CryptoInfo cryptoInfo = checkNotNull(sampleHolderWithBufferReplacementDisabled.cryptoInfo);
    int numSubSamples = cryptoInfo.numSubSamples;
    info.set(
        numSubSamples,
        Arrays.copyOf(checkNotNull(cryptoInfo.numBytesOfClearData), numSubSamples),
        Arrays.copyOf(checkNotNull(cryptoInfo.numBytesOfEncryptedData), numSubSamples),
        checkNotNull(cryptoInfo.key).clone(),
        checkNotNull(cryptoInfo.iv).clone(),
        cryptoInfo.mode);
    info.setPattern(
        new MediaCodec.CryptoInfo.Pattern(cryptoInfo.encryptedBlocks, cryptoInfo.clearBlocks));
  }

  /** Sets the {@link LogSessionId} for MediaExtractorCompat. */
  @RequiresApi(31)
  /* package */ void setLogSessionId(LogSessionId logSessionId) {
    if (!logSessionId.equals(LogSessionId.LOG_SESSION_ID_NONE)) {
      this.logSessionId = logSessionId;
    }
  }

  /** Returns the {@link LogSessionId} for MediaExtractorCompat. */
  @RequiresApi(31)
  /* package */ LogSessionId getLogSessionId() {
    return logSessionId != null ? logSessionId : LogSessionId.LOG_SESSION_ID_NONE;
  }

  /**
   * Extracts the DRM initialization data from the available tracks, if it exists.
   *
   * @return The {@link DrmInitData} in the content, or {@code null} if no recognizable DRM format
   *     is found.
   */
  /* package */ @Nullable DrmInitData getDrmInitData() {
    for (int i = 0; i < tracks.size(); i++) {
      Format format =
          tracks.get(i).getFormat(formatHolder, sampleHolderWithBufferReplacementDisabled);
      if (format.drmInitData == null) {
        continue;
      }
      return format.drmInitData;
    }
    return null;
  }

  /**
   * Returns an estimate of how much data is presently cached in memory, expressed in microseconds,
   * or -1 if this information is unavailable or not applicable (i.e., no cache exists).
   */
  /* package */ long getCachedDuration() {
    if (!advanceToSampleOrEndOfInput()) {
      return 0;
    }

    long largestReadTimestampUs = Long.MIN_VALUE;
    long largestQueuedTimestampUs = Long.MIN_VALUE;
    for (int i = 0; i < tracks.size(); i++) {
      MediaExtractorSampleQueue mediaExtractorSampleQueue = tracks.get(i).sampleQueue;

      largestReadTimestampUs =
          max(largestReadTimestampUs, mediaExtractorSampleQueue.getLargestReadTimestampUs());
      largestQueuedTimestampUs =
          max(largestQueuedTimestampUs, mediaExtractorSampleQueue.getLargestQueuedTimestampUs());
    }

    checkState(largestQueuedTimestampUs != Long.MIN_VALUE);
    if (largestReadTimestampUs == largestQueuedTimestampUs) {
      return 0;
    }

    if (largestReadTimestampUs == Long.MIN_VALUE) {
      largestReadTimestampUs = 0;
    }
    return largestQueuedTimestampUs - largestReadTimestampUs + DEFAULT_LAST_SAMPLE_DURATION_US;
  }

  /**
   * Returns {@code true} if data is being cached and the cache has reached the end of the data
   * stream. This indicates that no additional data is currently available for caching, although a
   * future seek may restart data fetching. This method only returns a meaningful result if {@link
   * #getCachedDuration} indicates the presence of a cache (i.e., does not return -1).
   */
  /* package */ boolean hasCacheReachedEndOfStream() {
    return getCachedDuration() == 0;
  }

  /**
   * Returns a {@link PersistableBundle} containing metrics data for the current media container.
   *
   * <p>The bundle includes attributes and values for the media container, as described in {@link
   * MediaExtractor.MetricsConstants}.
   */
  @RequiresApi(26)
  /* package */ PersistableBundle getMetrics() {
    PersistableBundle bundle = new PersistableBundle();
    String formatName = progressiveMediaExtractor.getUnderlyingImplementationName();
    if (formatName != null) {
      bundle.putString(MediaExtractor.MetricsConstants.FORMAT, formatName);
    }
    if (!tracks.isEmpty()) {
      Format format =
          tracks.get(0).getFormat(formatHolder, sampleHolderWithBufferReplacementDisabled);
      if (format.containerMimeType != null) {
        bundle.putString(MediaExtractor.MetricsConstants.MIME_TYPE, format.containerMimeType);
      }
    }
    bundle.putInt(MediaExtractor.MetricsConstants.TRACKS, tracks.size());
    return bundle;
  }

  /**
   * Extracts PSSH data from the media, if present.
   *
   * @return A {@link Map} of UUID-to-byte[] pairs, where the {@link UUID} identifies the crypto
   *     scheme, and the byte array contains the scheme-specific data. Returns {@code null} if no
   *     PSSH data exists.
   */
  /* package */ @Nullable Map<UUID, byte[]> getPsshInfo() {
    @Nullable DrmInitData drmInitData = getDrmInitData();
    if (drmInitData == null) {
      return null;
    }

    Map<UUID, byte[]> psshDataMap = new HashMap<>();
    for (int i = 0; i < drmInitData.schemeDataCount; i++) {
      DrmInitData.SchemeData schemeData = drmInitData.get(i);
      if (schemeData.data == null) {
        continue;
      }

      PsshAtomUtil.@Nullable PsshAtom parsedPsshAtom = PsshAtomUtil.parsePsshAtom(schemeData.data);
      if (parsedPsshAtom != null) {
        psshDataMap.put(parsedPsshAtom.uuid, parsedPsshAtom.schemeData);
      }
    }

    return psshDataMap.isEmpty() ? null : psshDataMap;
  }

  /* package */ Allocator getAllocator() {
    return allocator;
  }

  /**
   * Peeks a sample from the front of the given {@link SampleQueue}, discarding the downstream
   * {@link Format} first, if necessary.
   *
   * @param decoderInputBuffer The buffer to populate.
   * @throws IllegalStateException If a sample is not peeked as a result of calling this method.
   */
  private void peekNextSelectedTrackSample(
      DecoderInputBuffer decoderInputBuffer, boolean omitSampleData) {
    MediaExtractorTrack trackOfSample =
        tracks.get(checkNotNull(sampleMetadataQueue.peekFirst()).trackIndex);
    SampleQueue sampleQueue = trackOfSample.sampleQueue;
    @ReadDataResult
    int result =
        sampleQueue.read(
            formatHolder,
            decoderInputBuffer,
            FLAG_PEEK | (omitSampleData ? FLAG_OMIT_SAMPLE_DATA : 0),
            /* loadingFinished= */ false);
    if (result == C.RESULT_FORMAT_READ) {
      // We've consumed a downstream format. Now consume the actual sample.
      result =
          sampleQueue.read(
              formatHolder,
              decoderInputBuffer,
              FLAG_PEEK | (omitSampleData ? FLAG_OMIT_SAMPLE_DATA : 0),
              /* loadingFinished= */ false);
    }
    formatHolder.clear();
    // This method must only be called when there is a sample available for reading.
    checkState(result == C.RESULT_BUFFER_READ);
  }

  /**
   * Advances extraction until there is a queued sample from a selected track, or the end of the
   * input is found.
   *
   * <p>Handles I/O errors (for example, network connection loss) and parsing errors (for example, a
   * truncated file) in the same way as {@link MediaExtractor}, treating them as the end of input.
   *
   * @return Whether a sample from a selected track is available.
   */
  @EnsuresNonNullIf(expression = "sampleMetadataQueue.peekFirst()", result = true)
  private boolean advanceToSampleOrEndOfInput() {
    if (selectedTrackIndices.isEmpty()) {
      return false;
    }
    try {
      maybeResolvePendingSeek();
    } catch (IOException e) {
      Log.w(TAG, "Treating exception as the end of input.", e);
      return false;
    }

    while (true) {
      if (!sampleMetadataQueue.isEmpty()) {
        // By default, tracks are unselected.
        if (selectedTrackIndices.contains(
            checkNotNull(sampleMetadataQueue.peekFirst()).trackIndex)) {
          return true;
        } else {
          // There is a queued sample, but its track is unselected. We skip the sample.
          skipOneSample();
        }
      } else if (!hasReachedEndOfInput) {
        // There are no queued samples for the selected tracks, but we can feed more data to the
        // extractor and see if more samples are produced.
        try {
          @ReadResult int result = progressiveMediaExtractor.read(positionHolder);
          if (result == Extractor.RESULT_END_OF_INPUT) {
            hasReachedEndOfInput = true;
          } else if (result == Extractor.RESULT_SEEK) {
            reopenCurrentDataSource(positionHolder.position);
          }
        } catch (Exception | OutOfMemoryError e) {
          Log.w(TAG, "Treating exception as the end of input.", e);
          hasReachedEndOfInput = true;
        }
      } else {
        // No queued samples for selected tracks, and we've parsed all the file. Nothing else to do.
        return false;
      }
    }
  }

  private void skipOneSample() {
    int trackIndex = sampleMetadataQueue.removeFirst().trackIndex;
    MediaExtractorTrack track = tracks.get(trackIndex);
    if (!track.isCompatibilityTrack) {
      // We also need to skip the sample data.
      track.discardFrontSample();
    }
  }

  private void reopenCurrentDataSource(long newPositionInStream) throws IOException {
    DataSource currentDataSource = checkNotNull(this.currentDataSource);
    Uri currentUri = checkNotNull(currentDataSource.getUri());
    DataSourceUtil.closeQuietly(currentDataSource);
    long length =
        currentDataSource.open(
            buildDataSpec(currentUri, offsetInCurrentFile + newPositionInStream));
    if (length != C.LENGTH_UNSET) {
      length += newPositionInStream;
    }
    progressiveMediaExtractor.init(
        currentDataSource,
        currentUri,
        currentDataSource.getResponseHeaders(),
        newPositionInStream,
        length,
        new ExtractorOutputImpl());
  }

  private void onSampleQueueFormatInitialized(
      MediaExtractorSampleQueue mediaExtractorSampleQueue, Format newUpstreamFormat) {
    upstreamFormatsCount++;
    mediaExtractorSampleQueue.setMainTrackIndex(tracks.size());
    tracks.add(
        new MediaExtractorTrack(
            mediaExtractorSampleQueue,
            /* isCompatibilityTrack= */ false,
            /* compatibilityTrackMimeType= */ null));
    @Nullable String compatibilityTrackMimeType =
        MediaCodecUtil.getAlternativeCodecMimeType(newUpstreamFormat);
    if (compatibilityTrackMimeType != null) {
      mediaExtractorSampleQueue.setCompatibilityTrackIndex(tracks.size());
      tracks.add(
          new MediaExtractorTrack(
              mediaExtractorSampleQueue,
              /* isCompatibilityTrack= */ true,
              compatibilityTrackMimeType));
    }
  }

  private void maybeResolvePendingSeek() throws IOException {
    if (this.pendingSeek == null) {
      return; // Nothing to do.
    }
    SeekPoint pendingSeek = checkNotNull(this.pendingSeek);
    progressiveMediaExtractor.seek(pendingSeek.position, pendingSeek.timeUs);
    reopenCurrentDataSource(pendingSeek.position);
    this.pendingSeek = null;
  }

  /**
   * Create a new {@link DataSpec} with the given data.
   *
   * <p>The created {@link DataSpec} disables caching if the content length cannot be resolved,
   * since this is indicative of a progressive live stream.
   */
  private DataSpec buildDataSpec(Uri uri, long position) {
    DataSpec.Builder dataSpec =
        new DataSpec.Builder()
            .setUri(uri)
            .setPosition(position)
            .setFlags(
                DataSpec.FLAG_DONT_CACHE_IF_LENGTH_UNKNOWN
                    | DataSpec.FLAG_ALLOW_CACHE_FRAGMENTATION);
    if (httpRequestHeaders != null) {
      dataSpec.setHttpRequestHeaders(httpRequestHeaders);
    }
    return dataSpec.build();
  }

  private final class ExtractorOutputImpl implements ExtractorOutput {

    @Override
    public TrackOutput track(int id, int type) {
      MediaExtractorSampleQueue sampleQueue = sampleQueues.get(id);
      if (sampleQueue != null) {
        // This track has already been declared. We return the sample queue that corresponds to this
        // id.
        return sampleQueue;
      }
      if (tracksEnded) {
        // The id is new and the extractor has ended the tracks. Discard.
        return new DiscardingTrackOutput();
      }

      sampleQueue = new MediaExtractorSampleQueue(allocator, id);
      sampleQueues.put(id, sampleQueue);
      return sampleQueue;
    }

    @Override
    public void endTracks() {
      tracksEnded = true;
    }

    @Override
    public void seekMap(SeekMap seekMap) {
      MediaExtractorCompatInternal.this.seekMap = seekMap;
    }
  }

  private static final class MediaExtractorTrack {

    private final MediaExtractorSampleQueue sampleQueue;
    private final boolean isCompatibilityTrack;
    private final @Nullable String compatibilityTrackMimeType;

    private MediaExtractorTrack(
        MediaExtractorSampleQueue sampleQueue,
        boolean isCompatibilityTrack,
        @Nullable String compatibilityTrackMimeType) {
      this.sampleQueue = sampleQueue;
      this.isCompatibilityTrack = isCompatibilityTrack;
      this.compatibilityTrackMimeType = compatibilityTrackMimeType;
    }

    @SuppressWarnings("InlinedApi") // For MediaFormat.KEY_CODECS_STRING
    private MediaFormat createDownstreamMediaFormat(
        FormatHolder scratchFormatHolder, DecoderInputBuffer scratchNoDataDecoderInputBuffer) {
      Format format = getFormat(scratchFormatHolder, scratchNoDataDecoderInputBuffer);
      // MediaExtractor exposes the frame rate as an integer, and omits it if it rounds to zero.
      int frameRate = Math.round(format.frameRate);
      if (frameRate <= 0 && format.frameRate != Format.NO_VALUE) {
        // MediaFormat.removeKey requires API 29, so prevent the key from being set instead.
        format = format.buildUpon().setFrameRate(Format.NO_VALUE).build();
      }
      MediaFormat mediaFormatResult = MediaFormatUtil.createMediaFormatFromFormat(format);
      if (frameRate > 0) {
        mediaFormatResult.setInteger(MediaFormat.KEY_FRAME_RATE, frameRate);
      }
      if (compatibilityTrackMimeType != null) {
        if (SDK_INT >= 29) {
          mediaFormatResult.removeKey(MediaFormat.KEY_CODECS_STRING);
        }
        mediaFormatResult.setString(MediaFormat.KEY_MIME, compatibilityTrackMimeType);
      }
      Pair<Integer, Integer> profileAndLevel =
          CodecSpecificDataUtil.getCodecProfileAndLevel(format);
      if (profileAndLevel != null) {
        mediaFormatResult.setInteger(MediaFormat.KEY_PROFILE, profileAndLevel.first);
        if (profileAndLevel.second > 0) {
          mediaFormatResult.setInteger(MediaFormat.KEY_LEVEL, profileAndLevel.second);
        }
        if (MimeTypes.AUDIO_AAC.equals(format.sampleMimeType)) {
          mediaFormatResult.setInteger(MediaFormat.KEY_AAC_PROFILE, profileAndLevel.first);
        }
      }
      return mediaFormatResult;
    }

    private Format getFormat(
        FormatHolder scratchFormatHolder, DecoderInputBuffer scratchNoDataDecoderInputBuffer) {
      scratchFormatHolder.clear();
      sampleQueue.read(
          scratchFormatHolder,
          scratchNoDataDecoderInputBuffer,
          FLAG_REQUIRE_FORMAT,
          /* loadingFinished= */ false);
      Format format = checkNotNull(scratchFormatHolder.format);
      scratchFormatHolder.clear();
      return format;
    }

    private void discardFrontSample() {
      sampleQueue.skip(/* count= */ 1);
      sampleQueue.discardToRead();
    }

    private int getIdOfBackingTrack() {
      return sampleQueue.trackId;
    }

    @Override
    public String toString() {
      return String.format(
          "MediaExtractorSampleQueue: %s, isCompatibilityTrack: %s, compatibilityTrackMimeType: %s",
          sampleQueue, isCompatibilityTrack, compatibilityTrackMimeType);
    }
  }

  private final class MediaExtractorSampleQueue extends SampleQueue {

    private final int trackId;
    private long trackDurationUs;
    private int mainTrackIndex;
    private int compatibilityTrackIndex;

    private MediaExtractorSampleQueue(Allocator allocator, int trackId) {
      // We do not need the sample queue to acquire keys for encrypted samples, so we pass null
      // values for DRM-related arguments.
      super(allocator, /* drmSessionManager= */ null, /* drmEventDispatcher= */ null);
      this.trackId = trackId;
      trackDurationUs = C.TIME_UNSET;
      mainTrackIndex = C.INDEX_UNSET;
      compatibilityTrackIndex = C.INDEX_UNSET;
    }

    private void setMainTrackIndex(int mainTrackIndex) {
      this.mainTrackIndex = mainTrackIndex;
    }

    private void setCompatibilityTrackIndex(int compatibilityTrackIndex) {
      this.compatibilityTrackIndex = compatibilityTrackIndex;
    }

    // SampleQueue implementation.

    @Override
    public void durationUs(long durationUs) {
      this.trackDurationUs = durationUs;
      super.durationUs(durationUs);
    }

    @Override
    public Format getAdjustedUpstreamFormat(Format format) {
      if (getUpstreamFormat() == null) {
        onSampleQueueFormatInitialized(this, format);
      }
      return super.getAdjustedUpstreamFormat(format);
    }

    @Override
    public void sampleMetadata(
        long timeUs,
        @C.BufferFlags int flags,
        int size,
        int offset,
        @Nullable CryptoData cryptoData) {
      // Disable BUFFER_FLAG_LAST_SAMPLE to prevent the sample queue from ignoring
      // FLAG_REQUIRE_FORMAT. See b/191518632.
      flags &= ~C.BUFFER_FLAG_LAST_SAMPLE;
      checkState(mainTrackIndex != C.INDEX_UNSET);
      int writeIndexBeforeCommitting = this.getWriteIndex();
      super.sampleMetadata(timeUs, flags, size, offset, cryptoData);
      // Add the sample metadata if the sample was committed
      if (this.getWriteIndex() == writeIndexBeforeCommitting + 1) {
        queueSampleMetadata(timeUs, flags);
      }
    }

    @Override
    public String toString() {
      return String.format(
          "trackId: %s, mainTrackIndex: %s, compatibilityTrackIndex: %s",
          trackId, mainTrackIndex, compatibilityTrackIndex);
    }

    private void queueSampleMetadata(long timeUs, @C.BufferFlags int flags) {
      int mediaExtractorFlags = 0;
      mediaExtractorFlags |=
          (flags & C.BUFFER_FLAG_ENCRYPTED) != 0 ? MediaExtractor.SAMPLE_FLAG_ENCRYPTED : 0;
      mediaExtractorFlags |=
          (flags & C.BUFFER_FLAG_KEY_FRAME) != 0 ? MediaExtractor.SAMPLE_FLAG_SYNC : 0;

      if (compatibilityTrackIndex != C.INDEX_UNSET) {
        sampleMetadataQueue.addLast(
            timeUs, /* flags= */ mediaExtractorFlags, compatibilityTrackIndex);
      }
      sampleMetadataQueue.addLast(timeUs, /* flags= */ mediaExtractorFlags, mainTrackIndex);
    }
  }

  /**
   * A queue for managing {@link SampleMetadata} instances in FIFO order with an internal pool for
   * recycling.
   */
  private static final class SampleMetadataQueue {

    private final ArrayDeque<SampleMetadata> sampleMetadataPool;
    private final ArrayDeque<SampleMetadata> sampleMetadataQueue;

    /** Creates an instance. */
    private SampleMetadataQueue() {
      sampleMetadataPool = new ArrayDeque<>();
      sampleMetadataQueue = new ArrayDeque<>();
    }

    /**
     * Adds a sample to the end of the queue, reusing a pooled {@link SampleMetadata} instance if
     * available.
     *
     * @param timeUs The media timestamp associated with the sample, in microseconds.
     * @param flags Flags associated with the sample. See {@code MediaExtractor.SAMPLE_FLAG_*}.
     * @param trackIndex Track index of the sample.
     */
    private void addLast(long timeUs, int flags, int trackIndex) {
      SampleMetadata metadata = obtainSampleMetadata(timeUs, flags, trackIndex);
      sampleMetadataQueue.addLast(metadata);
    }

    /**
     * Removes and returns the first {@link SampleMetadata} in the queue, releasing it back to the
     * pool.
     */
    private SampleMetadata removeFirst() {
      SampleMetadata metadata = sampleMetadataQueue.removeFirst();
      sampleMetadataPool.push(metadata);
      return metadata;
    }

    /**
     * Peeks at the first {@link SampleMetadata} in the queue without removing it.
     *
     * @return The first {@link SampleMetadata} in the queue, or {@code null} if empty.
     */
    private @Nullable SampleMetadata peekFirst() {
      return sampleMetadataQueue.peekFirst();
    }

    /** Clears the queue, releasing all {@link SampleMetadata} back to the pool. */
    private void clear() {
      for (SampleMetadata metadata : sampleMetadataQueue) {
        sampleMetadataPool.push(metadata);
      }
      sampleMetadataQueue.clear();
    }

    /** Clears both the queue and the internal recycling pool. */
    private void release() {
      sampleMetadataQueue.clear();
      sampleMetadataPool.clear();
    }

    /** Returns whether the queue is empty. */
    private boolean isEmpty() {
      return sampleMetadataQueue.isEmpty();
    }

    private SampleMetadata obtainSampleMetadata(long timeUs, int flags, int trackIndex) {
      SampleMetadata metadata =
          sampleMetadataPool.isEmpty()
              ? new SampleMetadata(timeUs, flags, trackIndex)
              : sampleMetadataPool.pop();
      metadata.set(timeUs, flags, trackIndex);
      return metadata;
    }

    private static final class SampleMetadata {
      private int flags;
      private long timeUs;
      private int trackIndex;

      private SampleMetadata(long timeUs, int flags, int trackIndex) {
        set(timeUs, flags, trackIndex);
      }

      private void set(long timeUs, int flags, int trackIndex) {
        this.timeUs = timeUs;
        this.flags = flags;
        this.trackIndex = trackIndex;
      }
    }
  }
}
