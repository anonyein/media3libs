/*
 * Copyright 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.session;

import static androidx.media3.common.util.Util.convertToNullIfInvalid;
import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;

import android.content.ComponentName;
import android.media.session.MediaSession;
import android.os.Bundle;
import android.os.IBinder;
import android.text.TextUtils;
import androidx.core.app.BundleCompat;
import androidx.media3.common.util.Util;
import java.util.Objects;
import org.jspecify.annotations.Nullable;

/* package */ final class SessionTokenImplBase implements SessionToken.SessionTokenImpl {

  private final int uid;

  private final @SessionToken.TokenType int type;

  private final int libraryVersion;

  private final int interfaceVersion;

  private final String packageName;

  private final @Nullable String packageNameOverride;

  private final String serviceName;

  private final @Nullable ComponentName componentName;

  private final @Nullable IBinder iSession;

  private final Bundle extras;

  private final MediaSession.@Nullable Token platformToken;

  public SessionTokenImplBase(ComponentName serviceComponent, int uid, int type) {
    this(
        uid,
        type,
        SessionToken.UNKNOWN_SESSION_VERSION,
        SessionToken.UNKNOWN_INTERFACE_VERSION,
        checkNotNull(serviceComponent).getPackageName(),
        /* serviceName= */ serviceComponent.getClassName(),
        /* componentName= */ serviceComponent,
        /* iSession= */ null,
        /* extras= */ Bundle.EMPTY,
        /* platformToken= */ null,
        /* packageNameOverride= */ null);
  }

  public SessionTokenImplBase(
      int uid,
      int type,
      int libraryVersion,
      int interfaceVersion,
      String packageName,
      IMediaSession iSession,
      Bundle tokenExtras,
      MediaSession.@Nullable Token platformToken,
      @Nullable String packageNameOverride) {
    this(
        uid,
        type,
        libraryVersion,
        interfaceVersion,
        checkNotNull(packageName),
        /* serviceName= */ "",
        /* componentName= */ null,
        iSession.asBinder(),
        checkNotNull(tokenExtras),
        platformToken,
        packageNameOverride);
  }

  private SessionTokenImplBase(
      int uid,
      int type,
      int libraryVersion,
      int interfaceVersion,
      String packageName,
      String serviceName,
      @Nullable ComponentName componentName,
      @Nullable IBinder iSession,
      Bundle extras,
      MediaSession.@Nullable Token platformToken,
      @Nullable String packageNameOverride) {
    this.uid = uid;
    this.type = type;
    this.libraryVersion = libraryVersion;
    this.interfaceVersion = interfaceVersion;
    this.packageName = packageName;
    this.serviceName = serviceName;
    this.componentName = componentName;
    this.iSession = iSession;
    this.extras = extras;
    this.platformToken = platformToken;
    this.packageNameOverride = packageNameOverride;
  }

  @Override
  public int hashCode() {
    return Objects.hash(
        uid,
        type,
        libraryVersion,
        interfaceVersion,
        packageName,
        serviceName,
        componentName,
        iSession,
        platformToken,
        packageNameOverride);
  }

  @Override
  public boolean equals(@Nullable Object obj) {
    if (!(obj instanceof SessionTokenImplBase)) {
      return false;
    }
    SessionTokenImplBase other = (SessionTokenImplBase) obj;
    return uid == other.uid
        && type == other.type
        && libraryVersion == other.libraryVersion
        && interfaceVersion == other.interfaceVersion
        && TextUtils.equals(packageName, other.packageName)
        && TextUtils.equals(serviceName, other.serviceName)
        && Objects.equals(componentName, other.componentName)
        && Objects.equals(iSession, other.iSession)
        && Objects.equals(platformToken, other.platformToken)
        && Objects.equals(packageNameOverride, other.packageNameOverride);
  }

  @Override
  public String toString() {
    return "SessionToken {pkg="
        + packageName
        + " type="
        + type
        + " libraryVersion="
        + libraryVersion
        + " interfaceVersion="
        + interfaceVersion
        + " service="
        + serviceName
        + " IMediaSession="
        + iSession
        + " extras="
        + extras
        + "}";
  }

  @Override
  public boolean isLegacySession() {
    return false;
  }

  @Override
  public int getUid() {
    return uid;
  }

  @Override
  public String getPackageName() {
    return packageNameOverride == null ? packageName : packageNameOverride;
  }

  @Override
  public String getOriginalPackageName() {
    return packageName;
  }

  @Override
  public String getServiceName() {
    return serviceName;
  }

  @Override
  public @Nullable ComponentName getComponentName() {
    return componentName;
  }

  @Override
  public @SessionToken.TokenType int getType() {
    return type;
  }

  @Override
  public int getLibraryVersion() {
    return libraryVersion;
  }

  @Override
  public int getInterfaceVersion() {
    return interfaceVersion;
  }

  @Override
  public Bundle getExtras() {
    return new Bundle(extras);
  }

  @Override
  public @Nullable Object getBinder() {
    return iSession;
  }

  @Override
  public MediaSession.@Nullable Token getPlatformToken() {
    return platformToken;
  }

  private static final String FIELD_UID = Util.intToStringMaxRadix(0);
  private static final String FIELD_TYPE = Util.intToStringMaxRadix(1);
  private static final String FIELD_LIBRARY_VERSION = Util.intToStringMaxRadix(2);
  private static final String FIELD_PACKAGE_NAME = Util.intToStringMaxRadix(3);
  private static final String FIELD_SERVICE_NAME = Util.intToStringMaxRadix(4);
  private static final String FIELD_COMPONENT_NAME = Util.intToStringMaxRadix(5);
  private static final String FIELD_ISESSION = Util.intToStringMaxRadix(6);
  private static final String FIELD_EXTRAS = Util.intToStringMaxRadix(7);
  private static final String FIELD_INTERFACE_VERSION = Util.intToStringMaxRadix(8);
  private static final String FIELD_PLATFORM_TOKEN = Util.intToStringMaxRadix(9);
  private static final String FIELD_PACKAGE_NAME_OVERRIDE = Util.intToStringMaxRadix(10);

  // Next field key = 11

  @Override
  public Bundle toBundle() {
    Bundle bundle = new Bundle();
    bundle.putInt(FIELD_UID, uid);
    bundle.putInt(FIELD_TYPE, type);
    bundle.putInt(FIELD_LIBRARY_VERSION, libraryVersion);
    bundle.putString(FIELD_PACKAGE_NAME, packageName);
    bundle.putString(FIELD_SERVICE_NAME, serviceName);
    BundleCompat.putBinder(bundle, FIELD_ISESSION, iSession);
    bundle.putParcelable(FIELD_COMPONENT_NAME, componentName);
    bundle.putBundle(FIELD_EXTRAS, extras);
    bundle.putInt(FIELD_INTERFACE_VERSION, interfaceVersion);
    if (platformToken != null) {
      bundle.putParcelable(FIELD_PLATFORM_TOKEN, platformToken);
    }
    if (packageNameOverride != null) {
      bundle.putString(FIELD_PACKAGE_NAME_OVERRIDE, packageNameOverride);
    }
    return bundle;
  }

  /** Restores a {@code SessionTokenImplBase} from a {@link Bundle}. */
  public static SessionTokenImplBase fromBundle(
      Bundle bundle, MediaSession.@Nullable Token platformToken) {
    checkArgument(bundle.containsKey(FIELD_UID), "uid should be set.");
    int uid = bundle.getInt(FIELD_UID);
    checkArgument(bundle.containsKey(FIELD_TYPE), "type should be set.");
    int type = bundle.getInt(FIELD_TYPE);
    int libraryVersion =
        bundle.getInt(
            FIELD_LIBRARY_VERSION, /* defaultValue= */ SessionToken.UNKNOWN_SESSION_VERSION);
    int interfaceVersion =
        bundle.getInt(
            FIELD_INTERFACE_VERSION, /* defaultValue= */ SessionToken.UNKNOWN_INTERFACE_VERSION);
    String packageName = bundle.getString(FIELD_PACKAGE_NAME);
    checkArgument(!TextUtils.isEmpty(packageName), "package name should be set.");
    String serviceName = bundle.getString(FIELD_SERVICE_NAME, /* defaultValue= */ "");
    @Nullable IBinder iSession = BundleCompat.getBinder(bundle, FIELD_ISESSION);
    @Nullable ComponentName componentName = bundle.getParcelable(FIELD_COMPONENT_NAME);
    @Nullable Bundle extras = convertToNullIfInvalid(bundle.getBundle(FIELD_EXTRAS));
    MediaSession.@Nullable Token platformTokenFromBundle =
        bundle.getParcelable(FIELD_PLATFORM_TOKEN);
    if (platformTokenFromBundle != null) {
      platformToken = platformTokenFromBundle;
    }
    @Nullable String packageNameOverride = bundle.getString(FIELD_PACKAGE_NAME_OVERRIDE);
    return new SessionTokenImplBase(
        uid,
        type,
        libraryVersion,
        interfaceVersion,
        packageName,
        serviceName,
        componentName,
        iSession,
        extras == null ? Bundle.EMPTY : extras,
        platformToken,
        packageNameOverride);
  }
}
