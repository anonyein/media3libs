/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.effect;

import static androidx.media3.effect.DefaultGlFrameProcessor.KEY_COMPOSITION_SEQUENCE_INDEX;
import static androidx.media3.effect.DefaultGlFrameProcessor.KEY_COMPOSITOR_SETTINGS;
import static androidx.media3.effect.FrameProcessorUtils.runAllAndAccumulateExceptions;
import static androidx.media3.effect.FrameProcessorUtils.useHighPrecisionColorComponents;
import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;

import androidx.annotation.GuardedBy;
import androidx.annotation.VisibleForTesting;
import androidx.media3.common.ColorInfo;
import androidx.media3.common.GlObjectsProvider;
import androidx.media3.common.GlTextureInfo;
import androidx.media3.common.OverlaySettings;
import androidx.media3.common.VideoCompositorSettings;
import androidx.media3.common.VideoFrameProcessingException;
import androidx.media3.common.util.GlUtil.GlException;
import androidx.media3.common.util.Size;
import androidx.media3.effect.GlTextureFrameCompositor.CompositorGlProgram;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.function.Consumer;
import org.jspecify.annotations.Nullable;

/**
 * Composites a list of {@link GlTextureFrame GlTextureFrames}, and outputs to a downstream {@link
 * GlTextureFrameConsumer}.
 *
 * <p>Methods in this class must be called on a GL thread.
 */
/* package */ final class DefaultGlTextureFrameCompositor implements GlTextureFrameCompositor {

  private static final int DEFAULT_COMPOSITOR_CAPACITY = 2;

  /**
   * A {@link GlTextureFrameCompositor.Factory} that creates {@link DefaultGlTextureFrameCompositor}
   * instances.
   */
  public static final class Factory implements GlTextureFrameCompositor.Factory {
    private final CompositorGlProgram.Factory compositorGlProgramFactory;
    private final TexturePool.Factory texturePoolFactory;

    /**
     * Creates an instance.
     *
     * @param compositorGlProgramFactory The {@link CompositorGlProgram.Factory}.
     */
    public Factory(CompositorGlProgram.Factory compositorGlProgramFactory) {
      this(
          compositorGlProgramFactory,
          workingColorSpace ->
              new TexturePool(
                  useHighPrecisionColorComponents(workingColorSpace),
                  /* capacity= */ DEFAULT_COMPOSITOR_CAPACITY));
    }

    /**
     * Creates an instance for testing only.
     *
     * @param compositorGlProgramFactory The {@link CompositorGlProgram.Factory}.
     * @param texturePoolFactory The {@link TexturePool.Factory}.
     */
    @VisibleForTesting
    /* package */ Factory(
        CompositorGlProgram.Factory compositorGlProgramFactory,
        TexturePool.Factory texturePoolFactory) {
      this.compositorGlProgramFactory = compositorGlProgramFactory;
      this.texturePoolFactory = texturePoolFactory;
    }

    @Override
    public GlTextureFrameCompositor create(
        GlObjectsProvider glObjectsProvider,
        ColorInfo workingColorSpace,
        Consumer<VideoFrameProcessingException> errorConsumer,
        Executor glExecutor,
        GlTextureFrameConsumer downstreamConsumer) {
      return new DefaultGlTextureFrameCompositor(
          glObjectsProvider,
          texturePoolFactory.create(workingColorSpace),
          errorConsumer,
          compositorGlProgramFactory.create(),
          glExecutor,
          downstreamConsumer);
    }
  }

  private final GlObjectsProvider glObjectsProvider;
  private final TexturePool outputTexturePool;
  private final Consumer<VideoFrameProcessingException> errorConsumer;
  private final CompositorGlProgram compositorGlProgram;
  private final Executor glExecutor;
  private final GlTextureFrameConsumer downstreamConsumer;
  private final Object lock;

  private @Nullable GlTextureFrame pendingOutputFrame;

  @GuardedBy("lock")
  private @Nullable Runnable pendingWakeupListener;

  @GuardedBy("lock")
  private @Nullable Executor pendingWakeupExecutor;

  // This is reset when a new batch of frames is queued.
  private boolean inputStreamEnded;

  /**
   * Creates a new instance.
   *
   * @param glObjectsProvider The {@link GlObjectsProvider} that's used in OpenGL operations.
   * @param outputTexturePool The {@link TexturePool} to hold the pending output frames.
   * @param errorConsumer A {@link Consumer} that consumes {@link VideoFrameProcessingException}.
   * @param compositorGlProgram The {@link CompositorGlProgram} implementation that composites input
   *     frames into one output frame.
   * @param glExecutor The {@link Executor} to run OpenGL related tasks. The executor should execute
   *     on a thread with the current OpenGL context. All methods in this class should execute on
   *     this thread.
   * @param downstreamConsumer The {@link GlTextureFrameConsumer} that consumes the output frames.
   */
  public DefaultGlTextureFrameCompositor(
      GlObjectsProvider glObjectsProvider,
      TexturePool outputTexturePool,
      Consumer<VideoFrameProcessingException> errorConsumer,
      CompositorGlProgram compositorGlProgram,
      Executor glExecutor,
      GlTextureFrameConsumer downstreamConsumer) {
    this.glObjectsProvider = glObjectsProvider;
    this.outputTexturePool = outputTexturePool;
    this.errorConsumer = errorConsumer;
    this.compositorGlProgram = compositorGlProgram;
    this.glExecutor = glExecutor;
    this.downstreamConsumer = downstreamConsumer;
    lock = new Object();
  }

  @Override
  public boolean queue(
      List<GlTextureFrame> frames, Executor listenerExecutor, Runnable wakeupListener)
      throws VideoFrameProcessingException {
    // TODO: b/517424999 - Unify the listeners to follow the same pattern as FrameProcessor.
    checkArgument(!frames.isEmpty());
    boolean canBypassCompositing = canBypassCompositing(frames);
    if (pendingOutputFrame != null
        || (!canBypassCompositing
            && outputTexturePool.isConfigured()
            && outputTexturePool.freeTextureCount() == 0)) {
      synchronized (lock) {
        pendingWakeupListener = wakeupListener;
        pendingWakeupExecutor = listenerExecutor;
      }
      return false;
    }

    inputStreamEnded = false;
    if (canBypassCompositing) {
      return downstreamConsumer.queue(frames.get(0), listenerExecutor, wakeupListener);
    }

    // All the frames should have the same presentation time and compositor settings.
    GlTextureFrame primaryInputFrame = frames.get(0);
    VideoCompositorSettings videoCompositorSettings =
        (VideoCompositorSettings)
            checkNotNull(primaryInputFrame.getMetadata().get(KEY_COMPOSITOR_SETTINGS));

    ImmutableList.Builder<Size> inputSizes = new ImmutableList.Builder<>();
    long outputPresentationTimeUs = primaryInputFrame.presentationTimeUs;
    for (int i = 0; i < frames.size(); i++) {
      GlTextureInfo textureInfo = frames.get(i).glTextureInfo;
      inputSizes.add(new Size(textureInfo.width, textureInfo.height));
    }

    Size outputSize = videoCompositorSettings.getOutputSize(inputSizes.build());
    @Nullable GlTextureInfo outputTexture = null;
    try {
      outputTexturePool.ensureConfigured(
          glObjectsProvider, outputSize.getWidth(), outputSize.getHeight());
      outputTexture = outputTexturePool.useTexture();
      checkNotNull(compositorGlProgram).drawFrame(frames, outputTexture);

      GlTextureFrame outputGlTextureFrame =
          new GlTextureFrame.Builder(
                  outputTexture,
                  /* releaseTextureExecutor= */ glExecutor,
                  /* releaseTextureCallback= */ glTextureInfo -> {
                    try {
                      outputTexturePool.freeTexture(glTextureInfo);
                      maybeInvokeWakeupListener();
                    } catch (RuntimeException e) {
                      errorConsumer.accept(VideoFrameProcessingException.from(e));
                    }
                  })
              .setPresentationTimeUs(outputPresentationTimeUs)
              .setMetadata(
                  stripKeys(
                      primaryInputFrame.getMetadata(),
                      KEY_COMPOSITION_SEQUENCE_INDEX,
                      KEY_COMPOSITOR_SETTINGS))
              .setFormat(
                  primaryInputFrame
                      .format
                      .buildUpon()
                      .setWidth(outputTexture.width)
                      .setHeight(outputTexture.height)
                      .build())
              .build();

      pendingOutputFrame = outputGlTextureFrame;
    } catch (GlException | VideoFrameProcessingException | RuntimeException e) {
      if (outputTexture != null) {
        outputTexturePool.freeTexture(outputTexture);
      }
      throw VideoFrameProcessingException.from(e);
    } finally {
      for (int i = 0; i < frames.size(); i++) {
        frames.get(i).release(/* releaseFence= */ null);
      }
    }

    tryQueueToDownstream();
    // Returning true because the input frames are accepted. If queueing to downstream fails, it'll
    // be retried.
    return true;
  }

  @Override
  public void signalEndOfStream() {
    inputStreamEnded = true;
    if (pendingOutputFrame == null) {
      downstreamConsumer.signalEndOfStream();
    }
  }

  @Override
  public void close() throws VideoFrameProcessingException {
    inputStreamEnded = false;
    runAllAndAccumulateExceptions(
        compositorGlProgram::release,
        () -> {
          if (pendingOutputFrame != null) {
            pendingOutputFrame.release(/* releaseFence= */ null);
          }
        },
        outputTexturePool::deleteAllTextures);
  }

  private void tryQueueToDownstream() {
    if (pendingOutputFrame == null) {
      return;
    }
    boolean queued;
    try {
      // TODO: b/517424999 - Unify the listeners to follow the same pattern as
      //  FrameProcessor.
      queued =
          downstreamConsumer.queue(
              pendingOutputFrame, glExecutor, /* wakeupListener= */ this::tryQueueToDownstream);
    } catch (RuntimeException | VideoFrameProcessingException e) {
      if (pendingOutputFrame != null) {
        pendingOutputFrame.release(/* releaseFence= */ null);
        pendingOutputFrame = null;
      }
      errorConsumer.accept(VideoFrameProcessingException.from(e));
      return;
    }
    if (queued) {
      pendingOutputFrame = null;
      maybeInvokeWakeupListener();
      if (inputStreamEnded) {
        downstreamConsumer.signalEndOfStream();
      }
    }
  }

  private void maybeInvokeWakeupListener() {
    Runnable listener;
    Executor executor;
    synchronized (lock) {
      if (pendingWakeupListener == null || pendingWakeupExecutor == null) {
        return;
      }
      listener = pendingWakeupListener;
      executor = pendingWakeupExecutor;
      pendingWakeupListener = null;
      pendingWakeupExecutor = null;
    }
    executor.execute(
        () -> {
          try {
            listener.run();
          } catch (RuntimeException e) {
            errorConsumer.accept(VideoFrameProcessingException.from(e));
          }
        });
  }

  private static boolean canBypassCompositing(List<GlTextureFrame> frames) {
    if (frames.size() > 1) {
      return false;
    }
    GlTextureFrame inputFrame = frames.get(0);
    VideoCompositorSettings videoCompositorSettings =
        (VideoCompositorSettings)
            inputFrame
                .getMetadata()
                .getOrDefault(KEY_COMPOSITOR_SETTINGS, VideoCompositorSettings.DEFAULT);
    if (videoCompositorSettings.equals(VideoCompositorSettings.DEFAULT)) {
      return true;
    }
    Size inputSize = new Size(inputFrame.glTextureInfo.width, inputFrame.glTextureInfo.height);
    Size outputSize = videoCompositorSettings.getOutputSize(ImmutableList.of(inputSize));
    if (!outputSize.equals(inputSize)) {
      return false;
    }
    int sequenceIndex =
        (int) checkNotNull(inputFrame.getMetadata().get(KEY_COMPOSITION_SEQUENCE_INDEX));
    OverlaySettings overlaySettings =
        videoCompositorSettings.getOverlaySettings(sequenceIndex, inputFrame.presentationTimeUs);
    return isDefaultOverlaySettings(overlaySettings);
  }

  private static boolean isDefaultOverlaySettings(OverlaySettings overlaySettings) {
    return overlaySettings.getAlphaScale() == OverlaySettings.DEFAULT_ALPHA_SCALE
        && overlaySettings
            .getBackgroundFrameAnchor()
            .equals(OverlaySettings.DEFAULT_BACKGROUND_FRAME_ANCHOR)
        && overlaySettings
            .getOverlayFrameAnchor()
            .equals(OverlaySettings.DEFAULT_OVERLAY_FRAME_ANCHOR)
        && overlaySettings.getScale().equals(OverlaySettings.DEFAULT_SCALE)
        && overlaySettings.getRotationDegrees() == OverlaySettings.DEFAULT_ROTATION_DEGREES
        && overlaySettings.getHdrLuminanceMultiplier()
            == OverlaySettings.DEFAULT_HDR_LUMINANCE_MULTIPLIER;
  }

  private static ImmutableMap<String, Object> stripKeys(
      Map<String, Object> metadata, String... keys) {
    HashMap<String, Object> strippedMetadata = new HashMap<>(metadata);
    for (String key : keys) {
      strippedMetadata.remove(key);
    }
    return ImmutableMap.copyOf(strippedMetadata);
  }
}
