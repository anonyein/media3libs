/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.effect

import androidx.media3.common.util.Consumer
import androidx.media3.common.util.ExperimentalApi

/** A [PacketConsumer] that renders input [Packet]s to an output [O]. */
@ExperimentalApi // TODO: b/449956776 - Remove once FrameConsumer API is finalized.
interface RenderingPacketConsumer<I, O> : PacketConsumer<I> {

  /** Sets the target for where input frames are rendered to. */
  fun setRenderOutput(output: O?)

  /** Sets a [Consumer] to handle any [Exception]s that occur during rendering. */
  fun setErrorConsumer(errorConsumer: Consumer<Exception>)
}
