/*
 * Copyright 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.muxer;

import static androidx.media3.muxer.AnnexBUtils.doesSampleContainAnnexBNalUnits;
import static androidx.media3.muxer.Av1ConfigUtil.createAv1CodecConfigurationRecord;
import static androidx.media3.muxer.Boxes.BOX_HEADER_SIZE;
import static androidx.media3.muxer.Boxes.MFHD_BOX_CONTENT_SIZE;
import static androidx.media3.muxer.Boxes.TFDT_BOX_CONTENT_SIZE;
import static androidx.media3.muxer.Boxes.TFHD_BOX_CONTENT_SIZE;
import static androidx.media3.muxer.Boxes.getTrunBoxContentSize;
import static androidx.media3.muxer.Mp4Muxer.LAST_SAMPLE_DURATION_BEHAVIOR_SET_FROM_END_OF_STREAM_BUFFER_OR_DUPLICATE_PREVIOUS;
import static androidx.media3.muxer.MuxerUtil.UNSIGNED_INT_MAX_VALUE;
import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.base.Preconditions.checkState;
import static java.lang.Math.max;
import static java.lang.Math.min;

import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.util.Util;
import com.google.common.collect.ImmutableList;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.WritableByteChannel;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import org.checkerframework.checker.nullness.qual.MonotonicNonNull;

/**
 * Writes media samples into multiple fragments as per the fragmented MP4 (ISO/IEC 14496-12)
 * standard.
 */
/* package */ final class FragmentedMp4Writer {
  /** Provides a limited set of sample metadata. */
  public static class SampleMetadata {
    public final int durationVu;
    public final int size;
    public final int flags;
    public final int compositionTimeOffsetVu;

    public SampleMetadata(int durationsVu, int size, int flags, int compositionTimeOffsetVu) {
      this.durationVu = durationsVu;
      this.size = size;
      this.flags = flags;
      this.compositionTimeOffsetVu = compositionTimeOffsetVu;
    }
  }

  /** A {@link WritableByteChannel} that tracks the number of bytes written to the stream. */
  private static class PositionTrackingOutputChannel implements WritableByteChannel {
    private final WritableByteChannel outputChannel;
    private long position;

    public PositionTrackingOutputChannel(WritableByteChannel outputChannel) {
      this.outputChannel = outputChannel;
      this.position = 0;
    }

    @Override
    public int write(ByteBuffer src) throws IOException {
      int bytesWritten = outputChannel.write(src);
      position += bytesWritten;
      return bytesWritten;
    }

    @Override
    public boolean isOpen() {
      return outputChannel.isOpen();
    }

    @Override
    public void close() throws IOException {
      outputChannel.close();
    }

    /** Returns the number of bytes written to the channel. */
    public long getPosition() {
      return position;
    }
  }

  private final PositionTrackingOutputChannel outputChannel;
  private final MetadataCollector metadataCollector;
  private final AnnexBToAvccConverter annexBToAvccConverter;
  private final long fragmentDurationUs;
  private final boolean sampleCopyEnabled;
  private final @Mp4Muxer.LastSampleDurationBehavior int lastSampleDurationBehavior;
  private final List<Track> tracks;
  private final LinearByteBufferAllocator linearByteBufferAllocator;

  private boolean isClosed;
  private @MonotonicNonNull Track videoTrack;
  private int currentFragmentSequenceNumber;
  private boolean headerCreated;
  private long minInputPresentationTimeUs;
  private long maxTrackDurationUs;
  private int nextTrackId;

  /**
   * Creates an instance.
   *
   * @param outputChannel The {@link WritableByteChannel} to write the data to.
   * @param metadataCollector A {@link MetadataCollector}.
   * @param annexBToAvccConverter The {@link AnnexBToAvccConverter} to be used to convert H.264 and
   *     H.265 NAL units from the Annex-B format (using start codes to delineate NAL units) to the
   *     AVCC format (which uses length prefixes).
   * @param fragmentDurationMs The fragment duration (in milliseconds).
   * @param sampleCopyEnabled Whether sample copying is enabled.
   */
  public FragmentedMp4Writer(
      WritableByteChannel outputChannel,
      MetadataCollector metadataCollector,
      AnnexBToAvccConverter annexBToAvccConverter,
      long fragmentDurationMs,
      boolean sampleCopyEnabled) {
    this.outputChannel = new PositionTrackingOutputChannel(outputChannel);
    this.metadataCollector = metadataCollector;
    this.annexBToAvccConverter = annexBToAvccConverter;
    this.fragmentDurationUs = fragmentDurationMs * 1_000;
    this.sampleCopyEnabled = sampleCopyEnabled;
    lastSampleDurationBehavior =
        LAST_SAMPLE_DURATION_BEHAVIOR_SET_FROM_END_OF_STREAM_BUFFER_OR_DUPLICATE_PREVIOUS;
    tracks = new ArrayList<>();
    minInputPresentationTimeUs = Long.MAX_VALUE;
    currentFragmentSequenceNumber = 1;
    nextTrackId = 1;
    linearByteBufferAllocator = new LinearByteBufferAllocator(/* initialCapacity= */ 0);
  }

  public Track addTrack(int sortKey, Format format) {
    checkState(!isClosed, "FragmentedMp4Writer is closed.");
    Track track = new Track(nextTrackId++, format, sampleCopyEnabled);
    tracks.add(track);
    if (MimeTypes.isVideo(format.sampleMimeType)) {
      videoTrack = track;
    }
    return track;
  }

  public void writeSampleData(Track track, ByteBuffer byteBuffer, BufferInfo bufferInfo)
      throws IOException {
    checkState(!isClosed, "FragmentedMp4Writer is closed.");
    if (bufferInfo.size > 0
        && Objects.equals(track.format.sampleMimeType, MimeTypes.VIDEO_AV1)
        && track.format.initializationData.isEmpty()
        && track.parsedCsd == null) {
      track.parsedCsd = createAv1CodecConfigurationRecord(byteBuffer.duplicate());
    }
    if (shouldFlushPendingSamples(track, bufferInfo)) {
      createFragment(/* nextFragmentFirstSampleTimeUs= */ bufferInfo.presentationTimeUs);
    }
    track.writeSampleData(byteBuffer, bufferInfo);
    if (track.pendingSamplesBufferInfo.isEmpty()) {
      return;
    }
    if (!headerCreated) {
      createHeader();
      headerCreated = true;
    }
    BufferInfo firstPendingSample = checkNotNull(track.pendingSamplesBufferInfo.peekFirst());
    BufferInfo lastPendingSample = checkNotNull(track.pendingSamplesBufferInfo.peekLast());
    minInputPresentationTimeUs =
        min(minInputPresentationTimeUs, firstPendingSample.presentationTimeUs);
    maxTrackDurationUs =
        max(
            maxTrackDurationUs,
            lastPendingSample.presentationTimeUs - firstPendingSample.presentationTimeUs);
  }

  /**
   * Finalizes output and closes the writer.
   *
   * <p>This method can be called only once. The {@link FragmentedMp4Writer} cannot be used anymore
   * once this method returns.
   *
   * @throws IOException If an error occurs while finalizing output or closing the output channel.
   */
  public void close() throws IOException {
    checkState(!isClosed, "FragmentedMp4Writer is closed.");
    isClosed = true;
    try {
      // There is no next fragment, so the last sample duration keeps the end of track behaviour.
      createFragment(/* nextFragmentFirstSampleTimeUs= */ C.TIME_UNSET);
      writeMfraBox();
    } finally {
      outputChannel.close();
    }
  }

  private void writeMfraBox() throws IOException {
    List<ByteBuffer> tfraBoxes = new ArrayList<>();
    for (int i = 0; i < tracks.size(); i++) {
      Track track = tracks.get(i);
      if (!track.tfraEntries.isEmpty()) {
        tfraBoxes.add(Boxes.tfra(track.id, track.tfraEntries));
      }
    }
    if (!tfraBoxes.isEmpty()) {
      outputChannel.write(Boxes.mfra(tfraBoxes));
    }
  }

  private static ImmutableList<ByteBuffer> createTrafBoxes(
      List<ProcessedTrackInfo> trackInfos, long moofBoxStartPosition) {
    ImmutableList.Builder<ByteBuffer> trafBoxes = new ImmutableList.Builder<>();
    int moofBoxSize = calculateMoofBoxSize(trackInfos);
    int mdatBoxHeaderSize = BOX_HEADER_SIZE;
    // dataOffset denotes the relative position of the first sample of the track from the
    // moofBoxStartPosition.
    int dataOffset = moofBoxSize + mdatBoxHeaderSize;
    for (int i = 0; i < trackInfos.size(); i++) {
      ProcessedTrackInfo currentTrackInfo = trackInfos.get(i);
      trafBoxes.add(
          Boxes.traf(
              Boxes.tfhd(currentTrackInfo.trackId, /* baseDataOffset= */ moofBoxStartPosition),
              Boxes.tfdt(currentTrackInfo.baseMediaDecodeTime),
              Boxes.trun(
                  currentTrackInfo.trackFormat,
                  currentTrackInfo.pendingSamplesMetadata,
                  dataOffset,
                  currentTrackInfo.hasBFrame)));
      dataOffset += currentTrackInfo.totalSamplesSize;
    }
    return trafBoxes.build();
  }

  private static int calculateMoofBoxSize(List<ProcessedTrackInfo> trackInfos) {
    /* moof box looks like:
    moof
        mfhd
        traf
           tfhd
           tfdt
           trun
        traf
           tfhd
           tfdt
           trun
     */
    int moofBoxHeaderSize = BOX_HEADER_SIZE;
    int mfhdBoxSize = BOX_HEADER_SIZE + MFHD_BOX_CONTENT_SIZE;
    int trafBoxHeaderSize = BOX_HEADER_SIZE;
    int tfhdBoxSize = BOX_HEADER_SIZE + TFHD_BOX_CONTENT_SIZE;
    int tfdtBoxSize = BOX_HEADER_SIZE + TFDT_BOX_CONTENT_SIZE;
    int trunBoxHeaderFixedSize = BOX_HEADER_SIZE;
    int trafBoxesSize = 0;
    for (int i = 0; i < trackInfos.size(); i++) {
      ProcessedTrackInfo trackInfo = trackInfos.get(i);
      int trunBoxSize =
          trunBoxHeaderFixedSize
              + getTrunBoxContentSize(trackInfo.pendingSamplesMetadata.size(), trackInfo.hasBFrame);
      trafBoxesSize += trafBoxHeaderSize + tfhdBoxSize + tfdtBoxSize + trunBoxSize;
    }

    return moofBoxHeaderSize + mfhdBoxSize + trafBoxesSize;
  }

  private void createHeader() throws IOException {
    outputChannel.write(Boxes.ftyp(MuxerUtil.getFtypCompatibleBrands(tracks)));
    outputChannel.write(
        Boxes.moov(
            tracks, metadataCollector, /* isFragmentedMp4= */ true, lastSampleDurationBehavior));
  }

  private boolean shouldFlushPendingSamples(Track track, BufferInfo nextSampleBufferInfo) {
    // LINT.IfChange(fragmentation_logic)
    // If video track is present then fragment will be created based on group of pictures and
    // track's duration so far.
    if (videoTrack != null) {
      // Video samples can be written only when complete group of pictures are present.
      if (track.equals(videoTrack)
          && track.hadKeyframe
          && ((nextSampleBufferInfo.flags & C.BUFFER_FLAG_KEY_FRAME) > 0)) {
        BufferInfo firstPendingSample = checkNotNull(track.pendingSamplesBufferInfo.peekFirst());
        BufferInfo lastPendingSample = checkNotNull(track.pendingSamplesBufferInfo.peekLast());
        return lastPendingSample.presentationTimeUs - firstPendingSample.presentationTimeUs
            >= fragmentDurationUs;
      }
      return false;
    } else {
      return maxTrackDurationUs >= fragmentDurationUs;
    }
    // LINT.ThenChange(:mfra_indexing_logic)
  }

  /**
   * Writes all pending samples into a new fragment.
   *
   * <p>Pass {@link C#TIME_UNSET} for the last fragment.
   */
  private void createFragment(long nextFragmentFirstSampleTimeUs) throws IOException {
    /* Each fragment looks like:
    moof
        mfhd
        traf
           tfhd
           trun
        traf
           tfhd
           trun
     mdat
     */
    long moofBoxStartPosition = outputChannel.getPosition();
    // The 1-based index of the 'traf' box within the 'moof' box for the current track.
    int activeTrafIndex = 1;
    for (int i = 0; i < tracks.size(); i++) {
      Track track = tracks.get(i);
      if (!track.pendingSamplesBufferInfo.isEmpty()) {
        BufferInfo firstPendingSample = checkNotNull(track.pendingSamplesBufferInfo.peekFirst());
        // LINT.IfChange(mfra_indexing_logic)
        // Index video keyframes, audio keyframes, and the first sample of metadata/text tracks.
        boolean isRandomAccessPoint =
            (firstPendingSample.flags & C.BUFFER_FLAG_KEY_FRAME) != 0
                || (!MimeTypes.isVideo(track.format.sampleMimeType)
                    && !MimeTypes.isAudio(track.format.sampleMimeType));
        // LINT.ThenChange(:fragmentation_logic)
        if (isRandomAccessPoint) {
          long ptsInTimescale =
              Util.scaleLargeTimestamp(
                  firstPendingSample.presentationTimeUs, track.videoUnitTimebase(), 1_000_000L);
          track.tfraEntries.add(
              new Boxes.TfraEntry(ptsInTimescale, moofBoxStartPosition, activeTrafIndex));
        }
        activeTrafIndex++;
      }
    }

    ImmutableList<ProcessedTrackInfo> trackInfos = processAllTracks(nextFragmentFirstSampleTimeUs);
    ImmutableList<ByteBuffer> trafBoxes = createTrafBoxes(trackInfos, moofBoxStartPosition);
    if (trafBoxes.isEmpty()) {
      return;
    }
    outputChannel.write(Boxes.moof(Boxes.mfhd(currentFragmentSequenceNumber), trafBoxes));

    writeMdatBox(trackInfos);

    currentFragmentSequenceNumber++;
    maxTrackDurationUs = 0;
  }

  private void writeMdatBox(List<ProcessedTrackInfo> trackInfos) throws IOException {
    long totalNumBytesSamples = 0;
    for (int trackInfoIndex = 0; trackInfoIndex < trackInfos.size(); trackInfoIndex++) {
      ProcessedTrackInfo currentTrackInfo = trackInfos.get(trackInfoIndex);
      for (int sampleIndex = 0;
          sampleIndex < currentTrackInfo.pendingSamplesByteBuffer.size();
          sampleIndex++) {
        totalNumBytesSamples +=
            currentTrackInfo.pendingSamplesByteBuffer.get(sampleIndex).remaining();
      }
    }

    int mdatHeaderSize = 8; // 4 bytes (box size) + 4 bytes (box name)
    ByteBuffer header = ByteBuffer.allocate(mdatHeaderSize);
    long totalMdatSize = mdatHeaderSize + totalNumBytesSamples;

    checkArgument(
        totalMdatSize <= UNSIGNED_INT_MAX_VALUE,
        "Only 32-bit long mdat size supported in the fragmented MP4");
    header.putInt((int) totalMdatSize);
    header.put(Util.getUtf8Bytes("mdat"));
    header.flip();
    outputChannel.write(header);

    for (int trackInfoIndex = 0; trackInfoIndex < trackInfos.size(); trackInfoIndex++) {
      ProcessedTrackInfo currentTrackInfo = trackInfos.get(trackInfoIndex);
      for (int sampleIndex = 0;
          sampleIndex < currentTrackInfo.pendingSamplesByteBuffer.size();
          sampleIndex++) {
        outputChannel.write(currentTrackInfo.pendingSamplesByteBuffer.get(sampleIndex));
      }
    }
    linearByteBufferAllocator.reset();
  }

  private ImmutableList<ProcessedTrackInfo> processAllTracks(long nextFragmentFirstSampleTimeUs) {
    ImmutableList.Builder<ProcessedTrackInfo> trackInfos = new ImmutableList.Builder<>();
    for (int i = 0; i < tracks.size(); i++) {
      Track track = tracks.get(i);
      if (!track.pendingSamplesBufferInfo.isEmpty()) {
        long trackNextSampleTimeUs =
            track.equals(videoTrack) ? nextFragmentFirstSampleTimeUs : C.TIME_UNSET;
        trackInfos.add(processTrack(track.id, track, trackNextSampleTimeUs));
      }
    }
    return trackInfos.build();
  }

  private ProcessedTrackInfo processTrack(
      int trackId, Track track, long nextFragmentFirstSampleTimeUs) {
    checkState(track.pendingSamplesByteBuffer.size() == track.pendingSamplesBufferInfo.size());

    ImmutableList.Builder<ByteBuffer> pendingSamplesByteBuffer = new ImmutableList.Builder<>();
    ImmutableList.Builder<BufferInfo> pendingSamplesBufferInfoBuilder =
        new ImmutableList.Builder<>();
    if (doesSampleContainAnnexBNalUnits(track.format)) {
      while (!track.pendingSamplesByteBuffer.isEmpty()) {
        ByteBuffer currentSampleByteBuffer = track.pendingSamplesByteBuffer.removeFirst();
        currentSampleByteBuffer =
            annexBToAvccConverter.process(currentSampleByteBuffer, linearByteBufferAllocator);
        pendingSamplesByteBuffer.add(currentSampleByteBuffer);
        BufferInfo currentSampleBufferInfo = track.pendingSamplesBufferInfo.removeFirst();
        currentSampleBufferInfo =
            new BufferInfo(
                currentSampleBufferInfo.presentationTimeUs,
                currentSampleByteBuffer.remaining(),
                currentSampleBufferInfo.flags);
        pendingSamplesBufferInfoBuilder.add(currentSampleBufferInfo);
      }
    } else {
      pendingSamplesByteBuffer.addAll(track.pendingSamplesByteBuffer);
      track.pendingSamplesByteBuffer.clear();
      pendingSamplesBufferInfoBuilder.addAll(track.pendingSamplesBufferInfo);
      track.pendingSamplesBufferInfo.clear();
    }

    boolean hasBFrame = false;
    ImmutableList<BufferInfo> pendingSamplesBufferInfo = pendingSamplesBufferInfoBuilder.build();
    long fragmentEndTimestampUs =
        nextFragmentFirstSampleTimeUs != C.TIME_UNSET
            ? nextFragmentFirstSampleTimeUs
            : track.endOfStreamTimestampUs;
    List<Integer> sampleDurations =
        Boxes.convertPresentationTimestampsToDurationsVu(
            pendingSamplesBufferInfo,
            track.videoUnitTimebase(),
            LAST_SAMPLE_DURATION_BEHAVIOR_SET_FROM_END_OF_STREAM_BUFFER_OR_DUPLICATE_PREVIOUS,
            fragmentEndTimestampUs);

    List<Integer> sampleCompositionTimeOffsets =
        Boxes.calculateSampleCompositionTimeOffsets(
            pendingSamplesBufferInfo, sampleDurations, track.videoUnitTimebase());
    if (!sampleCompositionTimeOffsets.isEmpty()) {
      hasBFrame = true;
    }

    ImmutableList.Builder<SampleMetadata> pendingSamplesMetadata = new ImmutableList.Builder<>();
    int totalSamplesSize = 0;
    for (int i = 0; i < pendingSamplesBufferInfo.size(); i++) {
      totalSamplesSize += pendingSamplesBufferInfo.get(i).size;
      pendingSamplesMetadata.add(
          new SampleMetadata(
              sampleDurations.get(i),
              pendingSamplesBufferInfo.get(i).size,
              pendingSamplesBufferInfo.get(i).flags,
              hasBFrame ? sampleCompositionTimeOffsets.get(i) : 0));
    }

    BufferInfo firstPendingSample = checkNotNull(pendingSamplesBufferInfo.get(0));
    // The baseMediaDecodeTime is scaled to the track's timescale (unit timebase) per
    // ISO/IEC 14496-12 Section 8.8.8 and CMAF ISO/IEC 23000-19 Section 7.5.16. Initial
    // presentation timestamps can be negative (e.g. audio pre-roll or encoder delay in Opus or
    // IAMF streams). Since baseMediaDecodeTime in tfdt is an unsigned integer, it is clamped to 0.
    long baseMediaDecodeTime =
        max(
            0L,
            Util.scaleLargeTimestamp(
                /* timestamp= */ firstPendingSample.presentationTimeUs,
                /* multiplier= */ track.videoUnitTimebase(),
                /* divisor= */ 1_000_000L));

    return new ProcessedTrackInfo(
        trackId,
        track.format,
        totalSamplesSize,
        baseMediaDecodeTime,
        hasBFrame,
        pendingSamplesByteBuffer.build(),
        pendingSamplesMetadata.build());
  }

  private static class ProcessedTrackInfo {
    public final int trackId;
    public final Format trackFormat;
    public final int totalSamplesSize;
    public final long baseMediaDecodeTime;
    public final boolean hasBFrame;
    public final ImmutableList<ByteBuffer> pendingSamplesByteBuffer;
    public final ImmutableList<SampleMetadata> pendingSamplesMetadata;

    public ProcessedTrackInfo(
        int trackId,
        Format trackFormat,
        int totalSamplesSize,
        long baseMediaDecodeTime,
        boolean hasBFrame,
        ImmutableList<ByteBuffer> pendingSamplesByteBuffer,
        ImmutableList<SampleMetadata> pendingSamplesMetadata) {
      this.trackId = trackId;
      this.trackFormat = trackFormat;
      this.totalSamplesSize = totalSamplesSize;
      this.baseMediaDecodeTime = baseMediaDecodeTime;
      this.hasBFrame = hasBFrame;
      this.pendingSamplesByteBuffer = pendingSamplesByteBuffer;
      this.pendingSamplesMetadata = pendingSamplesMetadata;
    }
  }
}
