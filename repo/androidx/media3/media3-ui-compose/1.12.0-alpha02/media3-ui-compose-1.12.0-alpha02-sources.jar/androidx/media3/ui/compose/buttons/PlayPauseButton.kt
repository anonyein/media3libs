/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.media3.ui.compose.buttons

import androidx.compose.runtime.Composable
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.compose.state.DisplayMode
import androidx.media3.ui.compose.state.PlayPauseButtonState
import androidx.media3.ui.compose.state.SHOW_BUFFERING_ALWAYS
import androidx.media3.ui.compose.state.SHOW_REPLAY_ON_ENDED
import androidx.media3.ui.compose.state.SHOW_RETRY_ON_ERROR
import androidx.media3.ui.compose.state.rememberPlayPauseButtonState

/**
 * A state container for a button that plays or pauses the media item.
 *
 * This composable manages the enabled state and click handling of a play-pause button. The UI is
 * provided by the [content] lambda, which has access to the [PlayPauseButtonState].
 *
 * @param player The [Player] to control.
 * @param displayMode The [DisplayMode] determining under which conditions buffering, replay, or
 *   retry indicators should be shown. Defaults to [SHOW_BUFFERING_ALWAYS] combined with
 *   [SHOW_REPLAY_ON_ENDED] and [SHOW_RETRY_ON_ERROR].
 * @param content The composable content to be displayed for the button.
 */
@UnstableApi
@Composable
fun PlayPauseButton(
  player: Player?,
  displayMode: @DisplayMode Int =
    SHOW_BUFFERING_ALWAYS or SHOW_REPLAY_ON_ENDED or SHOW_RETRY_ON_ERROR,
  content: @Composable PlayPauseButtonState.() -> Unit,
) {
  rememberPlayPauseButtonState(player, displayMode).content()
}
