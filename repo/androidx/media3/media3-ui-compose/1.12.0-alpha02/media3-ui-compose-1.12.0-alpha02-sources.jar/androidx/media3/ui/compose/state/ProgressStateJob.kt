/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.media3.ui.compose.state

import androidx.annotation.VisibleForTesting
import androidx.compose.runtime.withFrameMillis
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.media3.common.util.UnstableApi
import androidx.media3.common.util.Util
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

internal class ProgressStateJob(
  private val player: Player,
  private val scope: CoroutineScope,
  private val nextMediaTickMsSupplier: () -> Long,
  private val shouldScheduleTask: () -> Boolean,
  private val scheduledTask: () -> Unit,
) {
  private var updateJob: Job? = null
  private var isObserving = false
  private val liveProgressCalculator = LiveProgressCalculator()
  private val timelineWindow = Timeline.Window()

  private val playerStateObserver =
    player.observeState(
      Player.EVENT_IS_PLAYING_CHANGED,
      Player.EVENT_POSITION_DISCONTINUITY,
      Player.EVENT_MEDIA_ITEM_TRANSITION,
      Player.EVENT_TIMELINE_CHANGED,
      Player.EVENT_PLAYBACK_PARAMETERS_CHANGED,
      Player.EVENT_AVAILABLE_COMMANDS_CHANGED,
      initialStateUpdater = {
        liveProgressCalculator.reset()
        cancelPendingUpdatesAndMaybeRelaunch()
      },
      stateUpdater = ::updateEvents,
    )

  /**
   * Returns the current position in milliseconds of a live stream, smoothed if the [window] start
   * time is known. Must only be called while playing a live stream.
   */
  internal fun getSmoothedLivePositionMs(window: Timeline.Window?, durationMs: Long): Long =
    smoothLivePosition(getCurrentPositionMsOrDefault(player), window, durationMs)

  /**
   * Returns the buffered position in milliseconds of a live stream, smoothed if the [window] start
   * time is known. Must only be called while playing a live stream.
   */
  internal fun getSmoothedLiveBufferedPositionMs(window: Timeline.Window?, durationMs: Long): Long =
    smoothLivePosition(getBufferedPositionMsOrDefault(player), window, durationMs)

  private fun smoothLivePosition(
    rawPositionMs: Long,
    window: Timeline.Window?,
    durationMs: Long,
  ): Long {
    if (window == null || window.windowStartTimeMs == C.TIME_UNSET || durationMs <= 0) {
      return rawPositionMs
    }
    return liveProgressCalculator.calculateAvailableWindowPosition(
      currentPositionMs = rawPositionMs,
      windowStartTimeMs = window.windowStartTimeMs,
      durationMs = durationMs,
      presentationStartTimeMs = window.presentationStartTimeMs,
    )
  }

  /**
   * Subscribes to updates from [Player.Events] to track changes of progress-related information in
   * an asynchronous way.
   */
  internal suspend fun observeProgress(): Nothing = coroutineScope {
    isObserving = true
    try {
      playerStateObserver.observe()
    } finally {
      isObserving = false
      updateJob?.cancel()
    }
  }

  private fun updateEvents(player: Player, events: Player.Events) {
    if (
      events.containsAny(Player.EVENT_POSITION_DISCONTINUITY, Player.EVENT_MEDIA_ITEM_TRANSITION)
    ) {
      // Seeks, discontinuities (including ad transitions) and media item transitions move the
      // position independently of the live window, so the smoothing has to start again from the new
      // raw position.
      liveProgressCalculator.reset()
    } else if (events.contains(Player.EVENT_TIMELINE_CHANGED)) {
      val window = getWindowOrNull(player, timelineWindow)
      if (window == null || !window.isLive()) {
        liveProgressCalculator.reset()
      } else {
        // Timeline updates refresh the live window without moving the playback position, so keep
        // the smoothing and only let the calculator update its sliding window detection.
        liveProgressCalculator.onTimelineChanged(
          windowStartTimeMs = window.windowStartTimeMs,
          windowDurationMs = window.durationMs,
        )
      }
    }
    cancelPendingUpdatesAndMaybeRelaunch()
  }

  /**
   * Manually restarts the continuous progress update, for example if scheduling parameters changed.
   */
  internal fun cancelPendingUpdatesAndMaybeRelaunch() {
    scheduledTask()
    if (!isObserving) {
      return
    }
    updateJob?.cancel()
    if (player.isCommandAvailable(Player.COMMAND_GET_CURRENT_MEDIA_ITEM) && shouldScheduleTask()) {
      updateJob = scope.launch {
        while (isActive) {
          smartDelay()
          scheduledTask()
        }
      }
    }
  }

  /**
   * Delay the polling of the [Player] until the current position reaches the value supplied by
   * [nextMediaTickMsSupplier]. If the time delta from until that next tick is less that
   * [MIN_UPDATE_INTERVAL_MS], the polling is suspended until the next frame is requested,
   * preventing unnecessarily frequent updates that will not be visible on the screen.
   *
   * Playback speed is taken into account as well, since it expands or shrinks the effective media
   * duration.
   */
  private suspend fun smartDelay() {
    if (player.isPlaying) {
      val mediaTimeToNextTickMs = nextMediaTickMsSupplier() - getCurrentPositionMsOrDefault(player)
      // Convert the interval to wall-clock time
      val realTimeToNextTickMs = mediaTimeToNextTickMs / player.playbackParameters.speed
      if (realTimeToNextTickMs < MIN_UPDATE_INTERVAL_MS) {
        // Throttle by recomposition frequency
        withFrameMillis {}
      } else {
        // Prevent infinite delays by 0
        delay(realTimeToNextTickMs.toLong().coerceAtLeast(1L))
      }
    } else {
      delay(FALLBACK_UPDATE_INTERVAL_MS)
    }
  }
}

internal fun getCurrentPositionMsOrDefault(player: Player): Long {
  return if (player.isCommandAvailable(Player.COMMAND_GET_CURRENT_MEDIA_ITEM)) {
    player.currentPosition
  } else {
    0
  }
}

internal fun getBufferedPositionMsOrDefault(player: Player): Long {
  return if (player.isCommandAvailable(Player.COMMAND_GET_CURRENT_MEDIA_ITEM)) {
    player.bufferedPosition
  } else {
    0
  }
}

internal fun getDurationMsOrDefault(player: Player): Long {
  return if (player.isCommandAvailable(Player.COMMAND_GET_CURRENT_MEDIA_ITEM)) {
    player.duration
  } else {
    C.TIME_UNSET
  }
}

internal fun getOriginalDurationMsOrDefault(
  player: Player,
  window: Timeline.Window = Timeline.Window(),
  period: Timeline.Period = Timeline.Period(),
): Long {
  if (!player.isCommandAvailable(Player.COMMAND_GET_CURRENT_MEDIA_ITEM)) {
    return C.TIME_UNSET
  }
  if (!player.isPlayingAd && player.isCommandAvailable(Player.COMMAND_GET_TIMELINE)) {
    val timeline = player.currentTimeline
    if (!timeline.isEmpty) {
      timeline.getWindow(player.currentMediaItemIndex, window)
      // Clipping is only supported for single-period media items.
      if (window.firstPeriodIndex == window.lastPeriodIndex) {
        val originalDurationMs =
          timeline.getPeriod(window.firstPeriodIndex, period).originalDurationMs
        if (originalDurationMs != C.TIME_UNSET) {
          return originalDurationMs
        }
      }
    }
  }
  return player.duration
}

/**
 * Returns the configured target live offset of the [window], or otherwise the offset of its default
 * position, or [C.TIME_UNSET] if neither is known.
 *
 * The default position offset is measured from the current time if the window start time is known
 * (consistent with [Player.getCurrentLiveOffset]), or from the end of the window otherwise.
 */
internal fun getTargetLiveOffsetMsOrDefault(window: Timeline.Window?): Long {
  if (window == null) return C.TIME_UNSET
  val configTarget = window.liveConfiguration?.targetOffsetMs ?: C.TIME_UNSET
  if (configTarget != C.TIME_UNSET) return configTarget
  if (window.defaultPositionUs <= 0) return C.TIME_UNSET
  if (window.windowStartTimeMs != C.TIME_UNSET) {
    return window.currentUnixTimeMs - window.windowStartTimeMs - window.defaultPositionMs
  }
  if (window.durationUs != C.TIME_UNSET && window.defaultPositionUs <= window.durationUs) {
    return Util.usToMs(window.durationUs - window.defaultPositionUs)
  }
  return C.TIME_UNSET
}

internal fun getWindowOrNull(
  player: Player,
  window: Timeline.Window = Timeline.Window(),
): Timeline.Window? {
  return if (player.isCommandAvailable(Player.COMMAND_GET_TIMELINE)) {
    val timeline = player.currentTimeline
    if (!timeline.isEmpty) {
      timeline.getWindow(player.currentMediaItemIndex, window)
    } else {
      null
    }
  } else {
    null
  }
}

internal fun isReadyOrBuffering(player: Player): Boolean =
  player.playbackState == Player.STATE_READY || player.playbackState == Player.STATE_BUFFERING

// Taking highest frame rate as 120fps, interval is 1000/120
@UnstableApi const val MIN_UPDATE_INTERVAL_MS = 8L
@UnstableApi
@VisibleForTesting(otherwise = VisibleForTesting.PRIVATE)
const val FALLBACK_UPDATE_INTERVAL_MS = 1000L
