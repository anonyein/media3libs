/*
 * Copyright 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.media3.ui.compose.state

import androidx.annotation.VisibleForTesting
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Size
import androidx.media3.common.C
import androidx.media3.common.MediaLibraryInfo
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi

/**
 * Remembers the value of [PresentationState] created based on the passed [Player] and launches a
 * coroutine to listen to [Player's][Player] changes.
 *
 * Note that if the [Player] instance changes between compositions, the method will not produce a
 * new value. The same object will be reused and subscribe to the [Player.Events] of the new player.
 *
 * @param[player] the Player whose [PresentationState] will be controlled.
 * @param[keepContentOnReset] whether the currently displayed video frame or media artwork is kept
 *   visible when tracks change or player changes. Defaults to false.
 */
@UnstableApi
@Composable
fun rememberPresentationState(
  player: Player?,
  keepContentOnReset: Boolean = false,
): PresentationState {
  val presentationState = remember {
    PresentationState(keepContentOnReset).apply { this.player = player }
  }
  LaunchedEffect(player) { presentationState.observe(player) }
  LaunchedEffect(keepContentOnReset) { presentationState.keepContentOnReset = keepContentOnReset }
  return presentationState
}

/**
 * State that holds information to correctly deal with UI components related to the rendering of
 * frames to a surface.
 *
 * @param[keepContentOnReset] whether the currently displayed video frame or media artwork is kept
 *   visible when tracks change or player changes. Defaults to false.
 * @property[videoAspectRatio] the aspect ratio of the video (width / height), adjusted for
 *   [VideoSize.pixelWidthHeightRatio]. Becomes `null` when either height or width of the video is
 *   zero, or [player] is null.
 * @property[coverSurface] set to false when the Player emits [Player.EVENT_RENDERED_FIRST_FRAME]
 *   and reset back to true on [Player.EVENT_TRACKS_CHANGED] depending on the number and type of
 *   tracks.
 * @property[showArtwork] set to true when artwork should be displayed. It does not guarantee that
 *   the current media item actually contains artwork data; the caller is responsible for validating
 *   the presence of artwork before rendering.
 */
@UnstableApi
class PresentationState(keepContentOnReset: Boolean = false) {
  private var _adjustedVideoSize by mutableStateOf<Size?>(null)

  /**
   * Wraps the video size in Compose's [Size].
   *
   * @deprecated Use [videoAspectRatio] instead.
   */
  @Deprecated("Use videoAspectRatio instead.")
  val videoSizeDp: Size?
    get() = _adjustedVideoSize

  val videoAspectRatio: Float?
    get() = _adjustedVideoSize?.run { width / height }

  var coverSurface by mutableStateOf(true)
    private set

  var showArtwork by mutableStateOf(false)
    private set

  internal var keepContentOnReset: Boolean = keepContentOnReset
    set(value) {
      if (value != field) {
        field = value
        updateForCurrentTrackSelections(player)
      }
    }

  private var playerStateObserver: PlayerStateObserver? = null

  @VisibleForTesting(otherwise = VisibleForTesting.PRIVATE)
  var player: Player? = null
    set(value) {
      if (field == value) return
      field = value
      playerStateObserver =
        value?.observeState(
          Player.EVENT_VIDEO_SIZE_CHANGED,
          Player.EVENT_RENDERED_FIRST_FRAME,
          Player.EVENT_TRACKS_CHANGED,
          Player.EVENT_TRACK_SELECTION_PARAMETERS_CHANGED,
          initialStateUpdater = ::initializeState,
          stateUpdater = ::updateState,
        )
      if (value == null) {
        if (!keepContentOnReset) {
          _adjustedVideoSize = null
        }
        updateForCurrentTrackSelections(null)
      }
    }

  private var lastPeriodUidWithTracks: Any? = null

  /**
   * Subscribes to updates from [Player.Events] and listens to
   * * [Player.EVENT_VIDEO_SIZE_CHANGED] to determine pixelWidthHeightRatio-adjusted video size
   * * [Player.EVENT_RENDERED_FIRST_FRAME], [Player.EVENT_TRACKS_CHANGED], and
   *   [Player.EVENT_TRACK_SELECTION_PARAMETERS_CHANGED] to determine whether the surface is ready
   *   to be shown
   */
  suspend fun observe(player: Player?) {
    try {
      this@PresentationState.player = player
      playerStateObserver?.observe()
    } finally {
      this@PresentationState.player = null
    }
  }

  private fun initializeState(player: Player) {
    _adjustedVideoSize = getAdjustedVideoSize(player)
    updateForCurrentTrackSelections(player)
  }

  private fun updateState(player: Player, events: Player.Events) {
    if (events.contains(Player.EVENT_VIDEO_SIZE_CHANGED)) {
      if (player.videoSize != VideoSize.UNKNOWN && player.playbackState != Player.STATE_IDLE) {
        _adjustedVideoSize = getAdjustedVideoSize(player)
      }
    }
    if (events.contains(Player.EVENT_RENDERED_FIRST_FRAME)) {
      // open shutter, video available
      coverSurface = false
    }
    if (
      events.containsAny(
        Player.EVENT_TRACKS_CHANGED,
        Player.EVENT_TRACK_SELECTION_PARAMETERS_CHANGED,
      )
    ) {
      if (!shouldKeepSurfaceVisible(player)) {
        updateForCurrentTrackSelections(player)
      }
    }
  }

  private fun getAdjustedVideoSize(player: Player): Size? {
    var videoSize = Size(player.videoSize.width.toFloat(), player.videoSize.height.toFloat())
    if (videoSize.width == 0f || videoSize.height == 0f) return null

    val par = player.videoSize.pixelWidthHeightRatio
    if (par < 1.0) {
      videoSize = videoSize.copy(width = videoSize.width * par)
    } else if (par > 1.0) {
      videoSize = videoSize.copy(height = videoSize.height / par)
    }
    return videoSize
  }

  @VisibleForTesting(otherwise = VisibleForTesting.PRIVATE)
  fun updateForCurrentTrackSelections(player: Player?) {
    if (player != null) {
      val hasTracks =
        player.isCommandAvailable(Player.COMMAND_GET_TRACKS) && !player.currentTracks.isEmpty
      if (!keepContentOnReset && !hasTracks) {
        coverSurface = true
        showArtwork = false
      }
      if (hasTracks) {
        if (!hasSelectedVideoTrack(player)) {
          // Nothing is rendered to the surface without a video track, so keep it covered. With a
          // video track, the shutter is lifted on EVENT_RENDERED_FIRST_FRAME instead.
          coverSurface = true
        }
        showArtwork = !hasSelectedVideoTrack(player)
      }
    } else {
      coverSurface = coverSurface || !keepContentOnReset
      showArtwork = showArtwork && keepContentOnReset
    }
  }

  private fun shouldKeepSurfaceVisible(player: Player): Boolean {
    // Suppress the shutter if transitioning to an unprepared period within the same window. This
    // is necessary to avoid closing the shutter (i.e covering the surface) when such a transition
    // occurs. See: https://github.com/google/ExoPlayer/issues/5507.
    val timeline =
      if (player.isCommandAvailable(Player.COMMAND_GET_TIMELINE)) player.currentTimeline
      else Timeline.EMPTY

    if (timeline.isEmpty) {
      lastPeriodUidWithTracks = null
      return false
    }

    val period = Timeline.Period()
    if (player.isCommandAvailable(Player.COMMAND_GET_TRACKS) && !player.currentTracks.isEmpty) {
      lastPeriodUidWithTracks =
        timeline.getPeriod(player.currentPeriodIndex, period, /* setIds= */ true).uid
    } else
      lastPeriodUidWithTracks?.let {
        val lastPeriodIndexWithTracks = timeline.getIndexOfPeriod(it)
        if (lastPeriodIndexWithTracks != C.INDEX_UNSET) {
          val lastWindowIndexWithTracks =
            timeline.getPeriod(lastPeriodIndexWithTracks, period).windowIndex
          if (player.currentMediaItemIndex == lastWindowIndexWithTracks) {
            // We're in the same media item, keep the surface visible, don't show the shutter.
            return true
          }
        }
        lastPeriodUidWithTracks = null
      }
    return false
  }

  private fun hasSelectedVideoTrack(player: Player): Boolean =
    player.isCommandAvailable(Player.COMMAND_GET_TRACKS) &&
      player.currentTracks.isTypeSelected(C.TRACK_TYPE_VIDEO)

  companion object {
    init {
      MediaLibraryInfo.registerModule("media3.ui.compose")
    }
  }
}
