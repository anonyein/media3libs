/*
 * Copyright 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.media3.ui.compose.state

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi

/**
 * Remembers the value of [PreviousButtonState] created based on the passed [Player] and launch a
 * coroutine to listen to [Player's][Player] changes. If the [Player] instance changes between
 * compositions, produce and remember a new value.
 */
@UnstableApi
@Composable
fun rememberPreviousButtonState(player: Player?): PreviousButtonState {
  val previousButtonState = remember(player) { PreviousButtonState(player) }
  LaunchedEffect(player) { previousButtonState.observe() }
  return previousButtonState
}

/**
 * State that holds all interactions to correctly deal with a UI component representing a
 * seek-to-previous button.
 *
 * This button has no internal state to maintain, it can only be enabled or disabled.
 *
 * @property[isEnabled] true if [player] is not `null` and [Player.COMMAND_SEEK_TO_PREVIOUS] is
 *   available.
 */
@UnstableApi
class PreviousButtonState(private val player: Player?) {
  var isEnabled by mutableStateOf(false)
    private set

  private val playerStateObserver: PlayerStateObserver? =
    player?.observeState(Player.EVENT_AVAILABLE_COMMANDS_CHANGED) {
      isEnabled = player.isCommandAvailable(Player.COMMAND_SEEK_TO_PREVIOUS)
    }

  /**
   * Handles the interaction with the PreviousButton by seeking to a later position in the current
   * or next MediaItem (if available).
   *
   * This method does nothing if [Player.COMMAND_SEEK_TO_PREVIOUS] is not available.
   *
   * @see [Player.seekToPrevious]
   * @see [Player.COMMAND_SEEK_TO_PREVIOUS]
   */
  fun onClick() {
    player?.let { if (it.isCommandAvailable(Player.COMMAND_SEEK_TO_PREVIOUS)) it.seekToPrevious() }
  }

  /**
   * Subscribes to updates from [Player.Events] and listens to
   * [Player.EVENT_AVAILABLE_COMMANDS_CHANGED] in order to determine whether the button should be
   * enabled, i.e. respond to user input.
   */
  suspend fun observe() {
    playerStateObserver?.observe()
  }
}
