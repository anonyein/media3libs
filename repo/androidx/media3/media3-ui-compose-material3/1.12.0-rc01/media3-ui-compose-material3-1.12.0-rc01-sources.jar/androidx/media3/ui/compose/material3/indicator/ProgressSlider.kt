/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.media3.ui.compose.material3.indicator

import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderColors
import androidx.compose.material3.SliderDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import androidx.media3.common.util.ExperimentalApi
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.compose.indicators.ProgressIndicator
import androidx.media3.ui.compose.material3.util.clearFractionalSeekToleranceIfEquals
import androidx.media3.ui.compose.material3.util.isScrubbingModeEnabled
import androidx.media3.ui.compose.material3.util.setFractionalSeekTolerance
import androidx.media3.ui.compose.material3.util.setScrubbingModeEnabled
import kotlinx.coroutines.CoroutineScope

/**
 * A Material3 [Slider] that displays the current position of the player.
 *
 * When [player] is an `ExoPlayer`, this composable automatically configures
 * `ScrubbingModeParameters.fractionalSeekToleranceBefore` and
 * `ScrubbingModeParameters.fractionalSeekToleranceAfter` based on the slider's width and clears
 * them to `null` when disposed.
 *
 * @param player The [Player] to get the progress from.
 * @param modifier The [Modifier] to be applied to the slider.
 */
@UnstableApi
@Composable
fun ProgressSlider(player: Player?, modifier: Modifier = Modifier) {
  ProgressSlider(
    player,
    modifier,
    onValueChangeFinished = null,
    scope = rememberCoroutineScope(),
    colors = SliderDefaults.colors(),
    interactionSource = remember { MutableInteractionSource() },
  )
}

/**
 * A Material3 [Slider] that displays the current position of the player.
 *
 * @param player The [Player] to get the progress from.
 * @param modifier The [Modifier] to be applied to the slider.
 * @param onValueChange An optional callback that is invoked continuously as the user drags the
 *   slider thumb. The lambda receives a `Float` representing the new progress value (from 0.0 to
 *   1.0). This can be used to display a preview of the seek position. You should not use this
 *   callback to update the slider's value, as this is handled internally.
 * @param onValueChangeFinished An optional callback that is invoked when the user has finished
 *   their interaction (by lifting their finger or tapping). The underlying `Player.seekTo`
 *   operation is performed internally just before this callback is invoked.
 * @param scope The [CoroutineScope] to use for listening to player progress updates.
 * @param colors [SliderColors] that will be used to resolve the colors used for this slider in
 *   different states. See [SliderDefaults.colors].
 * @param scrubbingEnabled Whether the time bar should seek immediately as the user drags the
 *   scrubber around (true), or only seek when the user releases the scrubber (false). When `true`
 *   and [player] is an `ExoPlayer`, `ScrubbingModeParameters.fractionalSeekToleranceBefore` and
 *   `ScrubbingModeParameters.fractionalSeekToleranceAfter` are automatically configured based on
 *   the slider's width and cleared to `null` when disposed.
 * @param interactionSource the [MutableInteractionSource] representing the stream of
 *   [Interactions][androidx.compose.foundation.interaction.Interaction] for this slider. You can
 *   create and pass in your own `remember`ed instance to observe `Interactions` and customize the
 *   appearance / behavior of this slider in different states.
 */
@ExperimentalApi // TODO: b/490019662 - Move to stable/unstable
@Composable
fun ProgressSlider(
  player: Player?,
  modifier: Modifier = Modifier,
  onValueChange: ((Float) -> Unit)? = null,
  onValueChangeFinished: (() -> Unit)? = null,
  scope: CoroutineScope = rememberCoroutineScope(),
  colors: SliderColors = SliderDefaults.colors(),
  scrubbingEnabled: Boolean = true,
  interactionSource: MutableInteractionSource = remember { MutableInteractionSource() },
) {
  var sliderWidthPx by remember { mutableIntStateOf(0) }
  val tolerancePx = with(LocalDensity.current) { SCRUBBING_TOLERANCE.toPx() }
  ProgressIndicator(player, totalTickCount = sliderWidthPx, scope) {
    var isDragging by remember { mutableStateOf(false) }
    var seekPosition by remember { mutableFloatStateOf(0f) }

    val tolerance =
      if (scrubbingEnabled && sliderWidthPx > 0) {
        (tolerancePx.toDouble() / sliderWidthPx).coerceIn(0.0, 1.0)
      } else {
        null
      }
    if (tolerance != null) {
      DisposableEffect(player, tolerance) {
        player.setFractionalSeekTolerance(toleranceBefore = tolerance, toleranceAfter = tolerance)
        onDispose {
          player.clearFractionalSeekToleranceIfEquals(
            toleranceBefore = tolerance,
            toleranceAfter = tolerance,
          )
        }
      }
    }
    // Fallback for navigating away before the trailing invoke in onValueChangeFinished is called
    DisposableEffect(player) {
      onDispose {
        player.setScrubbingModeEnabled(false)
        isDragging = false
      }
    }
    // Cache the result to avoid repeated reflection calls
    var scrubbingEnabledForThisPlayer by
      remember(player, scrubbingEnabled) { mutableStateOf(false) }

    Slider(
      value = if (isDragging) seekPosition else currentPositionProgress,
      onValueChange = {
        if (!isDragging && scrubbingEnabled) {
          if (tolerance != null) {
            player.setFractionalSeekTolerance(
              toleranceBefore = tolerance,
              toleranceAfter = tolerance,
            )
          }
          player.setScrubbingModeEnabled(true)
          scrubbingEnabledForThisPlayer = player.isScrubbingModeEnabled()
        }
        isDragging = true
        seekPosition = it
        // Dispatch seeks only if they are less expensive (scrubbing mode enabled)
        if (scrubbingEnabledForThisPlayer) updateCurrentPositionProgress(seekPosition)
        onValueChange?.invoke(it)
      },
      onValueChangeFinished = {
        updateCurrentPositionProgress(seekPosition)
        player.setScrubbingModeEnabled(false)
        isDragging = false
        onValueChangeFinished?.invoke()
      },
      // Measure after the caller's modifier (excluding any caller padding) and clamp to
      // constraints.maxWidth because Material3 Slider's internal minimumInteractiveComponentSize
      // enforces a 48.dp minimum even when constrained to a smaller width.
      modifier =
        modifier.layout { measurable, constraints ->
          val placeable = measurable.measure(constraints)
          sliderWidthPx = minOf(placeable.width, constraints.maxWidth)
          layout(placeable.width, placeable.height) { placeable.placeRelative(0, 0) }
        },
      enabled = changingProgressEnabled,
      colors = colors,
      interactionSource = interactionSource,
    )
  }
}

private val SCRUBBING_TOLERANCE = 2.dp
